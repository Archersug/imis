<?php
    include_once '../../includes/loader.php';
    include_once '../functions.php';

    // Initialize
    $db = new MySQL();   
    $requestTime = date('Y-m-d H:i:s');
    cors();

    // Determine API request from url. 
    // Test last element for url query string
    $arrURL = explode("/", $_SERVER['REQUEST_URI']);
    $request = $arrURL[count($arrURL) - 1];

    // Possible requests
    $arrPossibleRequests = array("sign-in", "sign-up", "update", "save-academy");

    // Capture API request body and save to an array
    $arrRequestBody = json_decode(file_get_contents("php://input"), true);
   
    // Capture API request headers and save to array
    $arrRequestHeaders = array();
    foreach ($_SERVER as $key => $value) {
        if (strpos($key, 'HTTP_') === 0) {
            $arrRequestHeaders[str_replace(' ', '', ucwords(str_replace('_', ' ', strtolower(substr($key, 5)))))] = $value;
        }
    }
    
    // Check request for user and token headers    
    if($arrRequestHeaders['User'] && $arrRequestHeaders['Token'])
    {
        // Authenticate user
        $authStatus = aunthenticateApiUserWeb($arrRequestHeaders['User'], $arrRequestHeaders['Token']);
        if($authStatus == 1) // valid user and apikey
        {
            if(in_array($request, $arrPossibleRequests))
            {
                $userId = getUserFromAPI($arrRequestHeaders['User']);
                $arrRequestBody['user_id'] = $userId['user_id'];

                if($request == 'update')
                {
                    $arrSync = syncData();
                    $message = "Request Successful!";

                    if($arrSync)
                    {
                        $arrResponse = array(
                            "SUCCESS" => 1,
                            "MESSAGE" => $message,
                            "RESULT" => $arrSync,
                            "HTTPCODE" => "200"
                        );
                    }
                    else
                    {
                        $arrResponse = array(
                            "SUCCESS" => 1,
                            "MESSAGE" => "Access denied-o",
                            "RESULT" => [],
                            "HTTPCODE" => "401"
                        );
                    }
                    
                } 
                elseif($request == 'sign-in')
                {
                    $arrUser = signIn($arrRequestBody);
                    $message = "Request Successful!";

                    if(($arrUser['SUCCESS'] == 1))
                    {
                        $arrResponse = array(
                            "SUCCESS" => 1,
                            "MESSAGE" => $message,
                            "RESULT" => $arrUser['RESULT'],
                            "HTTPCODE" => "200"
                        );
                    }
                    else
                    {
                        $arrResponse = array(
                            "SUCCESS" => 0,
                            "MESSAGE" => $arrUser['MESSAGE'],
                            "HTTPCODE" => "401"
                        );
                    }
                    
                }                
                elseif($request == 'sign-up')
                {
                    $arrUser = signUp($arrRequestBody);
                    if($arrUser['SUCCESS'] == 1)
                    {
                        $arrResponse = array(
                                        "SUCCESS" => 1,
                                        "MESSAGE" => "Request Successful",
                                        "HTTPCODE" => "200",
                                        "RESULT" => $arrUser['RESULT'],
                                    );
                    }
                    else
                    {
                        $arrResponse = array(
                                        "SUCCESS" => 0,
                                        "MESSAGE" => $arrUser['MESSAGE'],
                                    );
                    }
                }
                elseif($request == 'save-academy')
                {
                    $arrSync = saveAcademy($arrRequestBody);
                    if(!empty($arrSync))
                    {
                        $arrResponse = array(
                                        "SUCCESS" => 1,
                                        "MESSAGE" => "Request Successful",
                                        "HTTPCODE" => "200",
                                        "RESULT" => $arrSync,
                                    );
                    }
                    else
                    {
                        $arrResponse = array(
                                        "SUCCESS" => 0,
                                        "HTTPCODE" => "200",
                                        "MESSAGE" => "ERROR!",
                                    );
                    }
                }
                else
                {
                    $arrResponse = array(
                                        "SUCCESS" => 0,
                                        "MESSAGE" => "Invalid REQUEST",
                                    );
                }
            }
            else
            {
                $arrResponse = array(
                                        "SUCCESS" => 0,
                                        "MESSAGE" => "Please send a REQUEST",
                                    );
                
            }

        }
        elseif($authStatus == 2) // invalid user
        {
            $arrResponse = array(
                    "SUCCESS" => 0,
                    "MESSAGE" => "Invalid user",
                    "HTTPCODE" => "401"
                );
        }
        elseif($authStatus == 3) // invalid token
        {
            $arrResponse = array(
                    "SUCCESS" => 0,
                    "MESSAGE" => "Invalid token",
                    "HTTPCODE" => "401"
                );
        }
    }
    // If no token headers, respond with a 401
    else
    {
        $arrResponse = array(
                    "SUCCESS" => 0,
                    "MESSAGE" => "Please send a user and token",
                    "HTTPCODE" => "401"
                );
    }

    // Log API request to db
    $values = array();
    $responseTime = date("Y-m-d H:i:s");
    $values["user"] = MySQL::SQLValue($arrRequestHeaders['User']);
    $values["token"] = MySQL::SQLValue($arrRequestHeaders['Token']);
    $values["request"] = MySQL::SQLValue($request);
    $values["request_date"] = MySQL::SQLValue($requestTime);
    $values["request_body"] = MySQL::SQLValue(json_encode($arrRequestBody));
    $values["request_headers"] = MySQL::SQLValue(json_encode($arrRequestHeaders));
    $values["response_date"] = MySQL::SQLValue($responseTime);
    $values["response_body"] = MySQL::SQLValue(json_encode($arrResponse));
    if(!$result = $db->InsertRow("tbl_api_requests", $values))
        die("Error query error: " . $db->Error());

    // Print out API request response
    http_response_code($arrResponse["HTTPCODE"]);
    echo json_encode($arrResponse);
?>