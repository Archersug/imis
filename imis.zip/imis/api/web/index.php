<?php
    include_once '../../app-includes/loader.php';
    include_once '../functions.php';

    // Initialize
    $db = new MySQL();   
    $requestTime = date('Y-m-d H:i:s');
    cors();

    // Capture API request body and save to an array
    $arrRequestBody = json_decode(file_get_contents("php://input"), true);
   
    // Capture API request headers and save to array
    $arrRequestHeaders = array();
    foreach ($_SERVER as $key => $value) {
        if (strpos($key, 'HTTP_') === 0) {
            $arrRequestHeaders[str_replace(' ', '', ucwords(str_replace('_', ' ', strtolower(substr($key, 5)))))] = $value;
        }
    }
    
    // Check request for user and token headers    
    if($arrRequestHeaders['User'] && $arrRequestHeaders['Token'])
    {
        // Authenticate user
        $authStatus = aunthenticateApiUserWeb($arrRequestHeaders['User'], $arrRequestHeaders['Token']);
        if($authStatus == 1) // valid user and apikey
        {
            if($arrRequestHeaders['Request'])
            {
                if($arrRequestHeaders['Request'] == 'SyncUser')
                {
                    $arrUser = 'getUserDB($arrRequestHeaders[User])';
                    $message = "Request Successful!";
                    $arrResponse = array(
                                        "SUCCESS" => 1,
                                        "MESSAGE" => $message,
                                        "RESULT" => $arrUser,
                                        "HTTPCODE" => "200"
                                    );
                }                
                elseif($arrRequestHeaders['Request'] == 'PostWeightData')
                {
                    if($result = PostWeighbridgeData($arrRequestBody))
                    {
                        $arrResponse = array(
                                        "SUCCESS" => 1,
                                        "MESSAGE" => "Request Successful",
                                        "HTTPCODE" => "200"
                                    );
                    }
                    else
                    {
                        $arrResponse = array(
                                        "SUCCESS" => 0,
                                        "MESSAGE" => "Error posting data",
                                    );
                    }
                }
                else
                {
                    http_response_code(400);
                    $arrResponse = array(
                                        "SUCCESS" => 0,
                                        "MESSAGE" => "Invalid REQUEST",
                                    );
                }
            }
            else
            {
                http_response_code(400);
                $arrResponse = array(
                                        "SUCCESS" => 0,
                                        "MESSAGE" => "Please send a REQUEST",
                                    );
                
            }

        }
        elseif($authStatus == 2) // invalid user
        {
            http_response_code(401);
            $arrResponse = array(
                    "SUCCESS" => 0,
                    "MESSAGE" => "Invalid user",
                    "HTTPCODE" => "401"
                );
        }
        elseif($authStatus == 3) // invalid token
        {
            http_response_code(401);
            $arrResponse = array(
                    "SUCCESS" => 0,
                    "MESSAGE" => "Invalid token",
                    "HTTPCODE" => "401"
                );
        }
    }
    // If no token headers, respond with a 401
    else
    {
        http_response_code(401);
        $arrResponse = array(
                    "SUCCESS" => 0,
                    "MESSAGE" => "Please send a user and token",
                    "HTTPCODE" => "401"
                );
    }

    // Log API request to db
    $values = array();
    $responseTime = date("Y-m-d H:i:s");
    $values["user"] = MySQL::SQLValue($arrRequestHeaders['User']);
    $values["token"] = MySQL::SQLValue($arrRequestHeaders['Token']);
    $values["request"] = MySQL::SQLValue($arrRequestHeaders['Request']);
    $values["request_date"] = MySQL::SQLValue($requestTime);
    $values["request_body"] = MySQL::SQLValue(json_encode($arrRequestBody));
    $values["request_headers"] = MySQL::SQLValue(json_encode($arrRequestHeaders));
    $values["response_date"] = MySQL::SQLValue($responseTime);
    $values["response_body"] = MySQL::SQLValue(json_encode($arrResponse));
    if(!$result = $db->InsertRow("tbl_api_requests", $values))
        die("Error query error: " . $db->Error());

    // Print out API request response
    echo json_encode($arrResponse);
?>