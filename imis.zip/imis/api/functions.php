<?php
    function aunthenticateApiUserWeb($uuid, $token)
    {
        if($uuid && $token)
        {
            $db = new MySQL();
            
            $qUser = "SELECT tbl_users.api_user, tbl_users.api_key
                      FROM tbl_users
                      WHERE tbl_users.api_user = '$uuid'
                      AND tbl_users.mobile_app_access = '1'
                      ";
            $arrUser = $db->QuerySingleRowArray($qUser);
            
            if($db->RowCount())
            {
                $auth = base64_encode($arrUser['api_user'] . ':' . $arrUser['api_key']);
                if($auth == $token)
                {
                    return 1;
                }
                else
                {
                    return 3;
                }
            }
            else
            {
                return 2;
            }
        }
        else
        {
            return 2;
        }
    }
    
    function aunthenticateApiUser($uuid, $token)
    {
        if($uuid && $token)
        {
            $db = new MySQL();
            
            $qUser = "SELECT tbl_users.api_user, tbl_users.api_key
                      FROM tbl_users
                      WHERE tbl_users.api_user = '$uuid'
                      ";
            $arrUser = $db->QuerySingleRowArray($qUser);
            
            if($db->RowCount())
            {
                $auth = base64_encode($arrUser['api_user'] . ':' . $arrUser['api_key']);
                if($auth == $token)
                    return 1;
                else
                    return 3;
            }
            else
            {
                return 2;
            }
        }
    }
    
    function CheckNewAppVersion($arrData)
    {
        if(!empty($arrData))
        {
            $db = new MySQL();
            $qVersion = "SELECT tbl_app_versions.*
                         FROM tbl_app_versions
                         ORDER BY tbl_app_versions.version_date DESC
                         LIMIT 1";
            $arrVersion = $db->QuerySingleRowArray($qVersion, MYSQLI_ASSOC)
                or die("Version query error: " . $db->Error());;
            
            if($db->RowCount())
            {
                return $arrVersion;
            }
            else
            {
                echo "No new version";
                return NULL;
            }
        }
        else
        {
            echo "Empty array";
            return false;
        }
    }
    
    function logAPIError($request, $data, $message, $version, $userId = NULL)
    {
        $db = new MySQL();
        $values = array();
        $date = date("Y-m-d H:i:s");
        
        $values["error_date"] = MySQL::SQLValue($date);
        $values["userid"] = MySQL::SQLValue($userId);
        $values["version"] = MySQL::SQLValue($version);
        $values["request"] = MySQL::SQLValue($request);
        $values["error_data"] = MySQL::SQLValue($data);
        $values["error_message"] = MySQL::SQLValue($message);
        
        if(!$result = $db->InsertRow("tbl_api_errors", $values))
            die("Error query error: " . $db->Error());
    }

    function cors() 
    {
        // Allow from any origin
        if (isset($_SERVER['HTTP_ORIGIN'])) {
            // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
            // you want to allow, and if so:
            header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
            header('Access-Control-Allow-Credentials: true');
            header('Access-Control-Max-Age: 86400');    // cache for 1 day
        }

        // Access-Control headers are received during OPTIONS requests
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

            if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
                // may also be using PUT, PATCH, HEAD etc
                header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

            if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
                header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

            exit(0);
        }

        //echo "You have CORS!";
    }

    function signIn($arrData)
    {
        //print_r($arrData);
        $db = new MySQL();
        $email = MySQL::SQLValue($arrData['email']);
        $qUser = "SELECT tbl_users.api_user, tbl_users.full_name, tbl_users.gender, tbl_users.status, 
                    tbl_users.usergroup_id, tbl_users.email, tbl_users.phone, tbl_users.password, 
                    tbl_users.user_id
                  FROM tbl_users
                  WHERE tbl_users.email = $email
                  ";
        $arrUser = $db->QuerySingleRowArray($qUser, MYSQLI_ASSOC);
        if($db->Error())
            die("User query error: " . $db->Error());

        if($db->RowCount())
        {
            //if(password_verify($arrData['password'], $arrUser['password']))
            //{
                $arrEnrollments = dbGetEnrollments();
                $arrLessons = dbGetLessons();
                $arrExams = dbGetExams();
                $arrInstructorClasses = dbGetInstructorClasses($arrUser['user_id']);

                $arrUser['enrollments'] = $arrEnrollments;
                $arrUser['lessons'] = $arrLessons;
                $arrUser['exams'] = $arrExams;
                $arrUser['instructor_classes'] = $arrInstructorClasses;
                return array(
                    "SUCCESS" => 1,
                    "RESULT" => $arrUser
                );
            /*}
            else
            {
                return array(
                    "SUCCESS" => 0,
                    "MESSAGE" => "Invalid Password"
                );
            }*/
        }
        else
        {
            return array(
                "SUCCESS" => 0,
                "MESSAGE" => "Invalid Email"
            );
        }
    }

    function signUp($arrData)
    {
        //print_r($arrData);
        $db = new MySQL(true);
        $values = array();
        $date = date("Y-m-d H:i:s");
        $apiUser = generateUUID();
        $apiKey = MD5($apiUser);
        $hashedPassword = password_hash($arrData['password'], PASSWORD_DEFAULT);

        $values['full_name'] = MySQL::SQLValue($arrData['name']);
        $values['email'] = MySQL::SQLValue($arrData['email']);
        $values['password'] = MySQL::SQLValue($hashedPassword);
        $values['gender'] = MySQL::SQLValue($arrData['gender']);
        $values['dob'] = MySQL::SQLValue($arrData['dob']);
        
        $values['api_user'] = MySQL::SQLValue($apiUser);
        $values['api_key'] = MySQL::SQLValue($apiKey);
        $values['usergroup_id'] = MySQL::SQLValue('5');
        $values['date_created'] = MySQL::SQLValue($date);
        
        $db->InsertRow("tbl_users", $values);
        if($db->Error())
            die("User insert error: " . $db->Error());

        $arrUser = signIn($arrData);
        return $arrUser;
    }

    function saveAcademy($arrData)
    {
        //print_r($arrData);
        $db = new MySQL(true);
        $values = array();
        $date = date("Y-m-d H:i:s");

        $values['academy_id'] = MySQL::SQLValue($arrData['academy_id']);
        $values['academy_name'] = MySQL::SQLValue($arrData['academy_name']);
        $values['academy_type'] = MySQL::SQLValue($arrData['academy_type']);
        $values['academy_tagline'] = MySQL::SQLValue($arrData['academy_tagline']);
        $values['academy_website'] = MySQL::SQLValue($arrData['academy_website']);
        $values['academy_address'] = MySQL::SQLValue($arrData['academy_address']);
        $values['academy_contacts'] = MySQL::SQLValue($arrData['academy_contacts']);
        $values['academy_email'] = MySQL::SQLValue($arrData['academy_email']);
        $values['academy_info'] = MySQL::SQLValue($arrData['academy_info']);
        $values['academy_logo'] = MySQL::SQLValue($arrData['academy_logo']);
        $values['user_id'] = MySQL::SQLValue($arrData['user_id']);

        $whereArray = array();
        $whereArray['academy_id'] = MySQL::SQLValue($arrData['academy_id']);
        
        //$db->InsertRow("tbl_academies", $values);
        $db->AutoInsertUpdate("tbl_academies",$values,$whereArray);
        if($db->Error())
            die("Academy insert error: " . $db->Error());

        $arrSync = syncData();
        return $arrSync; 
    }

    function syncData()
    {
        $db = new MySQL();

        $arrBenCategories = dbGetBeneficiaryCategories();
        $arrCegActivities = dbGetAllActivities();
        $arrChallenges = dbGetAllChallenges();
        $arrComponents = dbGetAllComponents();
        $arrEnterprises = dbGetFarmEnterprises();

        $arrData = array(
            "beneficiary_categories" => $arrBenCategories,
            "activities" => $arrCegActivities,
            "challenges" => $arrChallenges,
            "components" => $arrComponents,
            "enterprises" => $arrEnterprises
        );

        return $arrData;


    }

    function getUserFromAPI($apiUser)
    {
        $db = new MySQL();
        $qUser = "SELECT tbl_users.*
                    FROM tbl_users
                    WHERE tbl_users.api_user = '$apiUser'
                  ";
        $arrUser = $db->QuerySingleRowArray($qUser, MYSQLI_ASSOC);

        if($db->Error())
            die("User query error: " . $db->Error());

        return $arrUser;
    }
       
?>