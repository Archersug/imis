<?php
  session_start();
  $ROOT_FOLDER = "/2021/imis/";
  $_SESSION['LAST_REQUEST_URI'] = $_SERVER['REQUEST_URI'];
  if(isset($_SESSION['USER']['ICOLEW_USERID']))
  {
    // Include necessary scripts and classes for entire project
    include("includes/loader.php");

    // Instantiate a database connection for the current page
    $db = new MySQL();

    // Instantiate the router to serve up the requested page
    $router = new Router();

    // Page router
    $arrURL = $router->getRoute($_SERVER['REQUEST_URI']);
    $router->adjust_root();
    
    // Determine page to display
    $displayedPage = $router->navigate(implode("/", $arrURL));

    // Log visited page in audit trail
    auditTrail("visited " . $_SERVER['REQUEST_URI']);
    $options = array("receiver_id" => $_SESSION['USER']['ICOLEW_USERID']);
    $arrNotifications = getInboxNotifications($options);
    
  ?>
<!DOCTYPE html>
<html lang="en">
  <head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $ROOT_FOLDER;?>assets/img/icon.png">

    <title>iMIS: ICOLEW MANAGMENT INFORMATION SYSTEM</title>

    <!-- vendor css -->
    <link href="<?php echo $ROOT_FOLDER;?>lib/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="<?php echo $ROOT_FOLDER;?>lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="<?php echo $ROOT_FOLDER;?>lib/jqvmap/jqvmap.min.css" rel="stylesheet">

    <!-- BEGIN: Page Level CSS-->
    <?php include("includes/css-includes.php");?>

    <!-- DashForge CSS -->
    <link rel="stylesheet" href="<?php echo $ROOT_FOLDER;?>assets/css/dashforge.css">
    <link id="dfMode" rel="stylesheet" href="<?php echo $ROOT_FOLDER;?>assets/css/skin.light.css">
    <link id="dfSkin" rel="stylesheet" href="<?php echo $ROOT_FOLDER;?>assets/css/skin.mglsd2.css">

    <link rel="stylesheet" href="<?php echo $ROOT_FOLDER;?>assets/css/custom.css">
  </head>
  <body class="">

    <aside class="aside aside-fixed">
      <div class="aside-header">
        <a href="<?php echo $ROOT_FOLDER;?>" class="aside-logo text-center">
          <img src="<?php echo $ROOT_FOLDER;?>assets/img/logo.png" height="30px;" />
        </a>
        <a href="" class="aside-menu-link">
          <i data-feather="menu"></i>
          <i data-feather="x"></i>
        </a>
      </div>
      <div class="aside-body">
        <div class="aside-loggedin">
          <div class="aside-loggedin-user">
            <a href="#loggedinMenu" class="d-flex align-items-center justify-content-between mg-b-2" data-toggle="collapse">
              <h6 class="tx-semibold mg-b-0"><?php echo $_SESSION['USER']['FULLNAME'];?></h6>
              <i data-feather="chevron-down"></i>
            </a>
            <p class="tx-color-03 tx-12 mg-b-0"><?php echo $_SESSION['USER']['USERGROUPNAME'];?></p>
          </div>
          <div class="collapse" id="loggedinMenu">
            <ul class="nav nav-aside mg-b-0">
              <li class="nav-item"><a href="<?php echo $ROOT_FOLDER;?>inbox" class="nav-link"><i data-feather="mail"></i> <span> Inbox</span></a></li>
              <li class="nav-item"><a href="" class="nav-link"><i data-feather="settings"></i> <span>Account Settings</span></a></li>
              <li class="nav-item"><a href="" class="nav-link"><i data-feather="help-circle"></i> <span>Help Center</span></a></li>
              <li class="nav-item"><a href="<?php echo $ROOT_FOLDER;?>logout" class="nav-link"><i data-feather="log-out"></i> <span>Sign Out</span></a></li>
            </ul>
          </div>
        </div><!-- aside-loggedin -->
        <?php
          include("includes/side-navigation.php");
        ?>
      </div>
    </aside>

    <div class="content ht-100v pd-0">
      <div class="content-header d-print-none">
        <div class="content-search">
          <i data-feather="search"></i>
          <input type="search" class="form-control" placeholder="Search...">
        </div>
        <nav class="nav">
          <div class="dropdown dropdown-message">
            <a href="" class="dropdown-link new-indicator" data-toggle="dropdown">
              <i data-feather="message-square"></i>
              <?php
                if(!empty($arrNotifications))
                {
              ?>
              <span><?php echo count($arrNotifications);?></span>
              <?php
                }
              ?>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
              <div class="dropdown-header">New Messages</div>
              <?php
                if(!empty($arrNotifications))
                {
                  foreach($arrNotifications as $notif)
                  {
                  ?>
                    <a href="<?php echo $ROOT_FOLDER;?>inbox/view/<?php echo $notif['message_id'];?>" class="dropdown-item">
                      <div class="media">
                        <div class="avatar"><span class="avatar-initial rounded-circle bg-indigo">
                          <?php echo substr($notif['sender'], 0, 1);?>
                        </span></div>
                        <div class="media-body mg-l-15">
                          <strong><?php echo $notif['sender'];?></strong>
                          <p><?php echo $notif['message_heading'];?></p>
                          <span><?php echo date("l, M, j, Y, g:i a", strtotime($notif['message_date']));?></span>
                        </div><!-- media-body -->
                      </div><!-- media -->
                    </a>
                  <?php
                  }
                }
              ?>

              <div class="dropdown-footer"><a href="<?php echo $ROOT_FOLDER;?>inbox">View all Messages</a></div>
            </div><!-- dropdown-menu -->
          </div><!-- dropdown -->
        </nav>
      </div><!-- content-header -->

      <?php
        include("pages/" . $displayedPage['file']);
      ?>
    </div>

    <div class="modal fade" id="composeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <form method="post" action="<?php echo $ROOT_FOLDER;?>process/modal-compose-message.php">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">New Message</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Subject:</label>
                <input type="text" class="form-control" name="message_heading" required>
                <input type="hidden" id="receiver_id" name="receiver_id">
                <input type="hidden" id="sender_id" name="sender_id">
                <input type="hidden" id="message_date" name="message_date">
              </div>
              <div class="form-group">
                <label for="message-text" class="col-form-label">Message:</label>
                <textarea class="form-control" id="message-text" name="message_body"></textarea>
              </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <input type="submit" class="btn btn-primary" value="Send" />
          </div>
          </form>
        </div>
      </div>
    </div>

    <div class="modal fade" id="modalApproveData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel4" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content tx-14">
          <div class="modal-header">
            <h6 class="modal-title" id="exampleModalLabel4">Sanction Message</h6>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="tx-center">
              <b><a data-toggle="" href="">Send a message to <span id="approval_author_name"></span></a></b>
              <div class="tx-left mg-t-5" id="">
                <form method="post" action="<?php echo $ROOT_FOLDER;?>process/modal-compose-message.php">
                  <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Subject:</label>
                    <input type="text" class="form-control" name="message_heading" id="approval_message_heading" required>
                    <input type="hidden" id="approval_receiver_id" name="receiver_id">
                    <input type="hidden" id="approval_sender_id" name="sender_id">
                    <input type="hidden" id="approval_message_date" name="message_date">
                  </div>
                  <div class="form-group">
                    <label for="message-text" class="col-form-label">Message:</label>
                    <textarea class="form-control" id="message-text" name="message_body"></textarea>
                  </div>
                  <input type="submit" class="btn btn-primary" value="Send" />
                </form>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary tx-13" data-dismiss="modal">Close</button>
            
          </div>
        </div>
      </div>
    </div>

    <script src="<?php echo $ROOT_FOLDER;?>lib/jquery/jquery.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/jqueryui/jquery-ui.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/feather-icons/feather.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    
    <script src="<?php echo $ROOT_FOLDER;?>lib/chart.js/Chart.bundle.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/jqvmap/jquery.vmap.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/jqvmap/maps/jquery.vmap.usa.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/select2/js/select2.min.js"></script>


    <!-- BEGIN PAGE LEVEL JS-->
    <?php include("includes/javascript-includes.php");?>

    <script src="<?php echo $ROOT_FOLDER;?>assets/js/dashforge.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>assets/js/dashforge.aside.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>assets/js/dashforge.sampledata.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/parsleyjs/parsley.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>assets/js/moment.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>assets/js/ajax.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>assets/js/custom.js"></script>
  </body>
</html>
<?php
}
else
{
?>
<!DOCTYPE html>
<html lang="en">
  <head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $ROOT_FOLDER;?>assets/img/icon.png">

    <title>iMIS: ICOLEW MANAGMENT INFORMATION SYSTEM</title>

    <!-- vendor css -->
    <link href="<?php echo $ROOT_FOLDER;?>lib/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="<?php echo $ROOT_FOLDER;?>lib/ionicons/css/ionicons.min.css" rel="stylesheet">

    <!-- DashForge CSS -->
    <link rel="stylesheet" href="<?php echo $ROOT_FOLDER;?>assets/css/dashforge.css">
    <link rel="stylesheet" href="<?php echo $ROOT_FOLDER;?>assets/css/dashforge.auth.css">
  </head>
  <body style="background-image: url('<?php echo $ROOT_FOLDER;?>assets/img/front31.jpg'); opacity: 0.9;">
    <div class="content content-fixed content-auth" >
      <div class="container">
        <div class="media align-items-stretch justify-content-center ht-100p pos-relative">
          <div class="media-body align-items-center d-none d-lg-flex">
            <div class="pos-absolutex b-0 l-0 tx-12 tx-center">
              <div class="row">
                <div class="col-sm-6 col-lg-6"  style="padding: 10px;">
                  <div class="card card-body">
                    <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Beneficiary Enrollment</h6>
                    <div class="d-flex d-lg-block d-xl-flex align-items-end">
                      <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">81%</h3>
                      <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">32% <i class="icon ion-md-arrow-up"></i></span></p>
                    </div>
                    <div class="chart-three">
                        <div id="flotChart3" class="flot-chart ht-30"></div>
                      </div><!-- chart-three -->
                  </div>
                </div><!-- col -->
                <div class="col-sm-6 col-lg-6 mg-t-10 mg-sm-t-0"  style="padding: 10px;">
                  <div class="card card-body">
                    <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Number of Beneficiaries</h6>
                    <div class="d-flex d-lg-block d-xl-flex align-items-end">
                      <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">537</h3>
                      <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-danger">27% </i></span></p>
                    </div>
                    <div class="chart-three">
                        <div id="flotChart4" class="flot-chart ht-30"></div>
                      </div><!-- chart-three -->
                  </div>
                </div><!-- col -->
                <div class="col-sm-6 col-lg-6 mg-t-10 mg-lg-t-0"  style="padding: 10px;">
                  <div class="card card-body">
                    <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">No. of CEGs</h6>
                    <div class="d-flex d-lg-block d-xl-flex align-items-end">
                      <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">63</h3>
                      <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">43% <i class="icon ion-md-arrow-up"></i></span></p>
                    </div>
                    <div class="chart-three">
                        <div id="flotChart5" class="flot-chart ht-30"></div>
                      </div><!-- chart-three -->
                  </div>
                </div><!-- col -->
                <div class="col-sm-6 col-lg-6 mg-t-10 mg-lg-t-0" style="padding: 10px;">
                  <div class="card card-body">
                    <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">No. of CLCs</h6>
                    <div class="d-flex d-lg-block d-xl-flex align-items-end">
                      <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">17</h3>
                      <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">2.1% <i class="icon ion-md-arrow-up"></i></span></p>
                    </div>
                    <div class="chart-three">
                        <div id="flotChart6" class="flot-chart ht-30"></div>
                      </div><!-- chart-three -->
                  </div>
                </div><!-- col -->
              </div>
            </div>
          </div><!-- media-body -->
          <div class="sign-wrapper mg-lg-l-50 mg-xl-l-60" style="background-color: #E1E1E1; opacity: 1; padding: 15px;">
            <form method="post" action="<?php echo $ROOT_FOLDER;?>process/login.php">
              <div class="wd-100p">
                <div class="text-center">
                  <img src="<?php echo $ROOT_FOLDER;?>assets/img/login-label.fw.png" class="img-fluidX" height="70px" alt="">
                </div>
                <h3 class="tx-color-01 mg-b-5">Sign In</h3>
                <p class="tx-color-01 tx-16 mg-b-40">Welcome to iMIS! Please signin to continue.</p>

                <div class="form-group">
                  <label>Email address</label>
                  <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                  <div class="d-flex justify-content-between mg-b-5">
                    <label class="mg-b-0-f">Password</label>
                  </div>
                  <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                  <div class="text-right">
                    <a href="" class="tx-13">Forgot password?</a>
                  </div>
                </div>
                <button class="btn btn-brand-02 btn-block">Sign In</button>
                <div style="padding: 3px; color: red;">
                  <?php 
                    if(isset($_SESSION['loginMessage'])) 
                      echo $_SESSION['loginMessage'];
                    unset($_SESSION['loginMessage']);
                  ?>
                  </div>
              </div>
            </form>
          </div><!-- sign-wrapper -->
        </div><!-- media -->
      </div><!-- container -->
    </div><!-- content -->

    <footer class="footer">
      <div>
        <span>&copy; <?php echo date("Y");?> iMIS: ICOLEW MANAGEMENT INFORMATION SYSTEM. v1.0.0. </span>
      </div>
    </footer>

    <script src="<?php echo $ROOT_FOLDER;?>lib/jquery/jquery.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $ROOT_FOLDER;?>lib/feather-icons/feather.min.js"></script>

    <!--<script src="<?php echo $ROOT_FOLDER;?>assets/js/dashforge.js"></script>-->

  </body>
</html>

<?php
}
?>