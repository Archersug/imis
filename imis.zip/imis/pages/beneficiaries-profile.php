<?php
  $arrBen = dbGetBeneficiary($displayedPage['item']);
  //print_r($arrBen);
  $options = array("ceg_id" => $arrBen['ceg_id']);
  $arrCeg = dbGetCegs($options);
  $arrComps = dbGetAllComponents();
  $arrActivities = dbGetCegActivities($displayedPage['item']);
  $arrBeneficiaries = dbGetBeneficiaries($options);
  $arrVillage = dbGetVillageFromId($arrBen['village_id']);
  $arrVSLA = dbGetVSLA($options);
  $arrVSLALoans = dbGetBeneficiaryLoans($displayedPage['item']);
?>

<div class="content-body">
  <div class="container pd-x-0 tx-13">
    <div class="media d-block d-lg-flex">
      <div class="profile-sidebar profile-sidebar-two pd-lg-r-15">

        <div class="row">
          <div class="col-sm-3 col-md-2 col-lg">
            <div class="avatar avatar-xxl avatar-online">
              <img src="<?php echo $ROOT_FOLDER;?>assets/img/beneficiaries/<?php echo $arrBen['beneficiary_picture'];?>" class="rounded-circle" alt="">
            </div>
          </div><!-- col -->
        </div>
        <div class="row">
          <div class="col-sm-8 col-md-7 col-lg mg-t-20 mg-sm-t-0 mg-lg-t-25">
            <h4 class="mg-b-2 tx-spacing--1"><?php echo $arrBen['beneficiary_name'];?></h4>
            <p class="tx-color-03 mg-b-25"><?php echo $arrBen['position_name'] . " of " . $arrBen['ceg_name'] . " (".$arrBen['ceg_code'].")";?></p>
          </div><!-- col -->
        </div>
        <div class="row">
          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <label class="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">Bio Data</label>
            <ul class="list-inline list-inline-skills">
              <li class="list-inline-item"><a><?php echo $arrBen['beneficiary_gender'];?></a></li>
              <li class="list-inline-item"><a><?php echo calculateAgeFromDate($arrBen['beneficiary_dob']);?>yrs</a></li>
              <li class="list-inline-item"><a href=""><?php echo $arrBen['marital_status'];?></a></li>
              <li class="list-inline-item"><a href=""><?php echo ($arrBen['beneficiary_disabled']==1)? 'DISABLED':'ABLE-BODIED';?></a></li>
              
            </ul>
          </div><!-- col -->
        </div>
        <div class="row">
          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <label class="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">Contact Information</label>
            <ul class="list-unstyled profile-info-list">
              <li><i data-feather="map-pin"></i> <?php echo $arrVillage;?></li>
              <li><i data-feather="phone"></i> <?php echo $arrBen['beneficiary_phone'];?></li>
              
            </ul>
          </div><!-- col -->
        </div>

        <div class="row">
          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <div class="d-flex mg-b-25">
              <a href="<?php echo $ROOT_FOLDER . "beneficiaries/edit/" . $displayedPage['item'];?>" class="btn btn-xs btn-success flex-fill mg-l-10">Edit Beneficiary</a>
            </div>
          </div><!-- col -->
          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <div class="d-flex mg-b-25">
              <a href="#" class="btn btn-xs btn-dark flex-fill mg-l-10">Drop Out</a>
            </div>
          </div><!-- col -->
        </div>

        

      </div><!-- profile-sidebar -->
      <div class="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">


        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Components</h6>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <div class="media d-block d-sm-flex">
              
                <div class="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                <h5 class="mg-b-5">Component Progress</h5>
                <span class="d-block tx-13 tx-color-03">December 2020</span>

                <table class="table">
                  <tbody>
                    <?php
                      $i = 1;
                      $arrProg = dbGetComponentProgress($displayedPage['item']);
                      
                      foreach($arrComps as $comp)
                      {
                        $arrCompUnits = dbGetComponentUnits($comp['component_id']);
                        $arrCompleteUnits = dbGetCompleteComponentUnits($comp['component_id'], $arrBen['ceg_id']);
                        //print_r($arrCompUnits);
                        $unitsNumber = count($arrCompUnits);
                        $unitsComplete = count($arrCompleteUnits);
                        foreach($arrCompUnits as $unit)
                        {
                          if($unit['unit_id'] == 'COMPLETE')
                            $unitsComplete += 1;
                        }
                        $unitPercent = round(($unitsComplete/$unitsNumber) * 100);
                    ?>
                    <tr>
                      <th class="wd-5p" scope="row"><?php echo $i;?></th>
                      <td><?php echo $comp['component_name'] . " (".$comp['component_abbr'].")";?>
                        <div class="progress ht-20">
                          <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $unitPercent;?>%" aria-valuenow="<?php echo $unitPercent;?>" aria-valuemin="0" aria-valuemax="100"><?php echo $unitPercent;?>%</div>
                           <!-- <div class="progress-bar bg-warning wd-60p" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div> -->
                        </div>
                      </td>
                    </tr>
                    <?php
                        $i++; 
                      }
                    ?>
                  </tbody>
                </table>
              </div>
              
            </div><!-- media -->
          </div>
          <div class="card-body pd-25">
            <div class="media d-block d-sm-flex">
                            
                <div class="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                <h5 class="mg-b-5">Exam Results</h5>
                <span class="d-block tx-13 tx-color-03"></span>

                <table class="table table-bordered mg-b-0">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Component</th>
                  <th scope="col">Exam 1</th>
                  <th scope="col">Exam 2</th>
                  <th scope="col">Exam 3</th>
                  <th scope="col">TOTAL</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  $i = 1;
                  foreach($arrComps as $comp)
                  {
                  ?>
                    <tr>
                      <th scope="row"><?php echo $i;?></th>
                      <td><?php echo $comp['component_name'];?></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                  <?php
                    $i++;
                  }
                ?>

              </tbody>
            </table>
              </div>
              
            </div><!-- media -->
          </div>
        </div><!-- card -->

        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Activities</h6>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <?php
              if(!empty($arrActivities))
              {
                foreach($arrActivities as $activity)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="slack" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $activity['activity_name'];?></h6>
                          <p class="tx-12 mg-b-10">STARTED: <?php echo $activity['start_date'];?>, <?php if(!is_null($activity['enterprise_id'])) echo "ENTERPRISE: " . $activity['enterprise_name'];?>
                          <?php if(!is_null($activity['description'])) echo "<br/>" . nl2br(substr($activity['description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
            
          </div>
        </div><!-- card -->

        <?php
          if(!empty($arrVSLA))
          {
        ?>
        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">VSLA Savings</h6>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <div class="media">
                  <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                    <i data-feather="github" class="tx-white-7 wd-20 ht-20"></i>
                  </div>
                  <div class="media-body pd-l-15">
                    <h6 class="tx-color-01 mg-b-5"><?php echo $arrVSLA['vsla_name'];?></h6>
                    <p class="tx-12 mg-b-10">Share Price: UGX <?php echo $arrVSLA['share_price'];?> | Regularity: <?php echo $arrVSLA['contribution_period'];?></p>
                  </div>
                </div><!-- media -->
              </div>
            </div>
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Date</th>
                      <th scope="col">Amount</th>
                      <th scope="col">Total Savings</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                        $averageContrib = 0;
                        $totalContrib = 0;
                        $totalSavings = 0;
                      if(!empty($arrBen['contributions']))
                      {
                        $i = 1;
                        
                        foreach($arrBen['contributions'] as $contrib)
                        {
                          $totalSavings = $totalSavings + $contrib['contribution_amount'];
                        ?>
                          <tr>
                            <th scope="row"><?php echo $i;?></th>
                            <td><?php echo $contrib['contribution_date'];?></td>
                            <td>UGX <?php echo number_format($contrib['contribution_amount']);?></td>
                            <td>UGX <?php echo number_format($totalSavings);?></td>
                          </tr>
                        <?php
                          $totalContrib = $totalContrib + $contrib['contribution_amount'];
                          
                          $i++;
                        }
                        $averageContrib = $totalContrib / count($arrBen['contributions']);
                      }
                    ?>
 
                  </tbody>
                  <tfoot>
                    <tr>
                      <th scope="col"></th>
                      <th scope="col"></th>
                      <th scope="col">Average: UGX <?php echo number_format($averageContrib);?></th>
                      <th scope="col">Total: UGX <?php echo number_format($totalSavings);?></th>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div><!-- card -->

        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">VSLA Loans</h6>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <div class="media">
                  <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                    <i data-feather="star" class="tx-white-7 wd-20 ht-20"></i>
                  </div>
                  <div class="media-body pd-l-15">
                    <h6 class="tx-color-01 mg-b-5"><?php echo $arrVSLA['vsla_name'];?></h6>
                    <p class="tx-12 mg-b-10">Share Price: UGX <?php echo $arrVSLA['share_price'];?> | Regularity: <?php echo $arrVSLA['contribution_period'];?></p>
                  </div>
                </div><!-- media -->
              </div>
            </div>
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <table class="table table-striped datatable-small">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Loan Title</th>
                      <th scope="col">Beneficiary</th>
                      <th scope="col">Principal</th>
                      <th scope="col">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      if(!empty($arrVSLALoans))
                      {
                        $i = 1;
                        foreach($arrVSLALoans as $loan)
                        {
                        ?>
                          <tr>
                            <td scope="row"><?php echo $i;?></td>
                            <td>
                              <b><a href="#" data-toggle="modal" data-target="#modalLoanDetails" data-loan-id="<?php echo $loan['loan_id'];?>">
                                <?php echo $loan['loan_title'];?></a></b><br/>
                              <?php echo $loan['loan_description'];?>
                              </td>
                            <td><?php echo $loan['beneficiary_name'];?></td>
                            <td><?php echo number_format($loan['principal']);?></td>
                            <td><?php echo $loan['loan_status'];?></td>
                          </tr>
                        <?php
                          $i++;
                        }
                      }
                    ?>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div><!-- card -->
        <?php
          }
        ?>

      </div><!-- media-body -->

    </div><!-- media -->
  </div><!-- container -->
</div><!-- content-body -->