<?php
  $options = array('budget_id' => $displayedPage['item']);
  $arrBudget = dbGetBudgetDetails($options);
?>

<div class="content-body tx-13">
  <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
    <!-- Alert User -->
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>
    <div class="row">
      <div class="col-sm-6 col-lg-6 mg-t-40">
        <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Budget Details</label>
        <ul class="list-unstyled lh-7">
          <li class="d-flex">
            <span><b>Budget Name: </b></span>
            <span style="padding-left: 10px"> <?php echo $arrBudget[0]['budget_name'];?></span>
          </li>
          <li class="d-flex">
            <span><b>Budget Description: </b></span>
            <span style="padding-left: 10px"><?php echo $arrBudget[0]['budget_description'];?></span>
          </li>
          <li class="d-flex">
            <span><b>Budget Category: </b></span>
            <span style="padding-left: 10px"><?php echo $arrBudget[0]['category_name'];?></span>
          </li>
          <li class="d-flex">
            <span><b>Budget Date: </b></span>
            <span style="padding-left: 10px"><?php echo $arrBudget[0]['budget_date'];?></span>
          </li>
          <li class="d-flex">
            <span><b>Subcounty: </b></span>
            <span style="padding-left: 10px"><?php echo $arrBudget[0]['subcounty_name'] . " (".$arrBudget[0]['district_name']." District)";?></span>
          </li>
        </ul>
      </div><!-- col -->
    </div><!-- row -->

    <div class="table-responsive mg-t-40">
      <table class="table table-invoice bd-b table-striped">
        <thead>
          <tr>
            <th class="tx-right"></th>
            <th class="wd-5p">#</th>
            <th class="wd-30p">Item</th>
            <th class="wd-40p d-none d-sm-table-cell">Description</th>
            <th class="tx-center">Quantity</th>
            <th class="tx-right">Unit Price</th>
            <th class="tx-right">Amount</th>
            
          </tr>
        </thead>
        <tbody>
          <?php
            if(!empty($arrBudget))
            {
              $i = 1;
              $totalAmount = 0;
              if(!empty($arrBudget['details']))
              {
                foreach($arrBudget['details'] as $item)
                {
                ?>
                <tr>
                  <td class="tx-right">
                    <a href="<?php echo $ROOT_FOLDER ."budgets/delete-detail/" . $displayedPage['item'] . "-" . $item['detail_id'];?>" class="confirm-delete">x</a>
                  </td>
                  <td class="tx-nowrap"><?php echo $i;?></td>
                  <td class="tx-nowrap"><?php echo $item['detail_name'];?></td>
                  <td class="d-none d-sm-table-cell tx-color-03"><?php echo $item['detail_description'];?></td>
                  <td class="tx-center"><?php echo $item['detail_quantity'];?></td>
                  <td class="tx-right"><?php echo number_format($item['detail_price']);?></td>
                  <td class="tx-right"><?php echo number_format($item['detail_amount']);?></td>

                </tr>
                <?php
                  $totalAmount += $item['detail_amount'];
                  $i++;
                }
              }
            }
          ?>
        </tbody>
      </table>
    </div>

    <div class="row justify-content-between">
      <div class="col-sm-6 col-lg-6 order-2 order-sm-0 mg-t-40 mg-sm-t-0">
        
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 order-1 order-sm-0">
        <ul class="list-unstyled lh-7 pd-r-10">
          <li class="d-flex justify-content-between">
            <strong>Total </strong>
            <strong><?php echo number_format($totalAmount);?></strong>
          </li>
        </ul>

        <button class="btn btn-block btn-outline-success" data-toggle="modal" data-target="#modalBudgetItem">Add Item</button>
        <a href="<?php echo $ROOT_FOLDER;?>budgets/edit-budget/<?php echo $displayedPage['item'];?>" class="btn btn-block btn-outline-primary">Edit Budget</a>
        <a href="<?php echo $ROOT_FOLDER;?>budgets/delete/<?php echo $displayedPage['item'];?>" class="btn btn-block btn-outline-danger confirm-delete">Delete Budget</a>
      </div><!-- col -->
    </div><!-- row -->
  </div><!-- container -->
</div><!-- content -->

<!-- Modal -->
<div class="modal fade" id="modalBudgetItem" tabindex="-1" role="dialog" aria-labelledby="modalBudgetItemTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-budget-edit-details.php" method="post">
        <input type="hidden" name="budget_id" value="<?php echo $displayedPage['item'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Budget Item</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="detail_name">Item</label>
            <input type="text" class="form-control" value="" name="detail_name" placeholder="Item" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-9">
            <label for="detail_description">Description</label>
            <input type="text" class="form-control" value="" name="detail_description" placeholder="Description">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-3">
            <label for="detail_quantity">Quantity</label>
            <input type="number" class="form-control" value="" name="detail_quantity" placeholder="">
          </div>
          <div class="form-group col-md-3">
            <label for="detail_price">Price</label>
            <input type="number" class="form-control" value="" name="detail_price" placeholder="">
          </div>
          <div class="form-group col-md-3">
            <label for="detail_amount">Amount</label>
            <input type="number" class="form-control" value="" name="detail_amount" placeholder="" required>
          </div>
        </div> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>
