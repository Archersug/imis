<?php
  $arrRegions = dbGetAllRegions();
  $arrCounty = dbGetSubcounty($displayedPage['item']);
  $arrRegions = dbGetAllRegions();
  $arrSubregions = dbGetAllSubregions();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Locations</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Edit Subcounty</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Edit Subcounty" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/subcounties-edit.php" method="post" data-parsley-validate>
            <input type="hidden" name="subcounty_id" value="<?php echo $displayedPage['item'];?>">
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="subcounty_name">Name</label>
                <input type="text" class="form-control" id="subcounty_name" name="subcounty_name" placeholder="County Name" value="<?php echo $arrCounty['subcounty_name'];?>" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="region_id">Region</label>
                <select class="custom-select dependable-select" data-initiates="sel-subregions" data-list="regions">
                  <option value="" selected> </option>
                  <?php
                    foreach($arrRegions as $region)
                    {
                  ?>
                  <option value="<?php echo $region['region_id'];?>">
                    <?php echo $region['region_name'];?>
                  </option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="subregion_id">Subregion</label>
                <select class="custom-select dependable-select" data-initiates="sel-districts" data-list="subregions" id="sel-subregions">
                  <option value="" selected> </option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="subregion_id">District</label>
                <select class="custom-select" id="sel-districts" name="district_id" required>
                  <option value="<?php echo $arrCounty['district_id'];?>" selected> <?php echo $arrCounty['district_name'];?> </option>
                </select>
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>