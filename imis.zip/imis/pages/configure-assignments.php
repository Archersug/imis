<?php
  $arrUsers = dbGetUsers();
  $arrDistricts = dbGetAllDistricts();

?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Project Settings</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Configure Assignments</h4>
      </div>
    </div>
        <!-- Alert User -->
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>
    <div class="row row-xs" style="margin-bottom: 20px;">
      <div class="col-sm-12 col-lg-12">
        <div data-label="" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/configure-assignments.php" method="post" data-parsley-validate>
            <label class="d-block">Use this tool to assign locations to users whose duties are specific to particular districts, subcounties or villages. When they log in, they will only have access to the data in these assigned locations. The districts, subcounties and villages assigned here are what will appear in the various dropdown menus for the users. <b>Changes will take effect when a user logs in after this assignment</b></label>
            <fieldset class="form-fieldset">
              <legend>User</legend>
              <div class="form-row">
                <div class="form-group col-md-9">
                  <label class="d-block">Select the User for assignment</label>
                  <div class="custom-control custom-checkbox">
                    <select class="form-control select2" id="sel-user-assignments" name="user_id" required>
                      <option></option>
                    <?php
                      if(!empty($arrUsers))
                      {
                        foreach($arrUsers as $user)
                        {
                          if($user['usergroup_id'] > 5)
                          {
                        ?>
                          <option value="<?php echo $user['user_id'];?>"><?php echo $user['fullname'];?></option>
                        <?php
                          }
                        }
                      }
                    ?>
                    </select>
                  </div>
                </div>
              </div>
            </fieldset>
            <fieldset class="form-fieldset">
              <legend>Current Assignments</legend>
              <div class="form-row">
                <div class="form-group col-md-12" id="div-assigned" style="white-space: pre-line;">
                  
                </div>
              </div>
            </fieldset>
            <fieldset class="form-fieldset">
              <legend>Districts</legend>
              <label class="d-block">Select district to assign to user</label>
              <div class="form-row">
                <div class="form-group col-md-3">
                  <?php
                    $divide = count($arrDistricts) / 3;
                    $i = 1;
                    foreach($arrDistricts as $district)
                    {
                      $checked = '';
                      /*if($group['usergroup_id'] > 5)
                      {
                        $checked = '';
                        if(!empty($arrApprovals))
                        {
                          foreach($arrApprovals as $approve)
                          {
                            if($approve['usergroup_id'] == $group['usergroup_id'] && $approve['level'] == '2')
                            {
                              $checked = ' checked';
                              break;
                            }
                            else
                              $checked = '';
                          }
                        }*/
                        
                    ?>
                      <!-- <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="district-<?php echo $district['district_id'];?>" name="districts[<?php echo $district['district_id'];?>]"<?php echo $checked;?>>
                        <label class="custom-control-label" for="district-<?php echo $district['district_id'];?>"><?php echo ucfirst(strtolower($district['district_name']));?></label>
                      </div> -->

                      <div class="custom-control custom-radio">
                        <input type="radio" id="district-<?php echo $district['district_id'];?>" name="district_id" class="custom-control-input dependable-radio" data-initiates="sel-subcounties" data-list="districts" value="<?php echo $district['district_id'];?>" required>
                        <label class="custom-control-label" for="district-<?php echo $district['district_id'];?>"><?php echo ucfirst(strtolower($district['district_name']));?></label>
                      </div>
                    <?php
                      //}
                    $i++;
                    if($i == $divide)
                    {
                      $i = 1;
                    ?>
                  </div>
                  <div class="form-group col-md-3">
                    <?php
                    }
                    }
                  ?>
                  
                </div>
              </div>
            </fieldset>
            <fieldset class="form-fieldset">
              <legend>Subcounties</legend>
              <label class="d-block">Select subcounties to assign to user</label>
              <div class="form-row">
                <div class="form-group col-md-6" id="sel-subcounties">
                  
                </div>
              </div>
            </fieldset>
            <fieldset class="form-fieldset">
              <legend>Parishes</legend>
              <label class="d-block ">Select parishes to assign to user</label>
              <div class="form-row">
                <div class="form-group col-md-6" id="check-parishes">
                  
                </div>
              </div>
            </fieldset>
            <fieldset class="form-fieldset">
              <legend>CLCs</legend>
              <label class="d-block ">Select CLCs to assign to user</label>
              <div class="form-row">
                <div class="form-group col-md-6" id="check-clcs">
                  
                </div>
              </div>
            </fieldset>
            <fieldset class="form-fieldset">
              <legend>Villages</legend>
              <label class="d-block ">Select villages to assign to user</label>
              <div class="form-row">
                <div class="form-group col-md-6" id="check-villages">
                  
                </div>
              </div>
            </fieldset>
            <fieldset class="form-fieldset">
              <legend>CEGs</legend>
              <label class="d-block ">Select CEGs to assign to user</label>
              <div class="form-row">
                <div class="form-group col-md-6" id="check-cegs">
                  
                </div>
              </div>
            </fieldset>
             <div class="form-row">
                <div class="form-group col-md-8">
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
              </div>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>