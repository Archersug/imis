<?php
  $arrDistricts = dbGetAllDistricts();
  $arrCategories = dbGetBudgetCategories();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Finance</a></li>
            <li class="breadcrumb-item active" aria-current="page">Expenses</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Add Expense</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Add Expense" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/expenses-add.php" method="post" data-parsley-validate>
            <input type="hidden" name="date_entered" value="<?php echo date("Y-m-d");?>">
            <input type="hidden" name="user_id" value="<?php echo $_SESSION['USER']['ICOLEW_USERID'];?>">
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="region_id">Category</label>
                <select class="custom-select" name="category_id" required>
                  <option value="" selected> </option>
                  <?php
                    foreach($arrCategories as $cat)
                    {
                  ?>
                  <option value="<?php echo $cat['category_id'];?>">
                    <?php echo $cat['category_name'];?>
                  </option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="region_id">District</label>
                <select class="custom-select select2 dependable-select" data-initiates="sel-subcounties" data-list="districts" name="district_id" required>
                  <option value="" selected> </option>
                  <?php
                    foreach($arrDistricts as $district)
                    {
                  ?>
                  <option value="<?php echo $district['district_id'];?>">
                    <?php echo ucfirst(strtolower($district['district_name']));?>
                  </option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="region_id">Subcounty</label>
                <select class="custom-select" name="subcounty_id" id="sel-subcounties">
                  <option value="" selected> </option>
                  <?php
                    foreach($arrRegions as $region)
                    {
                  ?>
                  <option value="<?php echo $region['region_id'];?>">
                    <?php echo $region['region_name'];?>
                  </option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="expense_name">Name</label>
                <input type="text" class="form-control" value="" name="expense_name" placeholder="Expense Name" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-9">
                <label for="expense_description">Description</label>
                <input type="text" class="form-control" id="expense_description" value="" name="expense_description" placeholder="Expense Description" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-3">
                <label for="expense_name">Date</label>
                <input type="text" class="form-control" value="" name="expense_date" id="datepicker-date" required>
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Add</button>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>
