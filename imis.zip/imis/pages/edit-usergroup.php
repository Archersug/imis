<?php
   $qUsergroup = "SELECT tbl_usergroups.*
                   FROM tbl_usergroups
                   WHERE tbl_usergroups.usergroup_id = " . $displayedPage['item'] ."
                   ";
   $arrUsergroup = $db->QuerySingleRowArray($qUsergroup, MYSQLI_ASSOC);

   // Retrieve all menu categories from db
  $qCats = "SELECT tbl_menu_categories.*
            FROM tbl_menu_categories
            ORDER BY tbl_menu_categories.cat_position
            ";
  $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);

   // Retrieve all menu items
  $qItems = "SELECT tbl_menu_items.*
             FROM tbl_menu_items
             ORDER BY tbl_menu_items.item_position
             ";
  $arrItems = $db->QueryArray($qItems, MYSQLI_ASSOC);

  // Retrieve usergroup permissions
  $qPermissions = "SELECT tbl_user_permissions.item_id
                   FROM tbl_user_permissions
                   WHERE tbl_user_permissions.usergroup_id = " . $displayedPage['item'] . "
                   ";
   $arrPermissions = $db->QueryArray($qPermissions, MYSQLI_ASSOC);
   $arrPermittedPages = array();
   if(!empty($arrPermissions))
   {
      foreach($arrPermissions as $perm)
      {
         $arrPermittedPages[] = $perm['item_id'];
      }
   }
   

?>
<div id="main">
   <div class="row">
     <div class="content-wrapper-before <?php echo $TEMPLATE_COLOR;?>"></div>
     <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
       <!-- Search for small screen-->
       <div class="container">
         <div class="row">
           <div class="col s10 m6 l6">
             <h5 class="breadcrumbs-title mt-0 mb-0">Edit Usergroup</h5>
             <ol class="breadcrumbs mb-0">
               <li class="breadcrumb-item"><a href="">Home</a>
               </li>
               <li class="breadcrumb-item"><a href="#">Users</a>
               </li>
               <li class="breadcrumb-item"><a>Edit Usergoup</a>
               </li>
             </ol>
           </div>
         </div>
       </div>
     </div>
     <div class="col s12">
      <div class="container">
        <div class="section section-data-tables">
          <div class="card">
            <div class="card-content">
              <p class="caption mb-0">Editing Usergroup: <?php echo $arrUsergroup['usergroup_name'];?></p>
            </div>
          </div>

          <div class="col s12 m12 l12">
         <div class="row">
         <div class="card">
            <div class="card-content">
               <form method="post" action="../../app-process/usergroups.php">
                  <div class="row">
                    <div class="input-field col s12">
                      <input type="hidden" name="hid-item" value="<?php echo $arrUsergroup['usergroup_id'];?>">
                      <input type="text" id="text-group-name" name="text-group-name" value="<?php echo $arrUsergroup['usergroup_name'];?>">
                      <label for="fn">Usergroup Name</label>
                    </div>
                  </div>
                  <br>
                  <div class="row">
                     <div class="col s12 m6 l6" style="border-right: 1px solid #e1e1e1;">
                        <h6>Select the pages that this usergoup will have access to:</h6>
                     <?php
                        if(!empty($arrCats))
                        {
                           foreach($arrCats as $cat)
                           {
                              echo '<b>' . $cat['cat_name'] .'</b>';
                              if(!empty($arrItems))
                              {
                                 foreach($arrItems as $item)
                                 {
                                    if($cat['cat_id'] == $item['item_category'])
                                    {
                                    ?>
                                    <p>
                                      <label>
                                        <input type="checkbox" name="check-permissions[]" value="<?php echo $item['item_id'];?>" class="filled-in"<?php echo in_array($item['item_id'], $arrPermittedPages)? ' checked="checked"':'';?> />
                                        <span><?php echo $item['item_name'];?></span>
                                      </label>
                                    </p>
                                    <?php
                                    }
                                 }
                                 echo '<hr><br>';
                              }
                           }
                        }
                     ?>
                  </div>
                  <div class="col s12 m6 l6">
                     <h6>Select the payment approval level for this group:</h6>
                     <p>
                       <label>
                         <input name="rad-approval-level" value="0" type="radio"<?php echo ($arrUsergroup['approval_level']==0)? ' checked':'';?> />
                         <span>Level 0 (Cannot approve)</span>
                       </label>
                     </p>
                     <p>
                       <label>
                         <input name="rad-approval-level" value="1" type="radio"<?php echo ($arrUsergroup['approval_level']==1)? ' checked':'';?> />
                         <span>Level 1</span>
                       </label>
                     </p>
                     <p>
                       <label>
                         <input value="2" name="rad-approval-level" type="radio"<?php echo ($arrUsergroup['approval_level']==2)? ' checked':'';?> />
                         <span>Level 2</span>
                       </label>
                     </p>
                  </div>
                  <br><br><br>
                  <div class="col s12 m6 l6">
                     <h6>Can this usergroup effect payments?</h6>
                     <p>
                       <label>
                         <input name="rad-make-payment" value="0" type="radio"<?php echo ($arrUsergroup['makes_payments']==0)? ' checked':'';?> />
                         <span>No</span>
                       </label>
                     </p>
                     <p>
                       <label>
                         <input name="rad-make-payment" value="1" type="radio"<?php echo ($arrUsergroup['makes_payments']==1)? ' checked':'';?> />
                         <span>Yes</span>
                       </label>
                     </p>
                  </div>
                  </div>
                  <div class="row">
                   <div class="input-field col s12">
                     <button name="btn-edit-usergroup" class="btn green waves-effect waves-light" type="submit" name="action">Save 
                     </button>
                   </div>
                 </div>
               </form>
            </div>
         </div>
      </div>
       </div>
       </div>
    </div>
      
   </div>
   </div>
</div>
