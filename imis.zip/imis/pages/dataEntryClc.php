<?php
  /*$options = array("clc_id" => $displayedPage['item']);
  $arrClc = dbGetCLCs($options);
  $arrPartnerships = dbGetAllCLCPartnerships($options);
  $arrServicesOffered = dbGetAllCLCServicesOffered($options);
  $arrGroups = dbGetCLCGroups($displayedPage['item']);
  $arrParish = dbGetParishFromId($arrClc[0]['parish_id']);
  $arrServices = dbGetAllCLCServices();
  $currentQuarter = dbGetCurrentQuarter();
   $options2 = array('quarter_id' => $currentQuarter[0]['quarter_id'], 'clc_id' => $displayedPage['item']);
  $arrUsers = dbGetCLCUsers($options2);
  $arrPartners = dbGetPartners();*/
  if(isset($_SESSION['USER']['ASSIGNMENTS']['locations']))
  {
    $options = array('group_id' => '1');
    $arrCourses = dbGetTrainingCourses($options);
    $arrQuarters = dbGetCurrentQuarter();

    $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['districts']);
    $arrDistricts = dbGetUserDistrict($options);

    $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['subcounties']);
    $arrSubcounties = dbGetUserSubcounties($options); 

    $options2 = array(
                'quarter_id' => $arrQuarters[0]['quarter_id'], 
                'subcounty_id' => $_SESSION['USER']['ASSIGNMENTS']['locations']['subcounties']
              );
    $arrTrained = dbGetFacilitatorsTrained($options2);
	$arrFacilitators=dbGetAllFacilitators($options);
  }
  
  
  
//---- facilitator Quarterly Reportings------------

?>


<div class="content-body">
  <div class="container pd-x-0 tx-13">
  <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Data Entry</a></li>
            <li class="breadcrumb-item active" aria-current="page">Facilitators</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Facilitator Data Entry</h4>
      </div>
    </div>
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
	   if(isset($_SESSION['USER']['ASSIGNMENTS']['locations']))
      {
    ?>
    <div class="media d-block d-lg-flex">
      
      <div class="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">


        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Facilitator Training</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalServices"><i data-feather="plus"></i> New Entry</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
          <!-----------Facilitator Training-->
          <div class="row row-xs" style="margin-bottom: 10px;">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Entered Data" class="df-example demo-table">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">District</th>
                <th scope="col" rowspan="2">Subcounty</th>
                <th scope="col" rowspan="2">Course</th>
                <th scope="col" rowspan="2">No. Trained</th>
              </tr>
              <tr>
                <th scope="col">L1</th>
                <th scope="col">L2</th>
                <th scope="col">L3</th>
              </tr>
            </thead>
            <tbody>
              <?php
                if(!empty($arrTrained))
                {
                  $i = 1;
                  foreach($arrTrained as $trained)
                  {
                  ?>
                    <tr>
                      <th scope="row"><?php echo $i;?></th>
                      <td><?php echo $trained['district_name'];?></td>
                      <td><?php echo $trained['subcounty_name'];?></td>
                      <td><?php echo $trained['course_name'];?></td>
                      <td><?php echo $trained['attended'];?></td>
                      <td>
                        <?php
                          if($trained['level1'])
                          {
                        ?>
                        <i data-feather="check-circle" class="feather-16"></i></td>
                        <?php
                          }
                          else
                          {
                          ?>
                          <i data-feather="more-horizontal" class="feather-16"></i>
                          <?php
                          }
                        ?>
                      <td>
                        <?php
                          if($trained['level2'])
                          {
                        ?>
                        <i data-feather="check-circle" class="feather-16"></i></td>
                        <?php
                          }
                          else
                          {
                          ?>
                          <i data-feather="more-horizontal" class="feather-16"></i>
                          <?php
                          }
                        ?>
                      </td>
                      <td>
                        <?php
                          if($trained['level3'])
                          {
                        ?>
                        <i data-feather="check-circle" class="feather-16"></i></td>
                        <?php
                          }
                          else
                          {
                          ?>
                          <i data-feather="more-horizontal" class="feather-16"></i>
                          <?php
                          }
                        ?>
                      </td>
                    </tr>
                  <?php
                    $i++;
                  }
                }
              ?>
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
     
          </div>       <?php
      }
      else
      {
      ?>
        <div class="alert alert-primary d-flex align-items-center" role="alert">
        <i data-feather="alert-circle" class="mg-r-10"></i> You have not been assigned to a location. You cannot complete this action.
      </div>
      <?php
      }
    ?>
        </div><!-- card -->


        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Renumerations</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="<?php echo $ROOT_FOLDER;?>data-entry/facilitator-remuneration/1" class="nav-link" ><i data-feather="plus"></i> New Entry</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">District</th>
                <th scope="col" rowspan="2">Subcounty</th>
                <th scope="col" rowspan="2">Facilitator</th>
                <th scope="col" rowspan="2">Amount</th>
              </tr>
              
            </thead>
            <tbody>
            <?php
              if(!empty($arrPartnerships))
              {
                foreach($arrPartnerships as $partnership)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="link" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $partnership['partner_name'].": ". $partnership['partnership_name'];?></h6>
                          <p class="tx-12 mg-b-10"><?php if(!is_null($partnership['partnership_description'])) echo nl2br(substr($partnership['partnership_description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
           </tbody>
          </table> 
          </div>
        </div><!-- card -->
<div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Equipment</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalEquipments"><i data-feather="plus"></i> New Entry</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
             <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">District</th>
                <th scope="col" rowspan="2">Subcounty</th>
                <th scope="col" rowspan="2">Facilitator</th>
                <th scope="col" rowspan="2">Quipment Type</th>
              </tr>
              
            </thead>
            <tbody>
            <?php
              if(!empty($arrPartnerships))
              {
                foreach($arrPartnerships as $partnership)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="link" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $partnership['partner_name'].": ". $partnership['partnership_name'];?></h6>
                          <p class="tx-12 mg-b-10"><?php if(!is_null($partnership['partnership_description'])) echo nl2br(substr($partnership['partnership_description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
           </tbody>
          </table> 
          </div>
        </div><!-- card -->


<div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Learning Sites</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="<?php echo $ROOT_FOLDER;?>data-entry/learning-sites/1" class="nav-link" ><i data-feather="plus"></i> New Entry</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">District</th>
                <th scope="col" rowspan="2">Subcounty</th>
                <th scope="col" rowspan="2">Status of Site</th>
                <th scope="col" rowspan="2">Number</th>
              </tr>
              
            </thead>
            <tbody>
            <?php
              if(!empty($arrPartnerships))
              {
                foreach($arrPartnerships as $partnership)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="link" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $partnership['partner_name'].": ". $partnership['partnership_name'];?></h6>
                          <p class="tx-12 mg-b-10"><?php if(!is_null($partnership['partnership_description'])) echo nl2br(substr($partnership['partnership_description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
           </tbody>
          </table>
            
          </div>
        </div><!-- card -->
        
        
<div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">SITAN Sessions Undertaken</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="<?php echo $ROOT_FOLDER;?>data-entry/sitan-sessions/1" class="nav-link" ><i data-feather="plus"></i> New Entry</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">District</th>
                <th scope="col" rowspan="2">Subcounty</th>
                <th scope="col" rowspan="2">Number of Sessions</th>
              </tr>
              
            </thead>
            <tbody>
            <?php
              if(!empty($arrPartnerships))
              {
                foreach($arrPartnerships as $partnership)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="link" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $partnership['partner_name'].": ". $partnership['partnership_name'];?></h6>
                          <p class="tx-12 mg-b-10"><?php if(!is_null($partnership['partnership_description'])) echo nl2br(substr($partnership['partnership_description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
           </tbody>
          </table>
            
          </div>
        </div><!-- card -->
        
        
        
        
<div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Vilages Mobilized and Sensitized</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="<?php echo $ROOT_FOLDER;?>data-entry/villages-mobilized/1" class="nav-link" ><i data-feather="plus"></i> New Entry</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">District</th>
                <th scope="col" rowspan="2">Subcounty</th>
                <th scope="col" rowspan="2">Number of Villages Mobilized</th>
              </tr>
              
            </thead>
            <tbody>
            <?php
              if(!empty($arrPartnerships))
              {
                foreach($arrPartnerships as $partnership)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="link" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $partnership['partner_name'].": ". $partnership['partnership_name'];?></h6>
                          <p class="tx-12 mg-b-10"><?php if(!is_null($partnership['partnership_description'])) echo nl2br(substr($partnership['partnership_description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
           </tbody>
          </table>
            
            
          </div>
        </div><!-- card -->
        


        
<div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Structures Established</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="<?php echo $ROOT_FOLDER;?>data-entry/structures-established/1" class="nav-link" ><i data-feather="plus"></i> New Entry</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">District</th>
                <th scope="col" rowspan="2">Subcounty</th>
                <th scope="col" rowspan="2">Number of Structures Established</th>
              </tr>
              
            </thead>
            <tbody>
            <?php
              if(!empty($arrPartnerships))
              {
                foreach($arrPartnerships as $partnership)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="link" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $partnership['partner_name'].": ". $partnership['partnership_name'];?></h6>
                          <p class="tx-12 mg-b-10"><?php if(!is_null($partnership['partnership_description'])) echo nl2br(substr($partnership['partnership_description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
           </tbody>
          </table>
            
            
          </div>
        </div><!-- card -->
        


        
<div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Structures Strengthened</h6>
            <nav class="nav nav-with-icon tx-13">
             <a href="<?php echo $ROOT_FOLDER;?>data-entry/structures-strengthened/1" class="nav-link" ><i data-feather="plus"></i> New Entry</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">District</th>
                <th scope="col" rowspan="2">Subcounty</th>
                <th scope="col" rowspan="2">Number of Structures Strengthened</th>
              </tr>
              
            </thead>
            <tbody>
            <?php
              if(!empty($arrPartnerships))
              {
                foreach($arrPartnerships as $partnership)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="link" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $partnership['partner_name'].": ". $partnership['partnership_name'];?></h6>
                          <p class="tx-12 mg-b-10"><?php if(!is_null($partnership['partnership_description'])) echo nl2br(substr($partnership['partnership_description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
           </tbody>
          </table>
            
            
          </div>
        </div><!-- card -->
        

      </div><!-- media-body -->

    </div><!-- media -->
  </div><!-- container -->
</div><!-- content-body -->



   



<!-- Modal Services -->
<div class="modal fade" id="modalServices" tabindex="-1" role="dialog" aria-labelledby="modalServicesTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/data-facilitators-trained.php" method="post" data-parsley-validate>
        <input type="hidden" name="clc_id" value="<?php echo $displayedPage['item'];?>">
        <input type="hidden" name="user_id" value="<?php echo $displayedPage['item'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Facilitator Training</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <!-- <div class="form-row">-->
            <!--<div class="form-group col-md-6">-->
              
            <div class="form-row">
              <div class="form-group col-md-4">
                <label>District</label>
                <select class="custom-select select2 dependable-select" data-initiates="sel-subcounties" data-list="districts" style="width:400px;">
                  <?php
                      foreach($arrDistricts as $district)
                      {
                    ?>
                    <option value="<?php echo $district['district_id'];?>">
                      <?php echo ucwords(strtolower($district['district_name']));?>
                    </option>
                    <?php
                      }
                    ?>
                </select>
              </div>
              </div>
              <div class="form-row">
              <div class="form-group col-md-4">
                <label>Subcounty</label>
                <select id="sel-subcounties" class="custom-select dependable-check-training" data-initiates="facilitator-training" data-list="subcounties" style="width:400px;" required>
                  <option value="" selected>Select Subcounty</option>
                  <?php
                      if(!empty($arrSubcounties))
                      {
                        foreach($arrSubcounties as $sub)
                        {
                        ?>
                          <option value="<?php echo $sub['subcounty_id'];?>"> 
                            <?php echo $sub['subcounty_name'];?>
                          </option>
                        <?php
                        }
                      }
                    ?>
                </select>
              </div>
              </div>
              <div class="form-row">
              <div class="form-group col-md-4">
                <label>Quarter</label>
                <select id="sel-counties" name="quarter_id" class="custom-select" style="width:400px;" required>
                  <?php
                    if(!empty($arrQuarters))
                    {
                      foreach($arrQuarters as $quarter)
                      {
                      ?>
                        <option value="<?php echo $quarter['quarter_id'];?>"><?php echo $quarter['quarter_name'];?></option>
                      <?php
                      }
                    }
                  ?>
                </select>
              </div>
            </div>        
            <div class="form-row">
              <div class="form-group col-md-12">
                <table class="table table-bordered" style="white-space:nowrap;">
                  <thead>
                    <tr>
                      <th scope="col" class="wd-5p">#</th>
                      <th scope="col" class="wd-35px text-center">Facilitator</th>
                      <?php
                        if(!empty($arrCourses))
                        {
                          foreach($arrCourses as $course)
                          {
                          ?>
                            <th scope="col" class="wd-10p text-center"><?php echo $course['course_name'];?></th>
                          <?php
                          }
                        }
                      ?>
                    </tr>
                  </thead>
                  <tbody id="check-data">
                   
                  </tbody>
                </table>
              </div>
            </div>
            </div>
          
            
          
       
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Submit Form">
      </div>
      </form>
    </div>
  </div>
</div>





<!-- Modal EQuipment -->
<div class="modal fade" id="modalEquipments" tabindex="-1" role="dialog" aria-labelledby="modalEquipmentTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/data-facilitators-trained.php" method="post" data-parsley-validate>
        <input type="hidden" name="clc_id" value="<?php echo $displayedPage['item'];?>">
        <input type="hidden" name="user_id" value="<?php echo $displayedPage['item'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Facilitator Equipments</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <!-- <div class="form-row">-->
            <!--<div class="form-group col-md-6">-->
              
            <div class="form-row">
              <div class="form-group col-md-4">
                <label>District</label>
                <select class="custom-select select2 dependable-select" data-initiates="sel-subcounties" data-list="districts" style="width:400px;">
                  <?php
                      foreach($arrDistricts as $district)
                      {
                    ?>
                    <option value="<?php echo $district['district_id'];?>">
                      <?php echo ucwords(strtolower($district['district_name']));?>
                    </option>
                    <?php
                      }
                    ?>
                </select>
              </div>
              </div>
              <div class="form-row">
              <div class="form-group col-md-4">
                <label>Subcounty</label>
                <select id="sel-subcounties" class="custom-select dependable-check-training" data-initiates="facilitator-training" data-list="subcounties" style="width:400px;" required>
                  <option value="" selected>Select Subcounty</option>
                  <?php
                      if(!empty($arrSubcounties))
                      {
                        foreach($arrSubcounties as $sub)
                        {
                        ?>
                          <option value="<?php echo $sub['subcounty_id'];?>"> 
                            <?php echo $sub['subcounty_name'];?>
                          </option>
                        <?php
                        }
                      }
                    ?>
                </select>
              </div>
              </div>
              <div class="form-row">
              <div class="form-group col-md-4">
                <label>Quarter</label>
                <select id="sel-counties" name="quarter_id" class="custom-select" style="width:400px;" required>
                  <?php
                    if(!empty($arrQuarters))
                    {
                      foreach($arrQuarters as $quarter)
                      {
                      ?>
                        <option value="<?php echo $quarter['quarter_id'];?>"><?php echo $quarter['quarter_name'];?></option>
                      <?php
                      }
                    }
                  ?>
                </select>
              </div>
            </div>        
            <div class="form-row">
              <div class="form-group col-md-4">
               <label>Facilitator</label>
                <select id="facilitator_id" name="facilitator_id" class="custom-select" style="width:400px;" required>
                  <?php
				 
                    if(!empty($arrFacilitators))
                    {
                      foreach($arrFacilitators as $fac)
                      {
                      ?>
                        <option value="<?php echo $fac['user_id'];?>"><?php echo $quarter['fullname'];?></option>
                      <?php
                      }
                    }
                  ?>
                </select>
              
              
              
               
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-12">
               <label>No. of Equipments</label>
                <input type='text' id="noofequipments" name="noofequipments" class="form-control" style="width:400px;" required></div>
            </div>
            
            
            </div>
          
            
          
       
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Submit Form">
      </div>
      </form>
    </div>
  </div>
</div>





<!-- Modal Renumeration -->
<div class="modal fade" id="modalRenumerations" tabindex="-1" role="dialog" aria-labelledby="modalServicesTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/data-facilitators-trained.php" method="post" data-parsley-validate>
        <input type="hidden" name="clc_id" value="<?php echo $displayedPage['item'];?>">
        <input type="hidden" name="user_id" value="<?php echo $displayedPage['item'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Facilitator Renumerations</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <!-- <div class="form-row">-->
            <!--<div class="form-group col-md-6">-->
              
            <div class="form-row">
              <div class="form-group col-md-4">
                <label>District</label>
                <select class="custom-select select2 dependable-select" data-initiates="sel-subcounties" data-list="districts" style="width:400px;">
                  <?php
                      foreach($arrDistricts as $district)
                      {
                    ?>
                    <option value="<?php echo $district['district_id'];?>">
                      <?php echo ucwords(strtolower($district['district_name']));?>
                    </option>
                    <?php
                      }
                    ?>
                </select>
              </div>
              </div>
              <div class="form-row">
              <div class="form-group col-md-4">
                <label>Subcounty</label>
                <select id="sel-subcounties" class="custom-select dependable-check-training" data-initiates="facilitator-training" data-list="subcounties" style="width:400px;" required>
                  <option value="" selected>Select Subcounty</option>
                  <?php
                      if(!empty($arrSubcounties))
                      {
                        foreach($arrSubcounties as $sub)
                        {
                        ?>
                          <option value="<?php echo $sub['subcounty_id'];?>"> 
                            <?php echo $sub['subcounty_name'];?>
                          </option>
                        <?php
                        }
                      }
                    ?>
                </select>
              </div>
              </div>
              <div class="form-row">
              <div class="form-group col-md-4">
                <label>Quarter</label>
                <select id="sel-counties" name="quarter_id" class="custom-select" style="width:400px;" required>
                  <?php
                    if(!empty($arrQuarters))
                    {
                      foreach($arrQuarters as $quarter)
                      {
                      ?>
                        <option value="<?php echo $quarter['quarter_id'];?>"><?php echo $quarter['quarter_name'];?></option>
                      <?php
                      }
                    }
                  ?>
                </select>
              </div>
            </div>        
            <div class="form-row">
              <div class="form-group col-md-12">
             
                      
                       <div class="form-row">
              <div class="form-group col-md-4">
                <label for="usergroup">Facilitators</label>
                <div id="check-facilitators">
                </div>
              </div>
            </div> 
                     
              </div>
            </div>
            </div>
          
            
          
       
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Submit Form">
      </div>
      </form>
    </div>
  </div>
</div>








<!-- Modal Partnerships -->
<div class="modal fade" id="modalPartnerships" tabindex="-1" role="dialog" aria-labelledby="modalPartnershipsTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-clc-new-partnership.php" method="post">
        <input type="hidden" name="clc_id" value="<?php echo $displayedPage['item'];?>">
        <input type="hidden" name="user_id" value="<?php echo $_SESSION['USER']['ICOLEW_USERID'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New Partnership</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-row">
            <div class="form-group col-md-4">
              <label>Partner</label>
              <select name="partner_id" class="custom-select" required>
                <option value="" selected>Choose One</option>
                <?php
                  foreach($arrPartners as $partner)
                  {
                  ?>
                    <option value="<?php echo $partner['partner_id'];?>">
                      <?php echo $partner['partner_name'];?>
                      </option>
                  <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-8">
              <label for="event_name">Partnership Name</label>
              <input type="text" class="form-control" name="partnership_name" placeholder="Partnership Name" value="" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="message-text" class="col-form-label">Partnership Description:</label>
              <textarea class="form-control" name="partnership_description"></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="date_started">Start Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item" name="start_date" placeholder="Select Date" required>
            </div>

          </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>