<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Monitoring & Evaluation</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Welcome to The Monitoring & Evaluation Dashboard</h4>
      </div>

    </div>
    <div class="row row-xs">
      <div class="col-sm-6 col-lg-4">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Learners Completing Cycle</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">81%</h3>
            <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">32% <i class="icon ion-md-arrow-up"></i></span></p>
          </div>
          <div class="chart-three">
              <div id="flotChart3" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 mg-t-10 mg-sm-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Facilitators Trained</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">537</h3>
            <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-danger">27% </i></span></p>
          </div>
          <div class="chart-three">
              <div id="flotChart4" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 mg-t-10 mg-lg-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Functional Learning Sites</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">63</h3>
            <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">43% <i class="icon ion-md-arrow-up"></i></span></p>
          </div>
          <div class="chart-three">
              <div id="flotChart5" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 mg-t-10 mg-lg-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Villages Mobilized and Sensitized</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">17</h3>
            <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">2.1% <i class="icon ion-md-arrow-up"></i></span></p>
          </div>
          <div class="chart-three">
              <div id="flotChart6" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 mg-t-10 mg-lg-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">VSLAs Established and Equipped</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">17</h3>
            <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">2.1% <i class="icon ion-md-arrow-up"></i></span></p>
          </div>
          <div class="chart-three">
              <div id="flotChart6" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 mg-t-10 mg-lg-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Facilitators Trained in VSLA Management</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">17</h3>
            <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">2.1% <i class="icon ion-md-arrow-up"></i></span></p>
          </div>
          <div class="chart-three">
              <div id="flotChart6" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 mg-t-10 mg-lg-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Learners Regularly Saving and Borrowing</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">17</h3>
            <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">2.1% <i class="icon ion-md-arrow-up"></i></span></p>
          </div>
          <div class="chart-three">
              <div id="flotChart6" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 mg-t-10 mg-lg-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Groups Funded By Amounts</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">17</h3>
            <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">2.1% <i class="icon ion-md-arrow-up"></i></span></p>
          </div>
          <div class="chart-three">
              <div id="flotChart6" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 mg-t-10 mg-lg-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Projects Established From VAPS and GAPS</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">17</h3>
            <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">2.1% <i class="icon ion-md-arrow-up"></i></span></p>
          </div>
          <div class="chart-three">
              <div id="flotChart6" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
    </div><!-- row -->
    
    <!----Another row-->
    
    <div class="row">
                                    <div class="col-lg-4">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                                <strong style="font-size:18px; font-weight:bold;">No. tested for HIV 15-49 years</strong>
                                                 
                                                 <i class="fa fa-bar-chart"></i>
                                                 <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                </div>
                                                
                                               
                                                
                                                
                                                
                                                </div>
                                            <!-- /.panel-heading -->
                                            <!--<div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                             
  
                                                <div class="graph_wrapper" id="container_Ind_10">
                                                 </div>
                                            
                                            <!-- /.panel-body -->
                                        </div>
                                      
                                        <!-- /.panel -->

                                    </div>
                                    
                                    
                                    
                                    
                                    
                              
                                    <div class="col-lg-4">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;"># of HIV+ 15-49 years</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_12">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    <div class="col-lg-4">
                                        <div class="panel panel-default">
                                            <div class="panel-heading"><strong style="font-size:18px; font-weight:bold;"># 15-49 Linked to care.</strong><div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div></div>
                                            <!-- /.panel-heading -->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_13"></div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!--/.panel -->

                                    </div>
                                </div>
    
    <!--end of another row--->
  </div><!-- container -->
</div>







<!-- jQuery -->

<script src="assets/javascripts/jquery-3.3.1.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="assets/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
<!-- Custom Theme JavaScript -->
<script src="assets/javascripts/sb-admin-2.js"></script>
<script src="assets/Highcharts-6.1.0/code/highcharts.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/map.js"></script>
<script src="assets/Highcharts-6.1.0/code/highcharts-3d.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/exporting.js"></script>
<script src="assets/Highcharts-6.1.0/code/modules/export-data.js"></script>
<script src="assets/Highmaps-6.1.0/code/ug-all.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/data.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/drilldown.js"></script>
<script src="../../code/highcharts.js"></script>
<script src="../../code/modules/exporting.js"></script>
<script src="../../code/modules/export-data.js"></script>



       <!----Indicator 18 --> 
        <table id="datatable18" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Male</th>
                <th>Female</th>
            </tr>
        </thead>
        <tbody>
        
		<tr>
		
			<th>1</th>
		    <td>1</td>
            <td>1</td>
		</tr>
		
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_18', {
    data: {
        table: 'datatable18'
    },
    chart: {
        type: 'bar'
    },
    title: {
        text: ''
    },
	subtitle: {
        text: 'Source:GBV-MoGLSD'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Percentage(%)'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script> 