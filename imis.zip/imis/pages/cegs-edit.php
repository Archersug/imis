<?php
  $options = array("ceg_id" => $displayedPage['item']);
  $arrCeg = dbGetCegs($options);
  $arrRegions = dbGetAllRegions();
  $arrFacilitators = dbGetAllFacilitators();
  //$arrSubregions = dbGetAllSubregions();
  $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['districts']);
  $arrDistricts = dbGetUserDistrict($options);

  $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['subcounties']);
  $arrSubcounties = dbGetUserSubcounties($options);  
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Features</a></li>
            <li class="breadcrumb-item active" aria-current="page">Engagement</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Edit CEG: <?php echo $arrCeg[0]['ceg_name'] . " (".$arrCeg[0]['ceg_code'].")";?></h4>
      </div>
    </div>
    <form action="<?php echo $ROOT_FOLDER;?>process/cegs-edit.php" method="post" data-parsley-validate>
      <input type="hidden" name="ceg_id" value="<?php echo $displayedPage['item'];?>">
      <div class="row row-xs">
        
        <div class="col-sm-12 col-lg-6">
          <div data-label="Location" class="df-example demo-table">
            
              <div class="form-row">
               
                <div class="form-group col-md-12">
                  <label for="subregion_id">District</label>
                  <select class="custom-select dependable-select" data-initiates="sel-subcounties" data-list="districts" id="sel-districts">
                    <?php
                      if(!empty($arrDistricts))
                      {
                        foreach($arrDistricts as $district)
                        {
                        ?>
                          <option value="<?php echo $district['district_id'];?>">
                            <?php echo $district['district_name'];?> </option>
                        <?php
                        }
                      }
                    ?>
                  </select>
                </div>

                <div class="form-group col-md-12">
                  <label for="subregion_id">Subcounty</label>
                  <select class="custom-select dependable-select" data-initiates="sel-parishes" data-list="subcounties" id="sel-subcounties">
                    <option value="" selected=""></option>
                    <?php
                      if(!empty($arrSubcounties))
                      {
                        foreach($arrSubcounties as $sub)
                        {
                        ?>
                          <option value="<?php echo $sub['subcounty_id'];?>"> 
                            <?php echo $sub['subcounty_name'];?>
                          </option>
                        <?php
                        }
                      }
                    ?>
                    
                  </select>
                </div>

                <div class="form-group col-md-12">
                  <label for="subregion_id">Parish</label>
                  <select class="custom-select dependable-select" data-initiates="sel-villages" data-list="parishes" id="sel-parishes">
                    <option value="" selected> </option>
                  </select>
                </div>

                <div class="form-group col-md-12">
                  <label for="subregion_id">Village</label>
                  <select class="custom-select" id="sel-villages" name="village_id" required>
                    <option value="<?php echo $arrCeg[0]['village_id'];?>" selected> <?php echo $arrCeg[0]['village_name'];?></option>
                  </select>
                </div>
              </div>
            
          </div>
        </div><!-- col -->
        <div class="col-sm-12 col-lg-6">
          <div data-label="CEG Details" class="df-example demo-table">
            
              <div class="form-row">
                <div class="form-group col-md-12">
                  <label for="ceg_name">CEG Name</label>
                  <input type="text" class="form-control" id="ceg_name" value="<?php echo $arrCeg[0]['ceg_name'];?>" name="ceg_name" placeholder="CEG Name" required>
                </div>

                <div class="form-group col-md-12">
                  <label for="ceg_code">CEG Code</label>
                  <input type="text" class="form-control" id="ceg_code" value="<?php echo $arrCeg[0]['ceg_code'];?>" name="ceg_code" placeholder="CEG Code" required>
                </div>

                <div class="form-group col-md-6">
                  <label for="beneficiary_dob">Date Established</label>
                  <input type="text" class="form-control" id="datepicker-birthday" name="date_established" placeholder="Select Date" value="<?php echo $arrCeg[0]['date_established'];?>">
                </div>

                <div class="form-group col-md-12">
                  <label for="ceg_phone">Phone Number</label>
                  <input type="text" class="form-control" id="ceg_phone" value="<?php echo $arrCeg[0]['ceg_phone'];?>" name="ceg_phone" placeholder="Phone Number">
                </div>

                <div class="form-group col-md-12">
                  <label for="ceg_email">Email</label>
                  <input type="text" class="form-control" id="ceg_email" value="<?php echo $arrCeg[0]['ceg_email'];?>" name="ceg_email" placeholder="Email">
                </div>

                <div class="form-group col-md-12">
                  <label for="ceg_coordinates">CEG coordinates</label>
                  <input type="text" class="form-control" id="ceg_coordinates" value="<?php echo $arrCeg[0]['ceg_coordinates'];?>" name="ceg_coordinates" placeholder="CEG Coordinates">
                </div>
              
              <div class="form-group col-md-12">
                <label for="facilitator_id">Facilitator</label>
                <select class="custom-select select2" id="facilitator_id" name="facilitator_id" required>
                  <option value="" selected> </option>
                  <?php
                    if(!empty($arrFacilitators))
                    {
                      foreach($arrFacilitators as $fac)
                      {
                      ?>
                        <option value="<?php echo $fac['facilitator_id'];?>" <?php echo ($arrCeg[0]['facilitator_id'] == $fac['facilitator_id'])? ' selected':'';?>>
                          <?php echo $fac['fullname'];?> 
                        </option>
                      <?php
                      }
                    }
                  ?>
                  
                </select>
                </div>
              </div>
              <button type="submit" class="btn btn-primary">Save</button>
            
          </div>
        </div><!-- col -->
        
      </div><!-- row -->
    </form>

  </div><!-- container -->
</div>