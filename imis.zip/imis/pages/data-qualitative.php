<?php
   if(isset($_SESSION['USER']['ASSIGNMENTS']['locations']))
  {
    $options = array('group_id' => '1');
    $arrCourses = dbGetTrainingCourses($options);
    $arrQuarters = dbGetCurrentQuarter();

    $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['districts']);
    $arrDistricts = dbGetUserDistrict($options);

    $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['subcounties']);
    $arrSubcounties = dbGetUserSubcounties($options); 

    $options2 = array(
                'quarter_id' => $arrQuarters[0]['quarter_id'], 
                'user_id' => $_SESSION['USER']['ICOLEW_USERID']
              );

    $arrData = dbGetQualitativeData($options2);
$arrMeetings = dbGetMeetings($options);
    $arrTypes = dbGetQualitativeDataTypes();

  }
  $arrDistricts = dbGetAllDistricts();
//---- facilitator Quarterly Reportings------------

?>


<div class="content-body">
  <div class="container pd-x-0 tx-13">
  <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Data Entry</a></li>
            <li class="breadcrumb-item active" aria-current="page">Narrative Reports</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Qualitative Data Entry</h4>
      </div>
    </div>
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
	   if(isset($_SESSION['USER']['ASSIGNMENTS']['locations']))
      {
    ?>
    <div class="media d-block d-lg-flex">
      
      <div class="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">


        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Narrative Reports</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalQualitative"><i data-feather="plus"></i> New Entry</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
          <!-----------Facilitator Training-->
          <div class="row row-xs" style="margin-bottom: 10px;">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Entered Data" class="df-example demo-table">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">Title</th>
                <th scope="col" rowspan="2">Type</th>
                <th scope="col" rowspan="2">Date</th>
                <th scope="col" rowspan="2">Action</th>
                </tr>
              <tr>
                <th scope="col">L1</th>
                <th scope="col">L2</th>
                <th scope="col">L3</th>
              </tr>
            </thead>
            <tbody>
              <?php
                if(!empty($arrData))
                {
                  $i = 1;
                  foreach($arrData as $data)
                  {
                  ?>
                    <tr>
                      <th scope="row"><?php echo $i;?></th>
                      <td><a href="<?php echo $ROOT_FOLDER;?>uploads/<?php echo $data['data_file'];?>"><?php echo $data['data_title'];?></a><br/>
                        <?php echo substr($data['data_description'],0,200);?>
                      </td>
                      <td><?php echo $data['type_name'];?></td>
                      <td><?php echo $data['upload_date'];?></td>
                      <td>
                        <?php
						
						
                          if($data['level1'])
                          {
                        ?>
                        <i data-feather="check-circle" class="feather-16"></i></td>
                        <?php
                          }
                          else
                          {
                          ?>
                          <i data-feather="more-horizontal" class="feather-16"></i>
                          <?php
                          }
                        ?>
                      <td>
                        <?php
                          if($data['level2'])
                          {
                        ?>
                        <i data-feather="check-circle" class="feather-16"></i></td>
                        <?php
                          }
                          else
                          {
                          ?>
                          <i data-feather="more-horizontal" class="feather-16"></i>
                          <?php
                          }
                        ?>
                      </td>
                      <td>
                        <?php
                          if($data['level3'])
                          {
                        ?>
                        <i data-feather="check-circle" class="feather-16"></i></td>
                        <?php
                          }
                          else
                          {
                          ?>
                          <i data-feather="more-horizontal" class="feather-16"></i>
                          <?php
                          }
                        ?>
                      </td>
                    </tr>
                  <?php
                    $i++;
                  }
                }
				
              ?>
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
     
          </div>       <?php
      }
      else
      {
      ?>
        <div class="alert alert-primary d-flex align-items-center" role="alert">
        <i data-feather="alert-circle" class="mg-r-10"></i> You have not been assigned to a location. You cannot complete this action.
      </div>
      <?php
      }
    ?>
        </div><!-- card -->






<div class="modal fade" id="modalQualitative" tabindex="-1" role="dialog" aria-labelledby="modalEquipmentTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
     <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Data Form" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/data-qualitative.php" method="post" data-parsley-validate enctype="multipart/form-data">
            <input type="hidden" name="user_id" value="<?php echo $_SESSION['USER']['ICOLEW_USERID'];?>">
            <input type="hidden" name="upload_date" value="<?php echo date("Y-m-d H:i:s");?>">
             <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New Partnership</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
            <div class="form-row">
              <div class="form-group col-md-4">
                <label>District</label>
                <select class="custom-select select2 dependable-select" data-initiates="sel-subregions" data-list="regions">
                  <?php
                      foreach($arrDistricts as $district)
                      {
                    ?>
                    <option value="<?php echo $district['district_id'];?>">
                      <?php echo ucwords(strtolower($district['district_name']));?>
                    </option>
                    <?php
                      }
                    ?>
                </select>
              </div>
              <div class="form-group col-md-4">
                <label>Subcounty</label>
                <select id="sel-counties" name="subcounty_id" class="custom-select" required>
                  <option value="" selected>Select Subcounty</option>
                   <?php
                      if(!empty($arrSubcounties))
                      {
                        foreach($arrSubcounties as $sub)
                        {
                        ?>
                          <option value="<?php echo $sub['subcounty_id'];?>"> 
                            <?php echo $sub['subcounty_name'];?>
                          </option>
                        <?php
                        }
                      }
                    ?>
                </select>
              </div>
              <div class="form-group col-md-4">
                <label>Quarter</label>
                <select id="" name="quarter_id" class="custom-select">
                  <option value="<?php echo $arrQuarters[0]['quarter_id'];?>" selected><?php echo $arrQuarters[0]['quarter_name'];?></option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-4">
                <label>Type Of Report</label>
                <select id="sel-counties" name="data_type" class="custom-select" required>
                  <option value="" selected>Choose Type</option>
                  <?php
                    if(!empty($arrTypes))
                    {
                      foreach($arrTypes as $type)
                      {
                      ?>
                        <option value="<?php echo $type['type_id'];?>"><?php echo $type['type_name'];?></option>
                      <?php
                      }
                    }
                  ?>
                  
                </select>
              </div>
              <div class="form-group col-md-8">
                <label for="data_title">Title</label>
                <input type="text" class="form-control" id="data_title" name="data_title" placeholder="Name" required><br/>
                <label for="usergroup">Brief Description</label>
                <textarea class="form-control" rows="4" placeholder="Textarea" name="data_description"></textarea>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-12">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="data_file" name="data_file" required>
                  <label class="custom-file-label" for="customFile">Choose file</label>
                </div>
              </div>
            </div>
            
            
            <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Submit Form">
      </div>
            
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->
    </div>
    </div>
    </div>
    
    
    <!-- modalNationalMeetings-->
    <div class="modal fade" id="modalNationalMeetings" tabindex="-1" role="dialog" aria-labelledby="modalNationalMeetingsTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document1">

        <div data-label="Data Form" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/users-add.php" method="post" data-parsley-validate>
          <div class="form-row">
          <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New Partnership</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
            <div class="form-group col-md-4">
              <label>Meeting Type</label>
              <select id="sel-activities" name="type_id" class="custom-select" required>
                <option value="" selected>Choose One</option>
                <option value="">Review</option>
                <option value="">Planning</option>
                <?php
                  foreach($arrEventTypes as $type)
                  {
                  ?>
                    <option value="<?php echo $type['type_id'];?>">
                      <?php echo $type['type_name'];?>
                      </option>
                  <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-8">
              <label for="event_name">Meeting Name</label>
              <input type="text" class="form-control" id="" name="event_name" placeholder="District Name" value="" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="message-text" class="col-form-label">Meeting Description:</label>
              <textarea class="form-control" id="" name="event_description"></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">Start Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item" name="start_date" placeholder="Select Date" required>
            </div>
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">End Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item1" name="end_date" placeholder="Select Date" required>
            </div>
          </div>           
            <div class="form-row">
              <div class="form-group col-md-8">
                <button type="submit" class="btn btn-primary">Submit Form</button>
              </div>
            </div>
            
            
          </form>
        </div>
     
  </div>
  </div>

    <!-- end of modalNationalMeetings-->
    
      
    
    <!-- modalDistrictMeetings-->
    <div class="modal fade" id="modalDistrictMeetings" tabindex="-1" role="dialog" aria-labelledby="modalEquipmentTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="documentxxx">
  xxxxxxx
  </div>
  </div>
    <!-- end of modalDistrictMeetings-->
    
    
    
    <!-- modalIMTCMeetings-->
    <div class="modal fade" id="modalIMTCMeetings" tabindex="-1" role="dialog" aria-labelledby="modalEquipmentTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="documentxsaaa">
  xxxxxxx
  </div>
  </div>
    <!-- end of modalIMTCMeetings-->