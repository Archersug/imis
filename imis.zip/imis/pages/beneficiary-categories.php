<?php
  $arrCats = dbGetBeneficiaryCategories();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Features</a></li>
            <li class="breadcrumb-item active" aria-current="page">Beneficiary Categories</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Beneficiary Categories</h4>
      </div>
      <div class="d-none d-md-block">
        <a href="" class="btn btn-sm pd-x-15 btn-primary btn-uppercase mg-l-5" data-toggle="modal" data-target="#modalAddBeneficiaryCategory"><i data-feather="users" class="wd-10 mg-r-5"></i>New Entry</a>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
            <div data-label="Beneficiary Categories" class="df-example demo-table">
        <table id="" class="table datatable">
          <thead>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="wd-35p">Name</th>
                  <th class="wd-20p">Abbreviation</th>
                  <th class="wd-20p">Actions</th>
              </tr>
          </thead>
          <tbody>
            <?php
              $i = 1;
              foreach($arrCats as $cat)
              {
            ?>
            <tr>
                <td><?php echo $i;?></td>
                <td><?php echo $cat['category_name'];?></td>
                <td><?php echo $cat['category_abbr'];?></td>
                <td>
                  <a href="#" type="button" 
                  class="btn btn btn-outline-primary btn-icon btn-xs beneficiary-edit-categories" data-toggle="modal" data-target="#modalEditBudgetCategory" data-cat-id="<?php echo $cat['category_id'];?>">
                    <i data-feather="edit"></i>
                  </a>
                  <a href="#" type="button" class="btn btn btn-outline-danger btn-icon btn-xs">
                    <i data-feather="trash"></i>
                  </a>
                </td>
            </tr>
            <?php
                $i++;
              }
            ?>
          </tbody>
      </table>
    </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>


<!-- Modal -->
<div class="modal fade" id="modalAddBeneficiaryCategory" tabindex="-1" role="dialog" aria-labelledby="modalBudgetItemTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-beneficiary-add-category.php" method="post">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Add Beneficiary Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <!--row 1-->
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="detail_name">Category Name</label>
            <input type="text" class="form-control" value="" name="category_name" placeholder="Category Name" required>
          </div>
        </div>
         <!--end of row 1-->
         <!--row 2-->
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="detail_name">Category Abbreviation</label>
            <input type="text" class="form-control" value="" name="category_abbr" placeholder="Abbreviation" required>
          </div>
        </div>
         <!--end of row 2-->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalEditBudgetCategory" tabindex="-1" role="dialog" aria-labelledby="modalBudgetItemTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-beneficiary-edit-category.php" method="post">
        <input type="hidden" id="category_id" name="category_id" value="">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Edit Beneficiary Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
               <!--Row 1--->
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="detail_name">Category Name</label>
            <input type="text" class="form-control" value="" name="category_name" id="category_name" placeholder="Category Name" required>
          </div>
        </div>
        <!---end of Row 1-->
         <!--Row 2--->
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="detail_name">Category Abbreviation</label>
            <input type="text" class="form-control" value="" name="category_abbr" id="category_abbr" placeholder="Category Abbreviation" required>
          </div>
        </div>
        <!---end of Row 2-->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>