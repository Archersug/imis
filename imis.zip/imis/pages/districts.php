<?php
  $arrDistricts = dbGetAllDistricts();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Locations</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">List of Districts</h4>
      </div>
      <div class="d-none d-md-block">
        <a href="<?php echo $ROOT_FOLDER;?>districts/add/1" class="btn btn-sm pd-x-15 btn-primary btn-uppercase mg-l-5"><i data-feather="user-plus" class="wd-10 mg-r-5"></i> Add New District</a>
      </div>
    </div>

    <!-- Alert User -->
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>

    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
            <div data-label="Districts" class="df-example demo-table">
        <table id="" class="table datatable">
          <thead>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="wd-10p">Name</th>
                  <th class="wd-20p">Region</th>
                  <th class="wd-10p">Actions</th>
              </tr>
          </thead>
          <tbody>
            <?php
              $i = 1;
              foreach($arrDistricts as $district)
              {
            ?>
            <tr>
                <td><?php echo $i;?></td>
                <td><?php echo $district['district_name'];?></td>
                <td><?php echo $district['region_name'];?></td>
                <td>
                  <a href="<?php echo $ROOT_FOLDER;?>districts/edit/<?php echo $district['district_id'];?>" type="button" class="btn btn btn-outline-primary btn-icon btn-xs">
                    <i data-feather="edit"></i>
                  </a>
                  <a href="<?php echo $ROOT_FOLDER;?>districts/delete/<?php echo $district['district_id'];?>" type="button" class="btn btn btn-outline-danger btn-icon btn-xs">
                    <i data-feather="trash"></i>
                  </a>
                </td>
            </tr>
            <?php
                $i++;
              }
            ?>
          </tbody>
      </table>
    </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>