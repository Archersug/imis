<?php
  $arrUsergroups = dbGetUsergroups();
  $arrDistricts = dbGetAllDistricts();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Data Entry</a></li>
            <li class="breadcrumb-item active" aria-current="page">Locations</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Learning Sites</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Data Form" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/users-add.php" method="post" data-parsley-validate>
            <div class="form-row">
              <div class="form-group col-md-4">
                <label>District</label>
                <select name="district_id" class="custom-select select2 dependable-select" data-initiates="sel-subcounties" data-list="districts">
                  <option value="0" selected>Select District</option>
                  <?php
                      foreach($arrDistricts as $district)
                      {
                    ?>
                    <option value="<?php echo $district['district_id'];?>">
                      <?php echo ucwords(strtolower($district['district_name']));?>
                    </option>
                    <?php
                      }
                    ?>
                </select>
              </div>
              <div class="form-group col-md-4">
                <label>Subcounty</label>
                <select id="sel-subcounties" name="subcounty_id" class="custom-select">
                  <option value="0" selected>Select Subcounty</option>
                </select>
              </div>
              <div class="form-group col-md-4">
                <label>Status Of Site</label>
                <select id="sel-counties" name="county_id" class="custom-select">
                  <option value="" selected>Choose Status</option>
                  <option value="2019">Functional</option>
                  <option value="2018">Non-functional</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-4">
                <label for="usergroup">Number</label>
                <input type="number" class="form-control" id="district_name" value="" name="district_name" placeholder="" required>
              </div>
            </div>           
            <div class="form-row">
              <div class="form-group col-md-8">
                <button type="submit" class="btn btn-primary">Submit Form</button>
              </div>
            </div>
            
            
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>