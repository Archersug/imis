<?php
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Project Settings</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Default Presets</h4>
      </div>
    </div>

    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>
    <div class="row row-xs" style="margin-bottom: 20px;">
      <div class="col-sm-12 col-lg-12">
        <div data-label="" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/default-presets.php" method="post" data-parsley-validate>
            <input type="hidden" name="setting_name" value="approval_level">
            <input type="hidden" name="setting_date" value="<?php echo date("Y-m-d H:i:s");?>">
            <input type="hidden" name="user_id" value="<?php echo $_SESSION['USER']['ICOLEW_USERID'];?>">
            <fieldset class="form-fieldset">
              <legend>Approval Level</legend>
              <div class="form-row">
                <div class="form-group col-md-12">
                  <label class="d-block">Default approval level specifies the approval level required for data entered before it appears on the reports for consumption. </label>
                  <div class="custom-control custom-radio">
                    <input type="radio" id="radio-approval-1" name="setting_value" class="custom-control-input" value="3"<?php echo ($arrProjectSettings[0]['setting_value']=='3')? ' checked':''; ?>>
                    <label class="custom-control-label" for="radio-approval-1">Level 3 (National)</label>
                  </div>

                  <div class="custom-control custom-radio">
                    <input type="radio" id="radio-approval-2" name="setting_value" class="custom-control-input" value="2"<?php echo ($arrProjectSettings[0]['setting_value']=='2')? ' checked':''; ?>>
                    <label class="custom-control-label" for="radio-approval-2">Level 2 (District)</label>
                  </div>

                  <div class="custom-control custom-radio">
                    <input type="radio" id="radio-approval-3" name="setting_value" class="custom-control-input" value="1"<?php echo ($arrProjectSettings[0]['setting_value']=='1')? ' checked':''; ?>>
                    <label class="custom-control-label" for="radio-approval-3">Level 1 (Subcounty)</label>
                  </div>
                  <!-- <p class="tx-gray-500" style="padding: 5px;">A comment</p> -->
                </div>
              </div>

              <div class="form-row">
                <div class="form-group col-md-8">
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>