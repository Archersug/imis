<?php
  $arrUsergroups = dbGetUsergroups();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Users</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Add User</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="New User" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/users-add.php" method="post" data-parsley-validate>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="fullname">Name</label>
                <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Name" required>
              </div>
              <div class="form-group col-md-6">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="phone">Phone</label>
                <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone">
              </div>
              <div class="form-group col-md-6">
                <label for="usergroup">Usergroup</label>
                <select class="custom-select" name="usergroup_id" required>
                  <option value="" selected> </option>
                  <?php
                    foreach($arrUsergroups as $group)
                    {
                  ?>
                  <option value="<?php echo $group['usergroup_id'];?>"><?php echo $group['usergroup_name'];?></option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="inputAddress">Address</label>
              <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
            </div>
            <div class="form-group">
              <label for="inputPassword">Password</label>
              <input type="text" class="form-control" id="inputPassword" name="password" placeholder="" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit Form</button>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>