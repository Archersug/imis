<?php
  if(isset($_SESSION['USER']['ASSIGNMENTS']['locations']))
  {
    $arrCoordinators = dbGetCLCCoordinators();
    
    $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['districts']);
    $arrDistricts = dbGetUserDistrict($options);

    $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['subcounties']);
    $arrSubcounties = dbGetUserSubcounties($options);  
  }
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Profiles</a></li>
            <li class="breadcrumb-item active" aria-current="page">CLCs</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Add Community Learning Center (CLC)</h4>
      </div>
    </div>
    <?php
      if(isset($_SESSION['USER']['ASSIGNMENTS']['locations']))
      {
    ?>
    <form action="<?php echo $ROOT_FOLDER;?>process/clcs-add.php" method="post" data-parsley-validate>
      <input type="hidden" name="date_entered" value="<?php echo date("Y-m-d H:i:s");?>">
      <input type="hidden" name="user_id" value="<?php echo $_SESSION['USER']['ICOLEW_USERID'];?>">
      <div class="row row-xs">
        
        <div class="col-sm-12 col-lg-6">
          <div data-label="Location" class="df-example demo-table">
            
              <div class="form-row">

                <div class="form-group col-md-12">
                  <label for="subregion_id">District</label>
                  <select class="custom-select dependable-select" data-initiates="sel-subcounties" data-list="districts" id="sel-districts">
                    <?php
                      if(!empty($arrDistricts))
                      {
                        foreach($arrDistricts as $district)
                        {
                        ?>
                          <option value="<?php echo $district['district_id'];?>">
                            <?php echo $district['district_name'];?> </option>
                        <?php
                        }
                      }
                    ?>
                  </select>
                </div>

                <div class="form-group col-md-12">
                  <label for="subregion_id">Subcounty</label>
                  <select class="custom-select dependable-select" data-initiates="sel-parishes" data-list="subcounties" id="sel-subcounties">
                    <option value="" selected=""></option>
                    <?php
                      if(!empty($arrSubcounties))
                      {
                        foreach($arrSubcounties as $sub)
                        {
                        ?>
                          <option value="<?php echo $sub['subcounty_id'];?>"> 
                            <?php echo $sub['subcounty_name'];?>
                          </option>
                        <?php
                        }
                      }
                    ?>
                    
                  </select>
                </div>

                <div class="form-group col-md-12">
                  <label for="subregion_id">Parish</label>
                  <select class="custom-select dependable-select" data-initiates="sel-villages" data-list="parishes" id="sel-parishes" name="parish_id" required>
                    <option value="" selected> </option>
                  </select>
                </div>

                <!-- <div class="form-group col-md-12">
                  <label for="subregion_id">Village</label>
                  <select class="custom-select" id="sel-villages" name="village_id" required>
                    <option value="" selected> </option>
                  </select>
                </div> -->
              </div>
            
          </div>
        </div><!-- col -->
        <div class="col-sm-12 col-lg-6">
          <div data-label="CLC Details" class="df-example demo-table">
            
              <div class="form-row">
                <div class="form-group col-md-12">
                  <label for="clc_name">CLC Name</label>
                  <input type="text" class="form-control" id="clc_name" value="" name="clc_name" placeholder="CLC Name" required>
                </div>

                <!-- <div class="form-group col-md-12">
                  <label for="clc_code">CLC Code</label>
                  <input type="text" class="form-control" id="clc_code" value="" name="clc_code" placeholder="CLC Code" required>
                </div> -->

                <div class="form-group col-md-6">
                  <label for="beneficiary_dob">Date Established</label>
                  <input type="text" class="form-control" id="datepicker-establishment" name="date_established" placeholder="Select Date">
                </div>

                <!-- <div class="form-group col-md-12">
                  <label for="clc_phone">Phone Number</label>
                  <input type="text" class="form-control" id="clc_phone" value="" name="clc_phone" placeholder="Phone Number">
                </div> -->

                <!-- <div class="form-group col-md-12">
                  <label for="clc_email">Email</label>
                  <input type="text" class="form-control" id="clc_email" value="" name="clc_email" placeholder="Email">
                </div> -->

                <div class="form-group col-md-12">
                  <label for="clc_coordinates">CLC coordinates</label>
                  <input type="text" class="form-control" id="clc_coordinates" value="" name="clc_coordinates" placeholder="CLC Coordinates">
                </div>
              
              <div class="form-group col-md-12">
                <label for="coordinator_id">Coordinator</label>
                <select class="custom-select" name="coordinator_id" required>
                  <option value="" selected> </option>
                  <?php
                    if(!empty($arrCoordinators))
                    {
                      foreach($arrCoordinators as $coord)
                      {
                      ?>
                        <option value="<?php echo $coord['coordinator_id'];?>"><?php echo $coord['fullname'];?> </option>
                      <?php
                      }
                    }
                  ?>
                  
                </select>
                </div>
              </div>
              <button type="submit" class="btn btn-primary">Add</button>
            
          </div>
        </div><!-- col -->
        
      </div><!-- row -->
    </form>
    <?php
      }
      else
      {
      ?>
        <div class="alert alert-primary d-flex align-items-center" role="alert">
          <i data-feather="alert-circle" class="mg-r-10"></i> You have not been assigned to a location. You cannot complete this action.
        </div>
      <?php
      }
    ?>

  </div><!-- container -->
</div>