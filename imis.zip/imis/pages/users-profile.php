<?php
  $arrUser = dbGetUserProfile($displayedPage['item']);
  $arrAssignments = dbGetUserAssignments($displayedPage['item']);
  //print_r($arrAssignments);
?>

<div class="content-body">
  <div class="container pd-x-0 tx-13">
    <div class="media d-block d-lg-flex">
      <div class="profile-sidebar profile-sidebar-two pd-lg-r-15">

        <div class="row">
          <div class="col-sm-3 col-md-2 col-lg">
            <div class="avatar avatar-xxl avatar-online">
              <img src="<?php echo $ROOT_FOLDER;?>assets/img/user-icon.svg" class="rounded-circle" alt="">
            </div>
          </div><!-- col -->
        </div>
        <div class="row">
          <div class="col-sm-8 col-md-7 col-lg mg-t-20 mg-sm-t-0 mg-lg-t-25">
            <h4 class="mg-b-2 tx-spacing--1"><?php echo $arrUser['fullname'];?></h4>
            <p class="tx-color-03 mg-b-25"><?php echo $arrUser['usergroup_name'];?></p>
          </div><!-- col -->
        </div>
        <div class="row">
          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <label class="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">Bio Data</label>
            <ul class="list-inline list-inline-skills">
              <li class="list-inline-item"><a><?php echo $arrUser['gender'];?></a></li>
              <li class="list-inline-item"><a href=""><?php echo $arrUser['status'];?></a></li>
              
            </ul>
          </div><!-- col -->
        </div>
        <div class="row">
          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <label class="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">Contact Information</label>
            <ul class="list-unstyled profile-info-list">
              <li><i data-feather="mail"></i> <?php echo $arrUser['email'];?></li>
              <li><i data-feather="phone"></i> <?php echo $arrUser['phone'];?></li>
              
            </ul>
          </div><!-- col -->
        </div>

        <div class="row">
          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <div class="d-flex mg-b-25">
              <a href="<?php echo $ROOT_FOLDER . "users/edit/" . $displayedPage['item'];?>" class="btn btn-xs btn-success flex-fill mg-l-10">Edit User</a>
            </div>
          </div><!-- col -->
        </div>

        

      </div><!-- profile-sidebar -->
      <div class="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">

        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">User Profile</h6>

          </div><!-- card-header -->
          <div class="card-body pd-25">
            <div class="media d-block d-sm-flex">
                <div class="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                <span class="d-block tx-13 tx-color-03"></span>
                <fieldset class="form-fieldset">
                  <legend>Current Assignments</legend>
                  <div class="form-row">
                    <div class="form-group col-md-12" id="div-assigned">
                      <table class="table">
                        <thead>
                          <tr>
                            <th scope="col" class="wd-5">#</th>
                            <th scope="col" class="wd-70">Location</th>
                            <th scope="col">Assignment</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                            if(!empty($arrAssignments))
                            {
                            ?>
                              <tr>
                                <th scope="row">1</th>
                                <td>District</td>
                                <td><?php echo $arrAssignments['district'];?></td>
                              </tr>
                              <tr>
                                <th scope="row">2</th>
                                <td>Subcounties</td>
                                <td><?php echo $arrAssignments['subcounties'];?></td>
                              </tr>
                              <tr>
                                <th scope="row">3</th>
                                <td>Parishes</td>
                                <td><?php echo $arrAssignments['parishes'];?></td>
                              </tr>
                              <tr>
                                <th scope="row">4</th>
                                <td>CLCs</td>
                                <td><?php echo $arrAssignments['clcs'];?></td>
                              </tr>
                              <tr>
                                <th scope="row">5</th>
                                <td>Villages</td>
                                <td><?php echo $arrAssignments['villages'];?></td>
                              </tr>
                              <tr>
                                <th scope="row">6</th>
                                <td>CEGs</td>
                                <td><?php echo $arrAssignments['cegs'];?></td>
                              </tr>
                            <?php
                            }
                          ?>

                        </tbody>
                      </table>
                    </div>
                  </div>
                </fieldset>
              </div>
              
            </div><!-- media -->
          </div>
        </div><!-- card -->

      </div><!-- media-body -->

    </div><!-- media -->
  </div><!-- container -->
</div><!-- content-body -->