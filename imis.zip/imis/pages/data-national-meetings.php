<?php
  $arrDistricts = dbGetAllDistricts();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Data Entry</a></li>
            <li class="breadcrumb-item active" aria-current="page">Meetings</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">National Meetings</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Data Form" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/users-add.php" method="post" data-parsley-validate>
          <div class="form-row">
            <div class="form-group col-md-4">
              <label>Meeting Type</label>
              <select id="sel-activities" name="type_id" class="custom-select" required>
                <option value="" selected>Choose One</option>
                <option value="">Review</option>
                <option value="">Planning</option>
                <?php
                  foreach($arrEventTypes as $type)
                  {
                  ?>
                    <option value="<?php echo $type['type_id'];?>">
                      <?php echo $type['type_name'];?>
                      </option>
                  <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-8">
              <label for="event_name">Meeting Name</label>
              <input type="text" class="form-control" id="" name="event_name" placeholder="District Name" value="" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="message-text" class="col-form-label">Meeting Description:</label>
              <textarea class="form-control" id="" name="event_description"></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">Start Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item" name="start_date" placeholder="Select Date" required>
            </div>
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">End Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item1" name="end_date" placeholder="Select Date" required>
            </div>
          </div>           
            <div class="form-row">
              <div class="form-group col-md-8">
                <button type="submit" class="btn btn-primary">Submit Form</button>
              </div>
            </div>
            
            
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>