<?php
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">System</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">API</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="API" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/regions-add.php" method="post" data-parsley-validate>
            <div class="form-row">
              <div class="form-group col-md-6">
                <div class="custom-control custom-switch">
                  <input type="checkbox" class="custom-control-input" id="customSwitch1" checked>
                  <label class="custom-control-label" for="customSwitch1">Switch API On/Off</label>
                </div>
              </div>
            </div>
            <!-- <button type="submit" class="btn btn-primary">Submit Form</button> -->
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>