<?php
  $arrBeneficiaries = dbGetBeneficiaries();
  $numBen = dbGetBeneficiariesNumber();
  $numCegs = dbGetCEGsNumber();
  $numCLCs = dbGetCLCsNumber();
  $options = array(
                'start_date' => $arrProjectSettings['cycle_start_date'], 
                'stop_date' => $arrProjectSettings['cycle_end_date']
              );
  $totalSavings = dbGetTotalSavings($options);
  $averageSavings = dbGetAverageSavings($options);
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Oversight</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Welcome to Oversight Dashboard</h4>
      </div>

    </div>
    <div class="row row-xs">
      <div class="col-sm-6 col-lg-3">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Beneficiary Enrollment</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">63%</h3>
          </div>
          <div class="chart-three">
              <div id="flotChart3" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-3 mg-t-10 mg-sm-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Number of Beneficiaries</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
              <?php echo number_format($numBen);?>
            </h3>
          </div>
          <div class="chart-three">
              <div id="flotChart4" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-3 mg-t-10 mg-lg-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">No. of CEGs</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
              <?php echo number_format($numCegs);?>
            </h3>
          </div>
          <div class="chart-three">
              <div id="flotChart5" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-sm-6 col-lg-3 mg-t-10 mg-lg-t-0">
        <div class="card card-body">
          <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">No. of CLCs</h6>
          <div class="d-flex d-lg-block d-xl-flex align-items-end">
            <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
              <?php echo $numCLCs;?>
            </h3>
          </div>
          <div class="chart-three">
              <div id="flotChart6" class="flot-chart ht-30"></div>
            </div><!-- chart-three -->
        </div>
      </div><!-- col -->
      <div class="col-lg-12 col-xl-12 mg-t-10">
        <div class="card">
          <div class="card-header pd-y-20 d-md-flex align-items-center justify-content-between">
            <h6 class="mg-b-0">VSLA Savings</h6>
            <ul class="list-inline d-flex mg-t-20 mg-sm-t-10 mg-md-t-0 mg-b-0">
              <li class="list-inline-item d-flex align-items-center">
                <span class="d-block wd-10 ht-10 bg-df-1 rounded mg-r-5"></span>
                <span class="tx-sans tx-uppercase tx-10 tx-medium tx-color-03">Growth Actual</span>
              </li>
              <li class="list-inline-item d-flex align-items-center mg-l-5">
                <span class="d-block wd-10 ht-10 bg-df-2 rounded mg-r-5"></span>
                <span class="tx-sans tx-uppercase tx-10 tx-medium tx-color-03">Actual</span>
              </li>
              <li class="list-inline-item d-flex align-items-center mg-l-5">
                <span class="d-block wd-10 ht-10 bg-df-3 rounded mg-r-5"></span>
                <span class="tx-sans tx-uppercase tx-10 tx-medium tx-color-03">Target</span>
              </li>
            </ul>
          </div><!-- card-header -->
          <div class="card-body pos-relative pd-0">
            <div class="pos-absolute t-20 l-20 wd-xl-100p z-index-10">
              <div class="row">
                <div class="col-sm-5">
                  <h3 class="tx-normal tx-rubik tx-spacing--2 mg-b-5">UGX <?php echo number_format($totalSavings);?></h3>
                  <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-10">Total Savings For Current Cycle</h6>
                  <p class="mg-b-0 tx-12 tx-color-03">Measure How Fast You’re Growing Monthly Recurring Revenue. <a href="">Learn More</a></p>
                </div><!-- col -->
                <div class="col-sm-5 mg-t-20 mg-sm-t-0">
                  <h3 class="tx-normal tx-rubik tx-spacing--2 mg-b-5">UGX <?php echo number_format($averageSavings);?></h3>
                  <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-10">Avg. Contribution/Beneficiary</h6>
                  <p class="mg-b-0 tx-12 tx-color-03">The revenue generated per account on a monthly or yearly basis. <a href="">Learn More</a></p>
                </div><!-- col -->
              </div><!-- row -->
            </div>

            <div class="chart-one">
              <div id="flotChart" class="flot-chart"></div>
            </div><!-- chart-one -->
          </div><!-- card-body -->
        </div><!-- card -->
      </div>


      <div class="col-lg-12 col-xl-8 mg-t-10">
        <div class="card mg-b-10">
          <div class="card-header pd-t-20 d-sm-flex align-items-start justify-content-between bd-b-0 pd-b-0">
            <div>
              <h6 class="mg-b-5">ICOLEW Component Progress</h6>
              <p class="tx-13 tx-color-03 mg-b-0">Component Units progress this cycle</p>
            </div>
            <div class="d-flex mg-t-20 mg-sm-t-0">
              <div class="btn-group flex-fill">
                <button class="btn btn-white btn-xs active">Range</button>
                <button class="btn btn-white btn-xs">Period</button>
              </div>
            </div>
          </div><!-- card-header -->
          <div class="card-body pd-y-30">
            <div class="d-sm-flex">
              <div class="media">
                <div class="wd-40 wd-md-50 ht-40 ht-md-50 bg-success tx-white mg-r-10 mg-md-r-10 d-flex align-items-center justify-content-center rounded op-6">
                  <i data-feather="bar-chart-2"></i>
                </div>
                <div class="media-body">
                  <h6 class="tx-sans tx-uppercase tx-10 tx-spacing-1 tx-color-03 tx-semibold tx-nowrap mg-b-5 mg-md-b-8">Complete Units</h6>
                  <h4 class="tx-20 tx-sm-18 tx-md-20 tx-normal tx-rubik mg-b-0">84</h4>
                </div>
              </div>
              <div class="media mg-t-20 mg-sm-t-0 mg-sm-l-15 mg-md-l-40">
                <div class="wd-40 wd-md-50 ht-40 ht-md-50 bg-primary tx-white mg-r-10 mg-md-r-10 d-flex align-items-center justify-content-center rounded op-5">
                  <i data-feather="bar-chart-2"></i>
                </div>
                <div class="media-body">
                  <h6 class="tx-sans tx-uppercase tx-10 tx-spacing-1 tx-color-03 tx-semibold mg-b-5 mg-md-b-8">On-going Units</h6>
                  <h4 class="tx-20 tx-sm-18 tx-md-20 tx-normal tx-rubik mg-b-0">263</h4>
                </div>
              </div>
              <div class="media mg-t-20 mg-sm-t-0 mg-sm-l-15 mg-md-l-40">
                <div class="wd-40 wd-md-50 ht-40 ht-md-50 bg-danger tx-white mg-r-10 mg-md-r-10 d-flex align-items-center justify-content-center rounded op-4">
                  <i data-feather="bar-chart-2"></i>
                </div>
                <div class="media-body">
                  <h6 class="tx-sans tx-uppercase tx-10 tx-spacing-1 tx-color-03 tx-semibold mg-b-5 mg-md-b-8">Pending Units</h6>
                  <h4 class="tx-20 tx-sm-18 tx-md-20 tx-normal tx-rubik mg-b-0">465</h4>
                </div>
              </div>
            </div>
          </div><!-- card-body -->
          <div class="table-responsive">
            <table class="table table-dashboard mg-b-0">
              <thead>
                <tr>
                  <th>District</th>
                  <th class="text-right">CEGs</th>
                  <th class="text-right">Complete</th>
                  <th class="text-right">On-going</th>
                  <th class="text-right">Pending</th>
                  <th class="text-right">% Complete</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="tx-color-03 tx-normal">Nwoya</td>
                  <td class="tx-medium text-right">9</td>
                  <td class="text-right tx-teal">25</td>
                  <td class="text-right tx-pink">43</td>
                  <td class="tx-medium text-right">75</td>
                  <td class="text-right tx-teal">23</td>
                </tr>
                <tr>
                  <td class="tx-color-03 tx-normal">Mpigi</td>
                  <td class="tx-medium text-right">6</td>
                  <td class="text-right tx-teal">13</td>
                  <td class="text-right tx-pink">31</td>
                  <td class="tx-medium text-right">50</td>
                  <td class="text-right tx-teal">17</td>
                </tr>
                <tr>
                  <td class="tx-color-03 tx-normal">Namayingo</td>
                  <td class="tx-medium text-right">5</td>
                  <td class="text-right tx-teal">10</td>
                  <td class="text-right tx-pink">15</td>
                  <td class="tx-medium text-right">36</td>
                  <td class="text-right tx-teal">15</td>
                </tr>
                <tr>
                  <td class="tx-color-03 tx-normal">Rukungiri</td>
                  <td class="tx-medium text-right">3</td>
                  <td class="text-right tx-teal">6</td>
                  <td class="text-right tx-pink">7</td>
                  <td class="tx-medium text-right">27</td>
                  <td class="text-right tx-teal">13</td>
                </tr>
              </tbody>
            </table>
          </div><!-- table-responsive -->
        </div><!-- card -->

        <div class="card card-body ht-lg-100">
          <div class="media">
            <span class="tx-color-04"><i data-feather="download" class="wd-60 ht-60"></i></span>
            <div class="media-body mg-l-20">
              <h6 class="mg-b-10">Download the report in Excel format.</h6>
              <p class="tx-color-03 mg-b-0">Open it in a spreadsheet and perform your own calculations, graphing etc.</p>
            </div>
          </div><!-- media -->
        </div>
      </div><!-- col -->
      <div class="col-md-6 col-xl-4 mg-t-10">
        <div class="card ht-100p">
          <div class="card-header d-flex align-items-center justify-content-between">
            <h6 class="mg-b-0">Latest CEGs Established</h6>
            <div class="d-flex tx-18">
              <a href="" class="link-03 lh-0"><i class="icon ion-md-refresh"></i></a>
              <a href="" class="link-03 lh-0 mg-l-10"><i class="icon ion-md-more"></i></a>
            </div>
          </div>
          <ul class="list-group list-group-flush tx-13">
            <li class="list-group-item d-flex pd-sm-x-20">
              <div class="avatar d-none d-sm-block"><span class="avatar-initial rounded-circle bg-teal"><i class="icon ion-md-checkmark"></i></span></div>
              <div class="pd-sm-l-10">
                <p class="tx-medium mg-b-0">Moko Oran CEG</p>
                <small class="tx-12 tx-color-03 mg-b-0">Alero, Nwoya District</small>
              </div>
              <div class="mg-l-auto text-right">
                <p class="tx-medium mg-b-0">28</p>
                <small class="tx-12 tx-success mg-b-0">Dec 16, 2020</small>
              </div>
            </li>
            <li class="list-group-item d-flex pd-sm-x-20">
              <div class="avatar d-none d-sm-block"><span class="avatar-initial rounded-circle bg-indigo op-5"><i class="icon ion-md-checkmark"></i></span></div>
              <div class="pd-sm-l-10">
                <p class="tx-medium mg-b-2">Can Wik Malan</p>
                <small class="tx-12 tx-color-03 mg-b-0">Adumi, Arua District</small>
              </div>
              <div class="mg-l-auto text-right">
                <p class="tx-medium mg-b-2">26</p>
                <small class="tx-12 tx-success mg-b-0">Dec 14, 2020</small>
              </div>
            </li>
            <li class="list-group-item d-flex pd-sm-x-20">
              <div class="avatar d-none d-sm-block"><span class="avatar-initial rounded-circle bg-orange op-5"><i class="icon ion-md-checkmark"></i></span></div>
              <div class="pd-sm-l-10">
                <p class="tx-medium mg-b-2">Mivule Twegatte CEG</p>
                <small class="tx-12 tx-color-03 mg-b-0">Mpenja, Gomba District</small>
              </div>
              <div class="mg-l-auto text-right">
                <p class="tx-medium mg-b-2">30</p>
                <small class="tx-12 tx-success mg-b-0">Dec 9, 2020</small>
              </div>
            </li>
            <li class="list-group-item d-flex pd-sm-x-20">
              <div class="avatar d-none d-sm-block"><span class="avatar-initial rounded-circle bg-teal"><i class="icon ion-md-checkmark"></i></span></div>
              <div class="pd-sm-l-10">
                <p class="tx-medium mg-b-0">Tuvudde Wala CEG</p>
                <small class="tx-12 tx-color-03 mg-b-0">Kayunga, Mukono District</small>
              </div>
              <div class="mg-l-auto text-right">
                <p class="tx-medium mg-b-0">29</p>
                <small class="tx-12 tx-success mg-b-0">Dec 5, 2020</small>
              </div>
            </li>
            <li class="list-group-item d-flex pd-sm-x-20">
              <div class="avatar d-none d-sm-block"><span class="avatar-initial rounded-circle bg-gray-400"><i class="icon ion-md-checkmark"></i></span></div>
              <div class="pd-sm-l-10">
                <p class="tx-medium mg-b-0">Kibaare United</p>
                <small class="tx-12 tx-color-03 mg-b-0">Bumbaire, Bushenyi District</small>
              </div>
              <div class="mg-l-auto text-right">
                <p class="tx-medium mg-b-0">28</p>
                <small class="tx-12 tx-success mg-b-0">Dec 4, 2020</small>
              </div>
            </li>
          </ul>
          <div class="card-footer text-center tx-13">
            <a href="" class="link-03">View All CEGs <i class="icon ion-md-arrow-down mg-l-5"></i></a>
          </div><!-- card-footer -->
        </div><!-- card -->
      </div>
    </div><!-- row -->
  </div><!-- container -->
</div>