<?php
//error_reporting(4);
/*
if (!isset($_SESSION['username'])) {
    session_start();
}
 

require_once('connections/lib_connect7.php');
//declare globals & DB connectivity
date_default_timezone_set("Etc/GMT-3");

//$connect = new MySQL();
$obj = new GraphManager('');
$fyr=$_SESSION['ActiveFyear'];
$qtr=$_SESSION['Activequarter'];
$distr=$_SESSION['ActiveDistrictCode'];
*/
/*Dashboard filter parameters*/


?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MGLSD:IMIS-Dashboard</title>

    <!-- Bootstrap Core CSS -->
    <link href="assets/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="assets/stylesheets/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <!----><link href="assets/fontawesome-free-5.0.12/web-fonts-with-css/css/fontawesome-all.css"
          rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <!-- Highmaps CSS -->
    <link href="assets/Highmaps-6.1.0/code/css/highmaps_ug.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]background-color:#157fcc;-->
<style type="text/css">
#container {
  min-width: 310px;
  max-width: 800px;
  height: 400px;
  margin: 0 auto
}

.reportingPeriod {
	width:180px;
	font-weight:bolder;
	color:#093;
	font-size:16px;
		}
.buttons {
  min-width: 310px;
  text-align: center;
  margin-bottom: 1.5rem;
  font-size: 0;
}

.buttons button {
  cursor: pointer;
  border: 1px solid silver;
  border-right-width: 0;
  background-color: #f8f8f8;
  font-size: 1rem;
  padding: 0.5rem;
  outline: none;
  transition-duration: 0.3s;
}

.buttons button:first-child {
  border-top-left-radius: 0.3em;
  border-bottom-left-radius: 0.3em;
}

.buttons button:last-child {
  border-top-right-radius: 0.3em;
  border-bottom-right-radius: 0.3em;
  border-right-width: 1px;
}

.buttons button:hover {
  color: white;
  background-color: rgb(158, 159, 163);
  outline: none;
}

.buttons button.active {
  background-color: #0051B4;
  color: white;
}

		</style>
</head>

<body>
<!--<div id="wrapper">
    <div id="page-wrapper">-->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!--<div class="panel-heading">
                        Dashboard
                    </div>-->
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <!-- Nav tabs -->
                        <?php //require_once('connections/tabs.php'); ?>

                        <!-- Tab panes -->
                        <div class="tab-content">
                        
                            <div class="tab-pane fade in active" id="home">
                               
                                <div class="container-fluid">
        <!--first row-->
        
        

                                <!-- /.end of first row -->
                                
                                
                                 <!-- /.row -->
                               <div class="row">
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;"># of Beneficiaries saving per Month</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_1">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                    
                                    
                                    
                                    
                              
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;">Amount of savings per month</strong></div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_2">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                </div>
                                <!-- /.row -->
                                
                                
                                
                                <!-- /.row -- start of row 2-->
                               <div class="row">
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading"><strong style="font-size:18px; font-weight:bold;"># of loans issued per Month</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_3">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                    
                                    
                                    
                                    
                              
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;">Amount of loans issued per Month</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_4">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                </div>
                                <!-- /.row -->
                                <!-- start of third row-->
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading"><strong style="font-size:18px; font-weight:bold;"># of loans Cleared</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_5">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                    
                                    
                                    
                                    
                              
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;">Value of loans Cleared</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_6">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                </div>
                                <!-- /.row -->
                            <!---start of forth row-->
                            <div class="row">
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading"><strong style="font-size:18px; font-weight:bold;"># of loans pending clearance</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_7">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                    
                                    
                                    
                                    
                              
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;">Value of loan pending</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_8">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                </div>
                                <!-- /.row -->
                                
                            </div>
                            
                            
                                </div>
                                <!-- /.row -->
                            </div>

                        </div>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        
    <!--</div>-->
    <!-- /#page-wrapper -->

<!--</div>-->
<!-- /#wrapper -->




<!-- jQuery -->

<script src="assets/javascripts/jquery-3.3.1.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="assets/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
<!-- Custom Theme JavaScript -->
<script src="assets/javascripts/sb-admin-2.js"></script>
<script src="assets/Highcharts-6.1.0/code/highcharts.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/map.js"></script>
<script src="assets/Highcharts-6.1.0/code/highcharts-3d.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/exporting.js"></script>
<script src="assets/Highcharts-6.1.0/code/modules/export-data.js"></script>
<script src="assets/Highmaps-6.1.0/code/ug-all.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/data.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/drilldown.js"></script>
<script src="../../code/highcharts.js"></script>
<script src="../../code/modules/exporting.js"></script>
<script src="../../code/modules/export-data.js"></script>


<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 10-->
<table id="datatable1" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Beneficiary Savings</th>
               
            </tr>
        </thead>
        <tbody>
        <?php
            
		$arrBeneficiarySavings=BeneficiarySavingsGraph();
		  if(!empty($arrBeneficiarySavings))
                {
                 
                  foreach($arrBeneficiarySavings as $row)
                  {
                  ?>
	
		<tr>
		
			<th><?php echo date('Y-M',strtotime($row['month'])); ?></th>
		    <td><?php echo $row['saving']; ?></td>
		</tr>
		<?php
		//
		}
				}
		
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_1', {
    data: {
        table: 'datatable1'
    },
    chart: {
        type: 'bar'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Number'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>
        
  
  <!-- Amount of Savings--->
  
  
<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 10-->
<table id="datatable2" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Beneficiary Savings</th>
                
               
            </tr>
        </thead>
        <tbody>
         <?php
            $arrBeneficiarySavings=BeneficiaryAmountofSavingsGraph();
			
		
		if(!empty($arrBeneficiarySavings))
                {
                 
                  foreach($arrBeneficiarySavings as $row)
                  {
                  ?>
	
		<tr>
		
			<th><?php echo date('Y-M',strtotime($row['month'])); ?></th>
		    <td><?php echo $row['saving']; ?></td>
		</tr>
		<?php
		//
		}
				}
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_2', {
    data: {
        table: 'datatable2'
    },
    chart: {
        type: 'bar'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Amount'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>

       
       
       
        <!-- # of loans issued per Month--->
  
  
<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 3-->
<table id="datatable3" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Beneficiary Loans</th>
                
               
            </tr>
        </thead>
        <tbody>
         <?php
         
		
		 $arrBeneficiarySavings=BeneficiaryNoofLoansGraph();
			
		
		if(!empty($arrBeneficiarySavings))
                {
                 
                  foreach($arrBeneficiarySavings as $row)
                  {
                  ?>
	
		<tr>
		
			<th><?php echo date('Y-M',strtotime($row['month'])); ?></th>
		    <td><?php echo $row['saving']; ?></td>
		</tr>
		<?php
		//
		}
				}
		
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_3', {
    data: {
        table: 'datatable3'
    },
    chart: {
        type: 'bar'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Number'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>
        
        
        <!-- Amount of loans issued per Month--->
  
  
<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 10-->
<table id="datatable4" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Amount of Loans</th>
                
               
            </tr>
        </thead>
        <tbody>
         <?php
            
			/*$sql="SELECT substr(`date_issued`,1,7) as month,sum(`principal`) as saving FROM `tbl_vsla_loans` WHERE 1 group by substr(`date_issued`,1,7) ";
			 
		$query=@mysqli_query($connect,$sql) or die(mysqli_error($connect));
		while($row=mysqli_fetch_array($query)){*/
	
		
		$arrBeneficiarySavings=BeneficiaryAmountofLoansGraph();
			
		
		if(!empty($arrBeneficiarySavings))
                {
                 
                  foreach($arrBeneficiarySavings as $row)
                  {
                  ?>
	
		<tr>
		
			<th><?php echo date('Y-M',strtotime($row['month'])); ?></th>
		    <td><?php echo $row['saving']; ?></td>
		</tr>
		<?php
		//
		}
				}
		
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_4', {
    data: {
        table: 'datatable4'
    },
    chart: {
        type: 'bar'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Amount'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>
        
          <!-- # of loans cleared--->
  
  
<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 3-->
<table id="datatable5" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Beneficiary Loans</th>
                
               
            </tr>
        </thead>
        <tbody>
         <?php
            

		
		$arrBeneficiarySavings=BeneficiaryNoofLoansClearedGraph();
			
		
		if(!empty($arrBeneficiarySavings))
                {
                 
                  foreach($arrBeneficiarySavings as $row)
                  {
                  ?>
	
		<tr>
		
			<th><?php echo date('Y-M',strtotime($row['month'])); ?></th>
		    <td><?php echo $row['saving']; ?></td>
		</tr>
		<?php
		//
		}
				}
		
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_5', {
    data: {
        table: 'datatable5'
    },
    chart: {
        type: 'bar'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Number'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>
        
        
        <!-- Amount of loans cleared--->
  
  
<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 10-->
<table id="datatable6" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Value of Loans</th>
                
               
            </tr>
        </thead>
        <tbody>
         <?php
           
		
		$arrBeneficiarySavings=BeneficiaryValueofLoansClearedGraph();
			
		
		if(!empty($arrBeneficiarySavings))
                {
                 
                  foreach($arrBeneficiarySavings as $row)
                  {
                  ?>
	
		<tr>
		
			<th><?php echo date('Y-M',strtotime($row['month'])); ?></th>
		    <td><?php echo $row['saving']; ?></td>
		</tr>
		<?php
		//
		}
				}
		
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_6', {
    data: {
        table: 'datatable6'
    },
    chart: {
        type: 'line'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Amount'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>


 <!-- # of loans Pending clearance--->
  
  
<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 3-->
<table id="datatable7" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Beneficiary Loans</th>
                
               
            </tr>
        </thead>
        <tbody>
         <?php
            
					
		$arrBeneficiarySavings=BeneficiaryNoofLoansPendingGraph();
			
		
		if(!empty($arrBeneficiarySavings))
                {
                 
                  foreach($arrBeneficiarySavings as $row)
                  {
                  ?>
	
		<tr>
		
			<th><?php echo date('Y-M',strtotime($row['month'])); ?></th>
		    <td><?php echo $row['saving']; ?></td>
		</tr>
		<?php
		//
		}
				}
		
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_7', {
    data: {
        table: 'datatable7'
    },
    chart: {
        type: 'line'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Number'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>
        
        
        <!-- Amount of loans Pending--->
  
  
<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 8-->
<table id="datatable8" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Value of Loans</th>
                
               
            </tr>
        </thead>
        <tbody>
         <?php
        	
		$arrBeneficiarySavings=BeneficiaryAmountofLoansPendingGraph();
			
		
		if(!empty($arrBeneficiarySavings))
                {
                 
                  foreach($arrBeneficiarySavings as $row)
                  {
                  ?>
	
		<tr>
		
			<th><?php echo date('Y-M',strtotime($row['month'])); ?></th>
		    <td><?php echo $row['saving']; ?></td>
		</tr>
		<?php
		//
		}
				}
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_8', {
    data: {
        table: 'datatable8'
    },
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Amount'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>



<?php 

require_once("connections/footer.php"); ?>
</body>
</html>
