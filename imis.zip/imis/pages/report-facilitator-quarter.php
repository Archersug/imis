<?php
  // Receive report query filters
  if($displayedPage['reportQuery'])
  {
    $region = $displayedPage['reportQuery'][0];
    $subregion = $displayedPage['reportQuery'][1];
    $district = $displayedPage['reportQuery'][2];
    $county = $displayedPage['reportQuery'][3];
    $subcounty = $displayedPage['reportQuery'][4];
    $parish = $displayedPage['reportQuery'][5];
    $clc = $displayedPage['reportQuery'][6];
    $gender = $displayedPage['reportQuery'][7];
    $category = $displayedPage['reportQuery'][8];
    $disabled = $displayedPage['reportQuery'][9];
  }
  else
  {
    $region = '';
    $subregion = '';
    $district = '';
    $county = '';
    $subcounty = '';
    $parish = '';
    $clc = '';
    $gender = '';
    $category = '';
    $disabled = '';
  }

  $arrDistricts = dbGetAllDistricts();
  $arrCLCs = dbGetCLCs();
  $arrCats = dbGetBeneficiaryCategories();

  //----------REPORT Query----------------
  $qBenefs = "SELECT tbl_beneficiaries.*, tbl_beneficiary_categories.category_abbr, 
                tbl_ceg_leadership.position_name
              FROM tbl_beneficiaries
              LEFT JOIN tbl_beneficiary_categories ON tbl_beneficiary_categories.category_id = tbl_beneficiaries.category_id
              LEFT JOIN tbl_ceg_leadership ON tbl_ceg_leadership.position_id = tbl_beneficiaries.position_id
              WHERE 1";

  $arrBenefs = $db->QueryArray($qBenefs, MYSQLI_ASSOC);

  // Set Excel export session query
  $_SESSION['REPORT']['name'] = "Payment Summaries";
  $_SESSION['REPORT']['query'] = $qBenefs;
  $_SESSION['REPORT']['params'] = array(
                                      array("label" => "START DATE", "value" => '$start'),
                                      array("label" => "END DATE", "value" => '$end'),
                                  );
  $_SESSION['REPORT']['headers'] = array("No.", "Date", "Title", "Amount");
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Reports</a></li>
            <li class="breadcrumb-item active" aria-current="page">Perfomance Reports</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1"> Facilitator Quarter</h4>
      </div>
      <div class="d-none d-md-block">
        <div class="dropdown">
          <button class="btn btn-white" onclick="PrintElem('print-div')"><i data-feather="printer" class="mg-r-5"></i> Print</button>
          <!-- <button class="btn btn-white mg-l-5"><i data-feather="mail" class="mg-r-5"></i> Email</button> -->
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Export
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="#">Excel</a>
            <a class="dropdown-item" href="#">PDF</a>
          </div>
        </div>
      </div>
    </div>

  <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
    <div class="d-sm-flex align-items-center justify-content-between">
      <div data-label="Filters" class="df-example demo-table col-md-12">
        <form method="post" action="<?php echo $ROOT_FOLDER;?>process/report-beneficiary-register.php">
          <div class="form-row">
            <div class="form-group col-md-3">
              <label>District</label>
              <select name="district_id" class="custom-select select2 dependable-select" data-initiates="sel-subregions" data-list="regions">
                <option value="0" selected>Select District</option>
                <?php
                    foreach($arrDistricts as $district)
                    {
                  ?>
                  <option value="<?php echo $district['district_id'];?>">
                    <?php echo ucwords(strtolower($district['district_name']));?>
                  </option>
                  <?php
                    }
                  ?>
              </select>
            </div>
            <div class="form-group col-md-3">
              <label>Subcounty</label>
              <select id="sel-counties" name="county_id" class="custom-select">
                <option value="0" selected>Select Subcounty</option>
              </select>
            </div>
            <div class="form-group col-md-3">
              <label>Year</label>
              <select id="sel-counties" name="county_id" class="custom-select">
                <option value="2020" selected>2020</option>
                <option value="2019">2019</option>
                <option value="2018">2018</option>
              </select>
            </div>
            
          </div>

          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  </div><!-- container -->

    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Report" class="df-example demo-table" id="print-div" style="width: 100%;">
          <div style="padding: 10px;">
            <h6>ICOLEW Management Information System</h6>
            <h3>
              Facilitator Quarterly Report
            </h3>
            <div>
              District: Mpigi 
            </div>
          </div>
          <table class="table table-sm table-striped table-bordered">
            <thead>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="wd-15p">Name</th>
                  <th class="wd-10p">Jan-Mar</th>
                  <th class="wd-10p">Apr-Jun</th>
                  <th class="wd-10p">Jul-Sep</th>
                  <th class="wd-10p">Oct-Dec</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $i = 1;
                foreach($arrBenefs as $ben)
                {
              ?>
              <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $ben['beneficiary_name'];?></td>
                  <td><i data-feather="check-circle"></i></td>
                  <td><i data-feather="check-circle"></i></td>
                  <td><i data-feather="check-circle"></i></td>
                  <td><i data-feather="x-circle"></i> </td>
              </tr>
              <?php
                  $i++;
                }
              ?>
            </tbody>
          </table>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>