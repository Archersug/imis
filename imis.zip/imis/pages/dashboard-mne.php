<?php
//error_reporting(4);
/*
if (!isset($_SESSION['username'])) {
    session_start();
}
 
require_once('connections/lib_connect7.php');
//declare globals & DB connectivity*/
date_default_timezone_set("Etc/GMT-3");
$connect = mysqli_connect("localhost", "root", "craiwrut", "db_icolew_v2");
//$connect = new MySQL();
/*$obj = new GraphManager('');
$fyr=$_SESSION['ActiveFyear'];
$qtr=$_SESSION['Activequarter'];
$distr=$_SESSION['ActiveDistrictCode'];
*/
/*Dashboard filter parameters*/


?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MGLSD:IMIS-Dashboard</title>

    <!-- Bootstrap Core CSS -->
    <link href="assets/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="assets/stylesheets/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <!----><link href="assets/fontawesome-free-5.0.12/web-fonts-with-css/css/fontawesome-all.css"
          rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <!-- Highmaps CSS -->
    <link href="assets/Highmaps-6.1.0/code/css/highmaps_ug.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]background-color:#157fcc;-->
<style type="text/css">
#container {
  min-width: 310px;
  max-width: 800px;
  height: 400px;
  margin: 0 auto
}

.reportingPeriod {
	width:180px;
	font-weight:bolder;
	color:#093;
	font-size:16px;
		}
.buttons {
  min-width: 310px;
  text-align: center;
  margin-bottom: 1.5rem;
  font-size: 0;
}

.buttons button {
  cursor: pointer;
  border: 1px solid silver;
  border-right-width: 0;
  background-color: #f8f8f8;
  font-size: 1rem;
  padding: 0.5rem;
  outline: none;
  transition-duration: 0.3s;
}

.buttons button:first-child {
  border-top-left-radius: 0.3em;
  border-bottom-left-radius: 0.3em;
}

.buttons button:last-child {
  border-top-right-radius: 0.3em;
  border-bottom-right-radius: 0.3em;
  border-right-width: 1px;
}

.buttons button:hover {
  color: white;
  background-color: rgb(158, 159, 163);
  outline: none;
}

.buttons button.active {
  background-color: #0051B4;
  color: white;
}

		</style>
</head>

<body>
<!--<div id="wrapper">
    <div id="page-wrapper">-->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!--<div class="panel-heading">
                        Dashboard
                    </div>-->
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <!-- Nav tabs -->
                        <?php //require_once('connections/tabs.php'); ?>

                        <!-- Tab panes -->
                        <div class="tab-content">
                        
                            <div class="tab-pane fade in active" id="home">
                               
                                <div class="container-fluid">
        <!--first row-->
        
        

                                <!-- /.end of first row -->
                                
                                
                                 <!-- /.row -->
                               <div class="row">
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;"># of CEGS by Location</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_1">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                    
                                    
                                    
                                    
                              
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;"># of beneficiaries by Location</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_2">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                </div>
                                <!-- /.row -->
                                
                                
                                
                                <!-- /.row -- start of row 2-->
                               <div class="row">
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;"># of Facilitators trained</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_10">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                    
                                    
                                    
                                    
                              
                                    <div class="col-lg-6">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                             <strong style="font-size:18px; font-weight:bold;"># of graduates per learning Cycle.</strong>
                                                <div class="pull-right">
                                                <i class="fa fa-bar-chart-o fa-fw"></i>
                                                <i class="fa fa-table"></i>
                                      	         <i class="fas fa-map-marker-alt"></i>
                                                  </div>
                                            </div>
                                            <!-- /.panel-heading -->
                                            <!-- <div class='buttons'>
  <button id='Agegrp' class='active'>
    Age Group
  </button>
   <button id='Region'>
    Region
  </button></div>-->
                                            <div class="panel-body">
                                                <div class="graph_wrapper" id="container_Ind_11">
                                                
                                                
                                                </div>
                                            </div>
                                            <!-- /.panel-body -->
                                        </div>
                                        <!-- /.panel -->

                                    </div>
                                    
                                </div>
                                <!-- /.row -->
                                <!-- start of third row-->
                                
                                <!-- /.row -->
                            
                                <!-- /.row -->
                                
                            </div>
                            
                            
                                </div>
                                <!-- /.row -->
                            </div>

                        </div>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    <!--</div>-->
    <!-- /#page-wrapper -->

<!--</div>-->
<!-- /#wrapper -->



<!-- jQuery -->

<script src="assets/javascripts/jquery-3.3.1.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="assets/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
<!-- Custom Theme JavaScript -->
<script src="assets/javascripts/sb-admin-2.js"></script>
<script src="assets/Highcharts-6.1.0/code/highcharts.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/map.js"></script>
<script src="assets/Highcharts-6.1.0/code/highcharts-3d.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/exporting.js"></script>
<script src="assets/Highcharts-6.1.0/code/modules/export-data.js"></script>
<script src="assets/Highmaps-6.1.0/code/ug-all.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/data.js"></script>
<script src="assets/Highmaps-6.1.0/code/modules/drilldown.js"></script>
<script src="../../code/highcharts.js"></script>
<script src="../../code/modules/exporting.js"></script>
<script src="../../code/modules/export-data.js"></script>


<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 10-->
<table id="datatable10" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Facilitators</th>
               
            </tr>
        </thead>
        <tbody>
        <?php
            
			/*$sql="SELECT tbl_training_courses.course_name,tbl_training_courses.course_id, SUM(CASE WHEN tbl_training_facilitators.attendance = '1' THEN 1 ELSE 0 END) AS attended FROM tbl_training_facilitators LEFT JOIN tbl_training_courses ON tbl_training_courses.course_id = tbl_training_facilitators.course_id WHERE 1 group by tbl_training_courses.course_name ";
			 */
			 $arrFacilitators=FacilitatorsTrainedGraph();
		  if(!empty($arrFacilitators))
                {
                 
                  foreach($arrFacilitators as $row)
                  {
                  ?>
	
		
		<tr>
		
			<th><?php echo $row['course_name']; ?></th>
		    <td><?php echo $row['attended']; ?></td>
		</tr>
		<?php
		//
		}
				}
		
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_10', {
    data: {
        table: 'datatable10'
    },
    chart: {
        type: 'bar'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Number'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>
        
  
  <!-- Graduates per learning cycle--->
  
  
<figure class="highcharts-figure">
    <!--<div id="container"></div>-->
    <p class="highcharts-description">
       
    </p>
    <!----Indicator 10-->
<table id="datatable11" style="display:none;">
        <thead>
            <tr>
                <th></th>
                <th>Male</th>
                <th>Female</th>
               
            </tr>
        </thead>
        <tbody>
        <?php
         
		?>
		<tr>
		
			<th>Cohort 1</th>
		    <td>30</td>
            <td>45</td>
		</tr>
		<?php
		//
		//}
		
		 ?>
        </tbody>
    </table>
</figure>


<script type="text/javascript">

Highcharts.chart('container_Ind_11', {
    data: {
        table: 'datatable11'
    },
    chart: {
        type: 'bar'
    },
    title: {
        text: ''
    },subtitle: {
        text: 'Source:MGLSD-ICOLEW'
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: 'Number'
        }
    },
    tooltip: {
        formatter: function () {
            return '<b>' + this.series.name + '</b><br/>' +
                this.point.y + ' ' + this.point.name.toLowerCase();
        }
    },
	plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                },
				column: {
                    dataLabels: {
                        enabled: true
                    }
                },
				line: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
});
		</script>

        <!--start of Map-->
        
        <script>
<?php  //# of CEGS by Location"; ?>
    /*set global highcharts properties*/
    $(function () {


        Highcharts.setOptions({
            colors: [
                '#058DC7',
                '#50B432',
                '#ED561B',
                '#DDDF00',
                '#24CBE5',
                '#64E572',
                '#FF9655',
                '#FFF263',
                '#6AF9C4'
            ],
            lang: {
                thousandsSep: ','
            },

        });
    });
    $(function () {
        // Radialize the colors
        Highcharts.getOptions().colors = Highcharts.map(Highcharts.getOptions().colors, function (color) {
            return {
                radialGradient: {cx: 0.5, cy: 0.3, r: 0.7},
                stops: [
                    [0, color],
                    [1, Highcharts.Color(color).brighten(-0.3).get('rgb')] // darken
                ]
            };
        });
        var data = [

            <?php
            /*map of CEGS by Location/District
              
               */
			
		
			
			
            
                    $ind_8_st = "				
				SELECT d.district_id,d.district_name,d.visual_code,COUNT(c.ceg_name) as mappedAndAssessed FROM `tbl_cegs` c join tbl_villages v on(v.village_id=c.village_id) join tbl_districts d on(v.district_id=d.district_id) GROUP by d.district_name";
                    
                



            $ind_8_q = mysqli_query($connect, $ind_8_st) or mysqli_error($connect);
            while($row_ind_8 = @mysqli_fetch_array($ind_8_q)){
            ?>
            ['ug-<?php echo $row_ind_8['visual_code'];?>', <?php echo $row_ind_8['mappedAndAssessed'];?>],
            <?php } ?>

        ];
        $('#container_Ind_1').highcharts('Map', {
            chart: {
                map: 'countries/ug/ug-all'
            },
            title: {
                text: ''
            },
            mapNavigation: {
                enabled: true,
                buttonOptions: {
                    verticalAlign: 'bottom'
                }
            },
            colors: ['rgba(19,64,117,0.05)', 'rgba(19,64,117,0.2)', 'rgba(19,64,117,0.4)',
                'rgba(19,64,117,0.5)', 'rgba(19,64,117,0.6)', 'rgba(19,64,117,0.8)', 'rgba(19,64,117,1)'],
            colorAxis: {
                dataClasses: [{
                    to: 3,
                    color: "red"
                }, {
                    from: 3,
                    to: 10,
                    color: "yellow"
                }, {
                    from: 10,
                    to: 30,
                    color: "#F7C26A"
                }, {
                    from: 30,
                    to: 100,
                    color: "#F19703"
                }, {
                    from: 100,
                    to: 300,
                    color: "#808080"
                }, {
                    from: 300,
                    to: 1000,
                    color: "purple"
                }, {
                    from: 1000,
                    color: "black"
                }]
            },
            credits: {
                enabled: false
            },
            series: [{
                data: data,

                name: '',
                states: {
                    hover: {
                        color: '#BADA55'
                    }
                },

                dataLabels: {
                    enabled: true,
                    format: '{point.name}: {point.value:,.0f}'
                }
            }]
        });
        $('#container_Ind_1_large').highcharts('Map', {
            chart: {
                map: 'countries/ug/ug-all'
            },
            title: {
                text: ''
            },
            mapNavigation: {
                enabled: true,
                buttonOptions: {
                    verticalAlign: 'bottom'
                }
            },
            colors: ['rgba(19,64,117,0.05)', 'rgba(19,64,117,0.2)', 'rgba(19,64,117,0.4)',
                'rgba(19,64,117,0.5)', 'rgba(19,64,117,0.6)', 'rgba(19,64,117,0.8)', 'rgba(19,64,117,1)'],
            colorAxis: {
                dataClasses: [{
                    to: 3,
                    color: "red"
                }, {
                    from: 3,
                    to: 10,
                    color: "yellow"
                }, {
                    from: 10,
                    to: 30,
                    color: "#F7C26A"
                }, {
                    from: 30,
                    to: 100,
                    color: "#F19703"
                }, {
                    from: 100,
                    to: 300,
                    color: "#808080"
                }, {
                    from: 300,
                    to: 1000,
                    color: "purple"
                }, {
                    from: 1000,
                    color: "black"
                }]
            },
            credits: {
                enabled: false
            },
            series: [{
                data: data,

                name: '',
                states: {
                    hover: {
                        color: '#BADA55'
                    }
                },

                dataLabels: {
                    enabled: true,
                    format: '{point.name}: {point.value:,.0f}'
                }
            }]
        });
    });

   


</script>


<!--map of Beneficaries by Location-->

<script>
/*map of Beneficaries by Location
              */
			  
			  
			   $(function () {


        Highcharts.setOptions({
            colors: [
                '#058DC7',
                '#50B432',
                '#ED561B',
                '#DDDF00',
                '#24CBE5',
                '#64E572',
                '#FF9655',
                '#FFF263',
                '#6AF9C4'
            ],
            lang: {
                thousandsSep: ','
            },

        });
    });
    $(function () {
        // Radialize the colors
        Highcharts.getOptions().colors = Highcharts.map(Highcharts.getOptions().colors, function (color) {
            return {
                radialGradient: {cx: 0.5, cy: 0.3, r: 0.7},
                stops: [
                    [0, color],
                    [1, Highcharts.Color(color).brighten(-0.3).get('rgb')] // darken
                ]
            };
        });
        var data = [

            <?php
            /*map of CEGS by Location/District
              
               */
			
$sql = "SELECT d.district_id,d.district_name,d.visual_code,COUNT(c.`beneficiary_name`) as mappedAndAssessed FROM `tbl_beneficiaries` c join tbl_villages v on(v.village_id=c.village_id) join tbl_districts d on(v.district_id=d.district_id) GROUP by d.district_name ";


            $ind_8_q = mysqli_query($connect, $sql) or mysqli_error($connect);
            while($row_ind_8 = @mysqli_fetch_array($ind_8_q)){
            ?>
            ['ug-<?php echo $row_ind_8['visual_code'];?>', <?php echo $row_ind_8['mappedAndAssessed'];?>],
            <?php } ?>

        ];
        $('#container_Ind_2').highcharts('Map', {
            chart: {
                map: 'countries/ug/ug-all'
            },
            title: {
                text: ''
            },
            mapNavigation: {
                enabled: true,
                buttonOptions: {
                    verticalAlign: 'bottom'
                }
            },
            colors: ['rgba(19,64,117,0.05)', 'rgba(19,64,117,0.2)', 'rgba(19,64,117,0.4)',
                'rgba(19,64,117,0.5)', 'rgba(19,64,117,0.6)', 'rgba(19,64,117,0.8)', 'rgba(19,64,117,1)'],
            colorAxis: {
                dataClasses: [{
                    to: 3,
                    color: "red"
                }, {
                    from: 3,
                    to: 10,
                    color: "yellow"
                }, {
                    from: 10,
                    to: 30,
                    color: "#F7C26A"
                }, {
                    from: 30,
                    to: 100,
                    color: "#F19703"
                }, {
                    from: 100,
                    to: 300,
                    color: "#808080"
                }, {
                    from: 300,
                    to: 1000,
                    color: "purple"
                }, {
                    from: 1000,
                    color: "black"
                }]
            },
            credits: {
                enabled: false
            },
            series: [{
                data: data,

                name: '',
                states: {
                    hover: {
                        color: '#BADA55'
                    }
                },

                dataLabels: {
                    enabled: true,
                    format: '{point.name}: {point.value:,.0f}'
                }
            }]
        });
        $('#container_Ind_2_large').highcharts('Map', {
            chart: {
                map: 'countries/ug/ug-all'
            },
            title: {
                text: ''
            },
            mapNavigation: {
                enabled: true,
                buttonOptions: {
                    verticalAlign: 'bottom'
                }
            },
            colors: ['rgba(19,64,117,0.05)', 'rgba(19,64,117,0.2)', 'rgba(19,64,117,0.4)',
                'rgba(19,64,117,0.5)', 'rgba(19,64,117,0.6)', 'rgba(19,64,117,0.8)', 'rgba(19,64,117,1)'],
            colorAxis: {
                dataClasses: [{
                    to: 3,
                    color: "red"
                }, {
                    from: 3,
                    to: 10,
                    color: "yellow"
                }, {
                    from: 10,
                    to: 30,
                    color: "#F7C26A"
                }, {
                    from: 30,
                    to: 100,
                    color: "#F19703"
                }, {
                    from: 100,
                    to: 300,
                    color: "#808080"
                }, {
                    from: 300,
                    to: 1000,
                    color: "purple"
                }, {
                    from: 1000,
                    color: "black"
                }]
            },
            credits: {
                enabled: false
            },
            series: [{
                data: data,

                name: '',
                states: {
                    hover: {
                        color: '#BADA55'
                    }
                },

                dataLabels: {
                    enabled: true,
                    format: '{point.name}: {point.value:,.0f}'
                }
            }]
        });
    });

   

</script>     
        <!---End of Map--->
        
		

<?php 

require_once("connections/footer.php"); ?>
</body>
</html>
