<?php
  $options = array('budget_id' => $displayedPage['item']);
  $arrBudget = dbGetBudgetDetails($options);
  $arrDistricts = dbGetAllDistricts();
  $arrCategories = dbGetBudgetCategories();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Finance</a></li>
            <li class="breadcrumb-item active" aria-current="page">Budget</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Edit Budget: <?php echo $arrBudget[0]['budget_name'];?></h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Add Budget" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/budgets-edit.php" method="post" data-parsley-validate>
            <input type="hidden" name="date_entered" value="<?php echo $arrBudget[0]['date_entered'];?>">
            <input type="hidden" name="user_id" value="<?php echo $arrBudget[0]['user_id'];?>">
            <input type="hidden" name="budget_id" value="<?php echo $displayedPage['item'];?>">
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="region_id">Category</label>
                <select class="custom-select" name="category_id" required>
                  <option value="" selected> </option>
                  <?php
                    foreach($arrCategories as $cat)
                    {
                  ?>
                  <option value="<?php echo $cat['category_id'];?>"<?php echo ($arrBudget[0]['category_id']==$cat['category_id'])? ' selected':'';?>>
                    <?php echo $cat['category_name'];?>
                  </option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="region_id">District</label>
                <select class="custom-select select2 dependable-select" data-initiates="sel-subcounties" data-list="districts">
                  <option value="" selected> </option>
                  <?php
                    foreach($arrDistricts as $district)
                    {
                  ?>
                  <option value="<?php echo $district['district_id'];?>">
                    <?php echo ucfirst(strtolower($district['district_name']));?>
                  </option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="region_id">Subcounty</label>
                <select class="custom-select" name="subcounty_id" id="sel-subcounties" required>
                  <option value="" selected> </option>
 
                  <option value="<?php echo $arrBudget[0]['subcounty_id'];?>" selected>
                    <?php echo $arrBudget[0]['subcounty_name'];?>
                  </option>

                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="budget_name">Name</label>
                <input type="text" class="form-control" value="<?php echo $arrBudget[0]['budget_name'];?>" name="budget_name" placeholder="Budget Name" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-9">
                <label for="budget_description">Description</label>
                <input type="text" class="form-control" id="budget_description" value="<?php echo $arrBudget[0]['budget_description'];?>" name="budget_description" placeholder="Budget Description" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-3">
                <label for="budget_name">Date</label>
                <input type="text" class="form-control" value="<?php echo $arrBudget[0]['budget_date'];?>" name="budget_date" id="datepicker-date" required>
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Add</button>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>
