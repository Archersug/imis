<?php
  $arrGlossary = dbGetGlossary();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Repository</a></li>
            <li class="breadcrumb-item active" aria-current="page">Glossary</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Glossary</h4>
      </div>
    </div>
    <hr class="mg-y-40 bd-0">
      <table class="table">
        <thead>
          <tr>
            <th scope="col" width="5%">#</th>
            <th scope="col" width="20%">KEYWORD</th>
            <th scope="col">DESCRIPTION</th>
          </tr>
        </thead>
        <tbody>
          <?php
            if(!empty($arrGlossary))
            {
              $i = 1;
              foreach($arrGlossary as $entry)
              {
              ?>
              <tr>
                <td scope="row"><?php echo $i;?></td>
                <td>
                  <b><?php echo $entry['keyword'];?></b>
                </td>
                <td>
                  <div>
                    <?php echo $entry['description'];?>
                  </div>
                </td>
              </tr>
              <?php
                $i++;
              }
            }
          ?>

        </tbody>
      </table>

  </div><!-- container -->
</div>