<?php
  $arrBen = dbGetBeneficiary($displayedPage['item']);
  $arrCats = dbGetBeneficiaryCategories();
  
  if($_SESSION['USER']['USERGROUPID'] < 10)
    $arrCegs = dbGetCegs();
  else
  {
    $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['cegs']);
    $arrCegs = dbGetCegs($options);
  }
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Profiles</a></li>
            <li class="breadcrumb-item active" aria-current="page">Beneficiaries</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Edit Beneficiary: <?php echo $arrBen['beneficiary_name'];?></h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Beneficiary Details" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/beneficiaries-edit.php" method="post" data-parsley-validate>
            <input type="hidden" value="" id="village_id" name="village_id">
            <input type="hidden" value="<?php echo $displayedPage['item'];?>" id="beneficiary_id" name="beneficiary_id">
            <div class="form-row">
              <div class="form-group col-md-8">
                <label for="beneficiary_name">Name</label>
                <input type="text" class="form-control" id="beneficiary_name" name="beneficiary_name" placeholder="Name" value="<?php echo $arrBen['beneficiary_name'];?>" required>
              </div>
              <div class="form-group col-md-6">
                <label for="usergroup">Gender</label>
                <select class="custom-select" name="beneficiary_gender" required>
                  <option value="" selected> </option>
                  <option value="MALE"<?php echo ($arrBen['beneficiary_gender']=='MALE')? ' selected':'';?>> MALE </option>
                  <option value="FEMALE"<?php echo ($arrBen['beneficiary_gender']=='FEMALE')? ' selected':'';?>> FEMALE</option>
                </select>
              </div>
              <div class="form-group col-md-6">
                <label for="usergroup">Marital Status</label>
                <select class="custom-select" name="marital_status" required>
                  <option value="" selected> </option>
                  <option value="SINGLE"<?php echo ($arrBen['marital_status']=='SINGLE')? ' selected':'';?>> SINGLE </option>
                  <option value="MARRIED"<?php echo ($arrBen['marital_status']=='MARRIED')? ' selected':'';?>> MARRIED</option>
                  <option value="DIVORCED"<?php echo ($arrBen['marital_status']=='DIVORCED')? ' selected':'';?>> DIVORCED </option>
                  <option value="WIDOWED"<?php echo ($arrBen['marital_status']=='WIDOWED')? ' selected':'';?>> WIDOWED</option>
                </select>
              </div>
              <div class="form-group col-md-8">
                <label for="phone">Phone</label>
                <input type="text" class="form-control" id="phone" name="beneficiary_phone" placeholder="Phone" value="<?php echo $arrBen['beneficiary_phone'];?>">
              </div>
              <div class="form-group col-md-6">
                <label for="beneficiary_dob">Date Of Birth</label>
                <input type="text" class="form-control" id="datepicker-birthday" name="beneficiary_dob" placeholder="Select Date" value="<?php echo $arrBen['beneficiary_dob'];?>">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-8">
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input" id="customCheck1" name="beneficiary_disabled" value="1">
                  <label class="custom-control-label" for="customCheck1">Disabled</label>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-5">
                <label for="category_id">Beneficiary Category</label>
                <select class="custom-select" name="category_id" required>
                  <option value=""> </option>
                  <?php
                    foreach($arrCats as $cat)
                    {
                  ?>
                  <option value="<?php echo $cat['category_id'];?>"<?php echo ($arrBen['category_id']== $cat['category_id'])? ' selected':'';?>><?php echo $cat['category_name'];?></option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-8">
                <label for="ceg_id">Community Empowerment Group (CEG)</label>
                <select class="custom-select select2 beneficiary-add-ceg" name="ceg_id" required>
                  <option value="" selected> </option>
                  <?php
                    foreach($arrCegs as $ceg)
                    {
                  ?>
                    <option value="<?php echo $ceg['ceg_id'];?>"<?php echo ($arrBen['ceg_id']==$ceg['ceg_id'])? ' selected':'';?>>
                    <?php 
                      echo $ceg['ceg_name'] . ' ('.$ceg['village_name'].' Village, ' . $ceg['subcounty_name'].' Subcounty, '  . $ceg['district_name'].' District)';
                      ?>
                    </option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <!-- <div class="form-group">
              <label for="inputAddress">Address</label>
              <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
            </div> -->
            <button type="submit" class="btn btn-primary">Submit Form</button>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>