<?php
  $options = array("ceg_id" => $displayedPage['item']);
  $_SESSION['USER']['current_ceg_id'] = $displayedPage['item'];
  $arrCeg = dbGetCegs($options);
  $arrEvents = dbGetCEGEvents($options);
  $arrEventTypes = dbGetEventTypes();
  $arrComps = dbGetAllComponents();
  $arrActivities = dbGetActivities();
  $arrCegActivities = dbGetCegActivities($displayedPage['item']);
  $arrEnterprises = dbGetFarmEnterprises();
  $arrBeneficiaries = dbGetBeneficiaries($options);
  $arrVillage = dbGetVillageFromId($arrCeg[0]['village_id']);
  $arrVSLA = dbGetVSLA($options);
  $arrVSLAContributions = dbGetVSLAContributionHeaders($options);

?>

<div class="content-body">
  <div class="container pd-x-0 tx-13">
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>
    <div class="media d-block d-lg-flex">
      <div class="profile-sidebar profile-sidebar-two pd-lg-r-15">

        <div class="row">
          <div class="col-sm-3 col-md-2 col-lg">
            <div class="avatar avatar-xxl avatar-online"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div>
          </div><!-- col -->
        </div>
        <div class="row">
          <div class="col-sm-8 col-md-7 col-lg mg-t-20 mg-sm-t-0 mg-lg-t-25">
            <h5 class="mg-b-2 tx-spacing--1"><?php echo $arrCeg[0]['ceg_name'];?></h5>
            <p class="tx-color-03 mg-b-25"><?php echo $arrCeg[0]['ceg_code'];?></p>

          </div><!-- col -->
        </div>
        <div class="row">

          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <label class="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">Contact Information</label>
            <ul class="list-unstyled profile-info-list">
              <li><i data-feather="map-pin"></i> <?php echo ucwords(strtolower($arrVillage));?></li>
              <li><i data-feather="phone"></i> <?php echo $arrCeg[0]['ceg_phone'];?></li>
              <li><i data-feather="mail"></i> <?php echo $arrCeg[0]['ceg_email'];?></li>
            </ul>
          </div><!-- col -->
        </div>
        <div class="row">

          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <label class="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">Beneficiaries</label>
            <ul class="list-unstyled profile-info-list">
              <?php
                if(!empty($arrBeneficiaries))
                {
                  $i = 1;
                  foreach($arrBeneficiaries as $benef)
                  {
                  ?>
                    <div class="beneficiary-list-item"><?php echo $i;?>. <a href="<?php echo $ROOT_FOLDER;?>beneficiaries/view/<?php echo $benef['beneficiary_id'];?>">
                      <?php echo $benef['beneficiary_name'] . ' <span class="tx-12 mg-b-10 tx-color-03">(' . $benef['position_name'] . ")</span>";?></a></div>
                  <?php
                    $i++;
                  }
                }
              ?>
              
            </ul>
          </div><!-- col -->
        </div><!-- row -->

        <div class="d-flex mg-b-25">
          <a href="<?php echo $ROOT_FOLDER . "cegs/edit/" . $displayedPage['item'];?>" class="btn btn-xs btn-success flex-fill mg-l-10">Edit CEG</a>
        </div>
        <div class="d-flex mg-b-25">
          <a href="" class="btn btn-xs btn-primary flex-fill mg-l-10" data-toggle="modal" data-target="#modalNewVSLA" >Create VSLA</a>
        </div>

      </div><!-- profile-sidebar -->
      <div class="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">


        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Components</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalComponentProgress"><i data-feather="plus"></i> Add Component Progress</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <div class="media d-block d-sm-flex">
              <div class="wd-80 ht-80 bg-ui-04 rounded d-flex align-items-center justify-content-center">
                <i data-feather="briefcase" class="tx-white-7 wd-40 ht-40"></i>
              </div>
              <div class="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                <h5 class="mg-b-5">Component Progress</h5>
                <span class="d-block tx-13 tx-color-03">December 2020</span>

                <table class="table">
                  <tbody>
                    <?php
                      $i = 1;
                      $arrProg = dbGetComponentProgress($displayedPage['item']);
                      
                      foreach($arrComps as $comp)
                      {
                        $arrCompUnits = dbGetComponentUnits($comp['component_id']);
                        $arrCompleteUnits = dbGetCompleteComponentUnits($comp['component_id'], $displayedPage['item']);
                        //print_r($arrCompUnits);
                        $unitsNumber = count($arrCompUnits);
                        $unitsComplete = count($arrCompleteUnits);
                        foreach($arrCompUnits as $unit)
                        {
                          if($unit['unit_id'] == 'COMPLETE')
                            $unitsComplete += 1;
                        }
                        $unitPercent = round(($unitsComplete/$unitsNumber) * 100);
                    ?>
                    <tr>
                      <th class="wd-5p" scope="row"><?php echo $i;?></th>
                      <td><?php echo $comp['component_name'];?>
                        <div class="progress ht-20">
                          <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $unitPercent;?>%" aria-valuenow="<?php echo $unitPercent;?>" aria-valuemin="0" aria-valuemax="100"><?php echo $unitPercent;?>%</div>
                           <!-- <div class="progress-bar bg-warning wd-60p" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div> -->
                        </div>
                      </td>
                    </tr>
                    <?php
                        $i++; 
                      }
                    ?>
                  </tbody>
                </table>
              </div>
            </div><!-- media -->
          </div>
        </div><!-- card -->

        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Activities</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalActivities"><i data-feather="plus"></i> Add New Activity</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <?php
              if(!empty($arrCegActivities))
              {
                foreach($arrCegActivities as $activity)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="slack" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $activity['activity_name'];?></h6>
                          <p class="tx-12 mg-b-10">STARTED: <?php echo $activity['start_date'];?>, <?php if(!is_null($activity['enterprise_id'])) echo "ENTERPRISE: " . $activity['enterprise_name'];?>
                          <?php if(!is_null($activity['description'])) echo "<br/>" . nl2br(substr($activity['description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
            
          </div>
        </div><!-- card -->

        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Beneficiary Event Attendance</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalNewEvent"><i data-feather="plus" ></i> Add New Event</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <div class="media">
                  <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                    <i data-feather="star" class="tx-white-7 wd-20 ht-20"></i>
                  </div>
                  <div class="media-body pd-l-15">
                    <h6 class="tx-color-01 mg-b-5"><?php echo $arrCeg[0]['ceg_name'];?> Events</h6>
                    <p class="tx-12 mg-b-10">Attendance Records</p>
                  </div>
                </div><!-- media -->
              </div>
            </div>
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <table class="table table-striped datatable-small">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Event</th>
                      <th scope="col">Date</th>
                      <th scope="col">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      if(!empty($arrEvents))
                      {
                        $i = 1;
                        foreach($arrEvents as $event)
                        {
                        ?>
                          <tr>
                            <td scope="row"><?php echo $i;?></td>
                            <td>
                              <b><a href="#" data-toggle="modal" data-target="#modalEventDetails" data-event-id="<?php echo $event['event_id'];?>"><?php echo $event['event_name'];?></a></b><br/>
                              <?php echo $event['event_description'];?>
                              </td>
                            <td><?php echo $event['start_date'];?></td>
                            <td><?php echo $event['event_status'];?></td>
                          </tr>
                        <?php
                          $i++;
                        }
                      }
                    ?>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div><!-- card -->

        <?php
          if(!empty($arrVSLA))
          {
        ?>
        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">VSLA Contributions</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalVSLAContribution"><i data-feather="plus" ></i> Add New Contribution</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <div class="media">
                  <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                    <i data-feather="star" class="tx-white-7 wd-20 ht-20"></i>
                  </div>
                  <div class="media-body pd-l-15">
                    <h6 class="tx-color-01 mg-b-5"><?php echo $arrVSLA['vsla_name'];?></h6>
                    <p class="tx-12 mg-b-10">Share Price: UGX <?php echo $arrVSLA['share_price'];?> | Regularity: <?php echo $arrVSLA['contribution_period'];?></p>
                  </div>
                </div><!-- media -->
              </div>
            </div>
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Date</th>
                      <th scope="col">Average Contribution</th>
                      <th scope="col">Total Contribution</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $averageContrib = 0;
                      $totalContrib = 0;
                      $totalSavings = 0;
                      if(!empty($arrVSLAContributions['contributions']))
                      {
                        $i = 1;
                        
                        foreach($arrVSLAContributions['contributions'] as $contrib)
                        {
                          $totalContrib = $totalContrib + $contrib['contribution_amount'];
                          $totalSavings = $totalSavings + $contrib['total_contribution'];
                          $averageContrib = $totalContrib / count($arrVSLAContributions['contributions']);
                        ?>
                          <tr>
                            <th scope="row"><?php echo $i;?></th>
                            <td><?php echo $contrib['contribution_date'];?></td>
                            <td>UGX <?php echo number_format($contrib['contribution_amount']);?></td>
                            <td>UGX <?php echo number_format($contrib['total_contribution']);?></td>
                          </tr>
                        <?php
                          
                          $i++;
                        }
                        
                      }
                    ?>
 
                  </tbody>
                  <tfoot>
                    <tr>
                      <th scope="col"></th>
                      <th scope="col"></th>
                      <th scope="col">UGX <?php echo number_format($averageContrib);?></th>
                      <th scope="col">UGX <?php echo number_format($totalSavings);?></th>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div><!-- card -->

        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">VSLA Loans</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalNewLoan"><i data-feather="plus" ></i> Add New Loan</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <div class="media">
                  <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                    <i data-feather="star" class="tx-white-7 wd-20 ht-20"></i>
                  </div>
                  <div class="media-body pd-l-15">
                    <h6 class="tx-color-01 mg-b-5"><?php echo $arrVSLA['vsla_name'];?></h6>
                    <p class="tx-12 mg-b-10">Share Price: UGX <?php echo $arrVSLA['share_price'];?> | Regularity: <?php echo $arrVSLA['contribution_period'];?></p>
                  </div>
                </div><!-- media -->
              </div>
            </div>
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <table class="table table-striped datatable-small">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Loan Title</th>
                      <th scope="col">Beneficiary</th>
                      <th scope="col">Principal</th>
                      <th scope="col">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      if(!empty($arrVSLA['loans']))
                      {
                        $i = 1;
                        foreach($arrVSLA['loans'] as $loan)
                        {
                        ?>
                          <tr>
                            <td scope="row"><?php echo $i;?></td>
                            <td>
                              <b><a href="#" data-toggle="modal" data-target="#modalLoanDetails" data-loan-id="<?php echo $loan['loan_id'];?>">
                                <?php echo $loan['loan_title'];?></a></b><br/>
                              <?php echo $loan['loan_description'];?>
                              </td>
                            <td><?php echo $loan['beneficiary_name'];?></td>
                            <td><?php echo number_format($loan['principal']);?></td>
                            <td><?php echo $loan['loan_status'];?></td>
                          </tr>
                        <?php
                          $i++;
                        }
                      }
                    ?>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div><!-- card -->
        <?php
          }
        ?>

      </div><!-- media-body -->

    </div><!-- media -->
  </div><!-- container -->
</div><!-- content-body -->

<!-- Modal New VSLA -->
<div class="modal fade" id="modalNewVSLA" tabindex="-1" role="dialog" aria-labelledby="modalNewVSLATitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-new-vsla.php" method="post">
        <input type="hidden" name="ceg_id" value="<?php echo $displayedPage['item'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Create VSLA</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row">
          <div class="form-group col-md-8">
              <label for="event_name">VSLA Name</label>
              <input type="text" class="form-control" id="" name="vsla_name" placeholder="VSLA Name" value="" required>
            </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label>Saving Regularity</label>
            <select id="" name="contribution_period" class="custom-select" required>
              <option value="" selected>Choose One</option>
              <option value="WEEKLY">Weekly</option>
              <option value="MONTHLY">Monthly</option>
            </select>
          </div>
          <div class="form-group col-md-6">
            <label>Share Price</label>
              <input type="number" class="form-control" name="share_price" placeholder="Share Price" value="" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="beneficiary_dob">Start Date</label>
            <input type="date" class="form-control datepicker" id="datepicker-item" name="date_started" placeholder="Select Date" required>
          </div>
        </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Compponent Progress-->
<div class="modal fade" id="modalComponentProgress" tabindex="-1" role="dialog" aria-labelledby="modalComponentProgressTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-component-progress.php" method="post">
        <input type="hidden" name="ceg_id" value="<?php echo $displayedPage['item'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Component Progress</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label>Component</label>
              <select id="sel-components" class="custom-select component-units dependable-select" data-initiates="sel-component-units" data-list="component_units" required>
                <option value="" selected>Choose One</option>
                <?php
                  foreach($arrComps as $comp)
                  {
                  ?>
                    <option value="<?php echo $comp['component_id'];?>">
                      <?php echo $comp['component_name'];?>
                      </option>
                  <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-6">
              <label>Component Units</label>
              <select id="sel-component-units" name="unit_id" class="custom-select component-units" required>
                <option value="" selected>Choose Component</option>
                ?>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="usergroup">Status</label>
              <select class="custom-select" name="unit_status" required>
                <option value="" selected> </option>
                <option value="PENDING"> Pending </option>
                <option value="ON-GOING"> On-going</option>
                <option value="COMPLETE"> Complete</option>
              </select>
            </div>
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">Date Of Status</label>
              <input type="date" class="form-control datepicker" id="" name="status_date" placeholder="Select Date" required>
            </div>
          </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal New Activity-->
<div class="modal fade" id="modalActivities" tabindex="-1" role="dialog" aria-labelledby="modalActivitiesTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-new-activity.php" method="post">
        <input type="hidden" name="ceg_id" value="<?php echo $displayedPage['item'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New Activity</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label>Activity</label>
              <select id="sel-activities" name="activity_id" class="custom-select" required>
                <option value="" selected>Choose One</option>
                <?php
                  foreach($arrActivities as $activity)
                  {
                  ?>
                    <option value="<?php echo $activity['activity_id'];?>">
                      <?php echo $activity['activity_name'];?>
                      </option>
                  <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-6">
              <label>Enterprise</label>
              <select id="sel-enterprise" name="enterprise_id" class="custom-select">
                <option value="" selected>Choose Enterprise</option>
                <?php
                  foreach($arrEnterprises as $ent)
                  {
                  ?>
                    <option value="<?php echo $ent['enterprise_id'];?>"><?php echo $ent['enterprise_name'];?></option>
                  <?php
                  }
                ?>
                ?>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">Start Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item" name="start_date" placeholder="Select Date" required>
            </div>
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">End Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item1" name="end_date" placeholder="Select Date" required>
            </div>
          </div>  
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="message-text" class="col-form-label">Remarks:</label>
              <textarea class="form-control" id="message-text" name="description"></textarea>
            </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal VSLA Contribution-->
<div class="modal fade" id="modalVSLAContribution" tabindex="-1" role="dialog" aria-labelledby="modalVSLAContributionTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-vsla-contribution.php" method="post">
        <input type="hidden" name="ceg_id" value="<?php echo $displayedPage['item'];?>">
        <input type="hidden" name="vsla_id" value="<?php echo $arrVSLA['vsla_id'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New VSLA Contrbution</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">Contribution Date</label>
              <input type="date" class="form-control" id="datepicker-birthday" name="contribution_date" placeholder="Select Date" required>
            </div>
            <div class="form-group col-md-12">
              <label>Contributions</label>
              <table class="table table-striped table-bordered table-sm">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col" class="wd-65p">Name</th>
                    <th scope="col">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    if(!empty($arrBeneficiaries))
                    {
                      $i = 1;
                      foreach($arrBeneficiaries as $ben)
                      {
                      ?>
                        <tr>
                          <th scope="row"><?php echo $i;?>.</th>
                          <td><?php echo $ben['beneficiary_name'];?></td>
                          <td>
                            <input type="number" class="form-control" value="<?php echo $arrVSLA['share_price'];?>" name="contribution[<?php echo $ben['beneficiary_id'];?>]" required>
                          </td>
                        </tr>
                      <?php
                        $i++;
                      }
                    }
                  ?>
                  
                </tbody>
              </table>
            </div>

          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Event Details -->
<div class="modal fade" id="modalEventDetails" tabindex="-1" role="dialog" aria-labelledby="modalEventAtendanceTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Event Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-group col-md-12">
            <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="tab-event-details" data-toggle="tab" href="#event-details" role="tab" aria-controls="home" aria-selected="true">Event Details</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="tab-event-attendance" data-toggle="tab" href="#event-attendance" role="tab" aria-controls="contact" aria-selected="false">Attendance</a>
              </li>
            </ul>
            <div class="tab-content bd bd-gray-300 bd-t-0 pd-20" id="myTabContent2">
              <div class="tab-pane fade show active" id="event-details" role="tabpanel" aria-labelledby="tab-event-details">
                <h6>Event Details</h6>
                <form action="<?php echo $ROOT_FOLDER;?>process/modal-event-details.php" method="post">
                  <input type="hidden" id="eventdetail_event_id2" name="event_id" value="">
                  <div class="form-row">
                    <div class="form-group col-md-4">
                      <label>Event Type</label>
                      <select id="eventdetail_event_type" name="type_id" class="custom-select" required>
                        <option value="" selected>Choose One</option>
                        <?php
                          foreach($arrEventTypes as $type)
                          {
                          ?>
                            <option value="<?php echo $type['type_id'];?>">
                              <?php echo $type['type_name'];?>
                              </option>
                          <?php
                          }
                        ?>
                      </select>
                    </div>
                    <div class="form-group col-md-8">
                      <label for="event_name">Event Name</label>
                      <input type="text" class="form-control" id="eventdetail_event_name" name="event_name" placeholder="Event Name" value="" required>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-12">
                      <label for="message-text" class="col-form-label">Event Description:</label>
                      <textarea class="form-control" id="eventdetail_event_description" name="event_description"></textarea>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="beneficiary_dob">Start Date</label>
                      <input type="date" class="form-control datepicker" id="eventdetail_event_start_date" name="start_date" placeholder="Select Date" required>
                    </div>
                    <div class="form-group col-md-6">
                      <label for="beneficiary_dob">End Date</label>
                      <input type="date" class="form-control datepicker" id="eventdetail_event_end_date" name="end_date" placeholder="Select Date" required>
                    </div>
                    <div class="form-group col-md-4">
                      <label>Status</label>
                      <select id="eventdetail_event_status" name="event_status" class="custom-select" required>
                        <option value="" selected></option>
                        <option value="UPCOMING">UPCOMING</option>
                        <option value="HAPPENING">HAPPENING</option>
                        <option value="COMPLETED">COMPLETED</option>
                        <option value="CANCELED">CANCELED</option>
                      </select>
                    </div>
                  </div>   
                  <input type="submit" class="btn btn-primary" value="Save">
                </form>
              </div>
              <div class="tab-pane fade" id="event-attendance" role="tabpanel" aria-labelledby="event-attendance">
                <h6>Event Attendance</h6>
                <form action="<?php echo $ROOT_FOLDER;?>process/modal-event-attendance.php" method="post">
                <input type="hidden" id="eventdetail_event_id" name="event_id" value="">
                <div class="form-row">
                  <div class="form-group col-md-12">
                    <table class="table table-striped table-bordered table-sm datatable-small">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col" class="wd-65p">Name</th>
                          <th scope="col">Attended</th>
                          <th scope="col">Reason</th>
                        </tr>
                      </thead>
                      <tbody id="event-attendance-data">
                        <?php
                          if(!empty($arrBeneficiaries))
                          {
                            $i = 1;
                            foreach($arrBeneficiaries as $ben)
                            {
                            ?>
                              <tr>
                                <th scope="row" class="wd-15"><?php echo $i;?>.</th>
                                <td><?php echo $ben['beneficiary_name'];?></td>
                                <td class="wd-15">
                                  <input type="hidden" name="beneficiaries[<?php echo $ben['beneficiary_id'];?>]" value="<?php echo $ben['beneficiary_id'];?>">
                                  <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input event-attend-check" id="event-attend-<?php echo $ben['beneficiary_id'];?>" data-id="<?php echo $ben['beneficiary_id'];?>" name="attended[<?php echo $ben['beneficiary_id'];?>]" value="1" checked>
                                    <label class="custom-control-label" for="event-attend-<?php echo $ben['beneficiary_id'];?>"></label>
                                  </div>
                                </td>
                                <td>
                                  <input type="text" id="reason-[<?php echo $ben['beneficiary_id'];?>" name="reason[<?php echo $ben['beneficiary_id'];?>]">
                                </td>
                              </tr>
                            <?php
                              $i++;
                            }
                          }
                        ?>
                        
                      </tbody>
                    </table>
                  </div>
                  <input type="submit" class="btn btn-primary" value="Save changes">
                </div>
                </form>
              </div>
            </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
      
    </div>
  </div>
</div>

<!-- Modal New Event-->
<div class="modal fade" id="modalNewEvent" tabindex="-1" role="dialog" aria-labelledby="modalNewEventTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-new-event.php" method="post">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New Event</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-row">
            <div class="form-group col-md-4">
              <label>Event Type</label>
              <select id="sel-activities" name="type_id" class="custom-select" required>
                <option value="" selected>Choose One</option>
                <?php
                  foreach($arrEventTypes as $type)
                  {
                  ?>
                    <option value="<?php echo $type['type_id'];?>">
                      <?php echo $type['type_name'];?>
                      </option>
                  <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-8">
              <label for="event_name">Event Name</label>
              <input type="text" class="form-control" id="" name="event_name" placeholder="Event Name" value="" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="message-text" class="col-form-label">Event Description:</label>
              <textarea class="form-control" id="" name="event_description"></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">Start Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item" name="start_date" placeholder="Select Date" required>
            </div>
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">End Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item1" name="end_date" placeholder="Select Date" required>
            </div>
          </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save Event">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal New Loan-->
<div class="modal fade" id="modalNewLoan" tabindex="-1" role="dialog" aria-labelledby="modalNewLoanTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-new-loan.php" method="post">
        <input type="hidden" name="ceg_id" value="<?php echo $displayedPage['item'];?>">
        <input type="hidden" name="vsla_id" value="<?php echo $arrVSLA['vsla_id'];?>">
        <input type="hidden" name="user_id" value="<?php echo $_SESSION['USER']['ICOLEW_USERID'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New Loan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-row">
            <div class="form-group col-md-4">
              <label>Beneficiary</label>
              <select name="beneficiary_id" class="custom-select" required>
                <option value="" selected>Choose One</option>
                <?php
                  foreach($arrBeneficiaries as $ben)
                  {
                  ?>
                    <option value="<?php echo $ben['beneficiary_id'];?>">
                      <?php echo $ben['beneficiary_name'];?>
                      </option>
                  <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-8">
              <label for="event_name">Loan Title</label>
              <input type="text" class="form-control" id="" name="loan_title" placeholder="Loan Title" value="" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="message-text" class="col-form-label">Loan Description:</label>
              <textarea class="form-control" id="" name="loan_description" required=""></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="event_name">Principal</label>
              <input type="number" class="form-control" id="" name="principal" placeholder="Principal" value="" required>
            </div>
            <div class="form-group col-md-6">
              <label for="event_name">Interest Rate</label>
              <input type="number" class="form-control" id="" name="interest_rate" placeholder="Ineterest Rate" value="" required>
            </div>
          </div>  
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">Date Applied</label>
              <input type="date" class="form-control datepicker" id="datepicker-item" name="date_applied" placeholder="Select Date" required>
            </div>
            <div class="form-group col-md-6">
              <label for="beneficiary_dob">Date Issued</label>
              <input type="date" class="form-control datepicker" id="datepicker-item1" name="date_issued" placeholder="Select Date" required>
            </div>
          </div> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save Loan">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Loan Details -->
<div class="modal fade" id="modalLoanDetails" tabindex="-1" role="dialog" aria-labelledby="modalLoanDetailsTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Loan Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row">
          <div class="form-group col-md-12">
            <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Loan Details</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">New Payment</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Payment History</a>
              </li>
            </ul>
            <div class="tab-content bd bd-gray-300 bd-t-0 pd-20" id="myTabContent">
              <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <h6>Loan Details</h6>
                <div class="form-row">
                  <div class="form-group col-md-12">
                    <table class="table table-sm">
                      <tbody>
                        <tr>
                          <th class="tx-right">Beneficiary: </th>
                          <td><span id="detail_beneficiary_name"></span></td>
                          <th class="tx-right">Principal: </th>
                          <td><span id="detail_principal"></span></td>
                        </tr>
                        <tr>
                          <th class="tx-right"> Loan Title:</th>
                          <td><span id="detail_loan_title"></span></td>
                          <th class="tx-right">Interest Rate:</th>
                          <td><span id="detail_interest_rate"></span></td>
                        </tr>
                        <tr>
                          <th class="tx-right"> Description:</th>
                          <td><span id="detail_loan_description"></span></td>
                          <th class="tx-right">Amount Paid:</th>
                          <td><span id="detail_amount_paid"></span></td>
                        </tr>
                        <tr>
                          <th class="tx-right">Date Issued:</th>
                          <td><span id="detail_date_issued"></span></td>
                          <th class="tx-right">Balance:</th>
                          <td><span id="detail_balance"></span></td>
                        </tr>
                        <tr>
                          <th class="tx-right">Status:</th>
                          <td><span id="detail_loan_status"></span></td>
                          <th class="tx-right"></th>
                          <td><span id=""></span></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <h6>New Payment</h6>
                <form action="<?php echo $ROOT_FOLDER;?>process/modal-new-loan-payment.php" method="post">
                  <input type="hidden" id="loan_id" name="loan_id" value="">
                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="beneficiary_dob">Date of Payment</label>
                      <input type="date" class="form-control datepicker" id="datepicker-item" name="payment_date" placeholder="Select Date" required>
                    </div>
                    <div class="form-group col-md-6">
                      <label for="event_name">Amount</label>
                      <input type="number" class="form-control" id="" name="amount" placeholder="Ammount" value="" required>
                    </div>
                  </div>  
                  <input type="submit" class="btn btn-primary" value="Save changes">
                </form>
              </div>
              <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <h6>Payment History</h6>
                <div class="form-row">
                  <div class="form-group col-md-12">
                    <table class="table table-striped table-bordered table-sm datatable-small">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Date</th>
                          <th scope="col">Amount</th>
                        </tr>
                      </thead>
                      <tbody id="loan-payment-data">
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>