<?php
  // Receive report query filters
  if($displayedPage['reportQuery'])
  {
    $region = $displayedPage['reportQuery'][0];
    $subregion = $displayedPage['reportQuery'][1];
    $district = $displayedPage['reportQuery'][2];
    $county = $displayedPage['reportQuery'][3];
    $subcounty = $displayedPage['reportQuery'][4];
    $parish = $displayedPage['reportQuery'][5];
    $clc = $displayedPage['reportQuery'][6];
    $gender = $displayedPage['reportQuery'][7];
    $category = $displayedPage['reportQuery'][8];
    $disabled = $displayedPage['reportQuery'][9];
  }
  else
  {
    $region = '';
    $subregion = '';
    $district = '';
    $county = '';
    $subcounty = '';
    $parish = '';
    $clc = '';
    $gender = '';
    $category = '';
    $disabled = '';
  }

  $arrDistricts = dbGetAllDistricts();
  $arrCLCs = dbGetCLCs();
  $arrCats = dbGetBeneficiaryCategories();

  //-----------------------------------
  $options = array('district_id' => 36);
  $arrSubcounties = dbGetAllSubCounties($options); 
  $arrQuarters = dbGetQuarters();

  //----------REPORT Query----------------
  $qTrained = "SELECT
            tbl_subcounties.subcounty_name, tbl_subcounties.subcounty_id, tbl_districts.district_name, tbl_training_facilitators.level1, tbl_training_facilitators.level2, tbl_training_facilitators.level3, tbl_training_facilitators.user_id, 
            SUM(CASE WHEN tbl_training_facilitators.attendance = '1' THEN 1 ELSE 0 END) AS attended
              FROM tbl_training_facilitators 
          LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_training_facilitators.facilitator_id 
          LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
          LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
          LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
          LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
          WHERE tbl_districts.district_id = '36'
          GROUP BY tbl_subcounties.subcounty_id
                   ";
  $arrFacTrained = $db->QueryArray($qTrained, MYSQLI_ASSOC);



  // Set Excel export session query
  // $_SESSION['REPORT']['name'] = "Payment Summaries";
  // $_SESSION['REPORT']['query'] = $qBenefs;
  // $_SESSION['REPORT']['params'] = array(
  //                                     array("label" => "START DATE", "value" => '$start'),
  //                                     array("label" => "END DATE", "value" => '$end'),
  //                                 );
  // $_SESSION['REPORT']['headers'] = array("No.", "Date", "Title", "Amount");
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Reports</a></li>
            <li class="breadcrumb-item active" aria-current="page">Perfomance Reports</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1"> District Quarterly Report</h4>
      </div>
      <div class="d-none d-md-block">
        <div class="dropdown">
          <button class="btn btn-white" onclick="PrintElem('print-div')"><i data-feather="printer" class="mg-r-5"></i> Print</button>
          <!-- <button class="btn btn-white mg-l-5"><i data-feather="mail" class="mg-r-5"></i> Email</button> -->
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Export
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="#">Excel</a>
            <a class="dropdown-item" href="#">PDF</a>
          </div>
        </div>
      </div>
    </div>

  <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
    <div class="d-sm-flex align-items-center justify-content-between">
      <div data-label="Filters" class="df-example demo-table col-md-12">
        <form method="post" action="<?php echo $ROOT_FOLDER;?>process/report-beneficiary-register.php">
          <div class="form-row">
            <div class="form-group col-md-3">
              <label>District</label>
              <select name="district_id" class="custom-select select2 dependable-select" data-initiates="sel-subregions" data-list="regions">
                <option value="0" selected>Select District</option>
                <?php
                    foreach($arrDistricts as $district)
                    {
                  ?>
                  <option value="<?php echo $district['district_id'];?>">
                    <?php echo ucwords(strtolower($district['district_name']));?>
                  </option>
                  <?php
                    }
                  ?>
              </select>
            </div>

            <div class="form-group col-md-3">
              <label>Quarter</label>
              <select id="sel-counties" name="county_id" class="custom-select">
                <?php
                  foreach($arrQuarters as $quarter)
                  {
                  ?>
                    <option value="<?php echo $quarter['quarter_id'];?>"><?php echo $quarter['quarter_name'];?></option>
                  <?php
                  }
                ?>
                
              </select>
            </div>
            
          </div>

          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  </div><!-- container -->

    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Report" class="df-example demo-table" id="print-div" style="width: 100%;">
          <div style="padding: 10px;">
            <h6>ICOLEW Management Information System</h6>
            <h3>
              District Quarterly Report
            </h3>
            <div>
              <h5>District: Mpigi, Quarter: Oct - Dec (2020/2021) </h5>
            </div>
          </div>
          <table class="table table-sm table-striped table-bordered">
            <thead>
              <tr>
                <td colspan="5" class="tx-center">
                  Facilitators
                </td>
              </tr>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="">Subcounty</th>
                  <th class="wd-10p">Trained</th>
                  <th class="wd-10p">Remunerated</th>
                  <th class="wd-10p">Equipped</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $i = 1;
                $totalTrained = 0;
                foreach($arrSubcounties as $subcounty)
                {
                  
              ?>
              <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $subcounty['subcounty_name'];?></td>
                  <td>
                    <?php
                      foreach($arrFacTrained as $facTrained)
                      {
                        if($facTrained['subcounty_id'] == $subcounty['subcounty_id'])
                        {
                          echo $facTrained['attended'];
                          $totalTrained += $facTrained['attended'];
                          break;
                        }
                      }
                     ?>
                  </td>
                  <td></td>
                  <td></td>
              </tr>
              <?php
                  $i++;
                }
              ?>
              <tr>
                  <td></td>
                  <td>TOTAL</td>
                  <td><?php echo $totalTrained;?></td>
                  <td></td>
                  <td></td>
              </tr>
            </tbody>
          </table>
          <table class="table table-sm table-striped table-bordered">
            <thead>
              <tr>
                <td colspan="5" class="tx-center">
                  Community Learning Centers
                </td>
              </tr>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="">Subcounty</th>
                  <th class="wd-10p">Established</th>
                  <th class="wd-10p">Coordinators Trained</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $i = 1;
                $totalTrained = 0;
                foreach($arrSubcounties as $subcounty)
                {
                  
              ?>
              <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $subcounty['subcounty_name'];?></td>
                  <td>
                    <?php
                      foreach($arrFacTrained as $facTrained)
                      {
                        if($facTrained['subcounty_id'] == $subcounty['subcounty_id'])
                        {
                          echo $facTrained['attended'];
                          $totalTrained += $facTrained['attended'];
                          break;
                        }
                      }
                     ?>
                  </td>
                  <td></td>
              </tr>
              <?php
                  $i++;
                }
              ?>
              <tr>
                  <td></td>
                  <td>TOTAL</td>
                  <td><?php echo $totalTrained;?></td>
                  <td></td>
              </tr>
            </tbody>
          </table>
          <table class="table table-sm table-striped table-bordered">
            <thead>
              <tr>
                <td colspan="5" class="tx-center">
                  Locations
                </td>
              </tr>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="">Subcounty</th>
                  <th class="wd-10p">Villages Mobilized</th>
                  <th class="wd-10p">Structures Established</th>
                  <th class="wd-10p">Structures Strengthened</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $i = 1;
                $totalTrained = 0;
                foreach($arrSubcounties as $subcounty)
                {
                  
              ?>
              <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $subcounty['subcounty_name'];?></td>
                  <td>
                    <?php
                      foreach($arrFacTrained as $facTrained)
                      {
                        if($facTrained['subcounty_id'] == $subcounty['subcounty_id'])
                        {
                          echo $facTrained['attended'];
                          $totalTrained += $facTrained['attended'];
                          break;
                        }
                      }
                     ?>
                  </td>
                  <td></td>
                  <td></td>
              </tr>
              <?php
                  $i++;
                }
              ?>
              <tr>
                  <td></td>
                  <td>TOTAL</td>
                  <td><?php echo $totalTrained;?></td>
                  <td></td>
                  <td></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>