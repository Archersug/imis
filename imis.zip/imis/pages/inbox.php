<?php
  $options = array("receiver_id" => $_SESSION['USER']['ICOLEW_USERID']);
  $arrMessages = getInboxMessages($options);
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Profile</a></li>
            <li class="breadcrumb-item active" aria-current="page">Inbox</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Messages</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="mail-groupx">
            <div class="mail-group-header justify-content-between">
              <h6 class="tx-uppercase tx-semibold mg-b-0">Inbox</h6>
              
            </div><!-- mail-group-header -->
            <div class="mail-group-body">

              <label class="mail-group-label"></label>
              <ul class="list-unstyled media-list mg-b-0">
                <?php
                  if(!empty($arrMessages))
                  {
                    foreach($arrMessages as $message)
                    {
                    ?>
                      <li data-msg="<?php echo $message['message_id'];?>" class="msg-link media<?php echo ($message['read_status']=='1')? ' unread':'';?>">
                        <div class="avatar"><span class="avatar-initial rounded-circle bg-indigo">
                          <?php echo substr($message['sender'], 0, 1);?>
                        </span></div>
                        <div class="media-body mg-l-15">
                          <div class="tx-color-03 d-flex align-items-center justify-content-between mg-b-2">
                            <span class="tx-12"><?php echo $message['sender'];?></span>
                            <span class="tx-11"><?php echo date("D, M, j, Y, g:i a", strtotime($message['message_date']));?></span>
                          </div>
                          <h6 class="tx-13"><?php echo $message['message_heading'];?></h6>
                          <p class="tx-12 tx-color-03 mg-b-0"><?php echo substr($message['message_body'], 0, 350);?>... </p>
                        </div><!-- media-body -->
                      </li>
                    <?php
                    }
                  }
                ?>

              </ul>

            </div><!-- mail-group-body -->
          </div><!-- mail-group -->
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>