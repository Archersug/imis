<?php
  $arrUsergroups = dbGetUsergroups();
  $arrDistricts = dbGetAllDistricts();
  $options = array('group_id' => '1');
  $arrCourses = dbGetTrainingCourses($options);
  $arrQuarters = dbGetCurrentQuarter();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Data Entry</a></li>
            <li class="breadcrumb-item active" aria-current="page">CLCs</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">CLC Establishment & Functionality</h4>
      </div>
    </div>

        <!-- Alert User -->
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Data Form" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/data-facilitators-trained.php" method="post" data-parsley-validate>
            <div class="form-row">
              <div class="form-group col-md-4">
                <label>District</label>
                <select class="custom-select select2 dependable-select" data-initiates="sel-subcounties" data-list="districts">
                  <option value="0" selected>Select District</option>
                  <?php
                      foreach($arrDistricts as $district)
                      {
                    ?>
                    <option value="<?php echo $district['district_id'];?>">
                      <?php echo ucwords(strtolower($district['district_name']));?>
                    </option>
                    <?php
                      }
                    ?>
                </select>
              </div>
              <div class="form-group col-md-4">
                <label>Subcounty</label>
                <select id="sel-subcounties" class="custom-select dependable-check-clc-establishment" data-initiates="clc-establishment" data-list="subcounties" required>
                  <option value="" selected>Select Subcounty</option>
                </select>
              </div>
              <div class="form-group col-md-4">
                <label>Quarter</label>
                <select id="sel-counties" name="quarter_id" class="custom-select" required>
                  <?php
                    if(!empty($arrQuarters))
                    {
                      foreach($arrQuarters as $quarter)
                      {
                      ?>
                        <option value="<?php echo $quarter['quarter_id'];?>"><?php echo $quarter['quarter_name'];?></option>
                      <?php
                      }
                    }
                  ?>
                </select>
              </div>
            </div>        
            <div class="form-row">
              <div class="form-group col-md-12">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th scope="col" class="wd-5p">#</th>
                      <th scope="col" class="wd-35px text-center">Community Learning Center</th>
                      <th scope="col" class="wd-10p text-center">Established</th>
                      <th scope="col" class="wd-10p text-center">Equipped</th>
                      <th scope="col" class="wd-10p text-center">Functional</th>
                    </tr>
                  </thead>
                  <tbody id="check-data">

                  </tbody>
                </table>
              </div>
            </div>
            
            <div class="form-row">
              <div class="form-group col-md-8">
                <button type="submit" class="btn btn-primary">Submit Form</button>
              </div>
            </div>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>