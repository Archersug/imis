<?php
  $arrUsergroups = dbGetUsergroups();
  $arrApprovals = dbGetDataApprovals();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Project Settings</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Configure Approvals</h4>
      </div>
    </div>
        <!-- Alert User -->
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>
    <div class="row row-xs" style="margin-bottom: 20px;">
      <div class="col-sm-12 col-lg-12">
        <div data-label="" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/configure-approvals.php" method="post" data-parsley-validate>
            <input type="hidden" name="level" value="1">
            <fieldset class="form-fieldset">
              <legend>Level 1 (Subcounty)</legend>
              <div class="form-row">
                <div class="form-group col-md-9">
                  <label class="d-block">Tag Usergroups with clearance to approve data at Level 1</label>
                  <?php
                    foreach($arrUsergroups as $group)
                    {
                      if($group['usergroup_id'] > 5)
                      {
                        $checked = '';
                        if(!empty($arrApprovals))
                        {
                          foreach($arrApprovals as $approve)
                          {
                            if($approve['usergroup_id'] == $group['usergroup_id'] && $approve['level'] == '1')
                            {
                              $checked = ' checked';
                              break;
                            }
                            else
                              $checked = '';
                          }
                        }
                        
                    ?>
                      <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="group-check-1-<?php echo $group['usergroup_id'];?>" name="group[<?php echo $group['usergroup_id'];?>]"<?php echo $checked;?>>
                        <label class="custom-control-label" for="group-check-1-<?php echo $group['usergroup_id'];?>"><?php echo $group['usergroup_name'];?></label>
                      </div>
                    <?php
                      }
                    }
                  ?>
                  
                </div>
              </div>

              <div class="form-row">
                <div class="form-group col-md-8">
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

    <div class="row row-xs" style="margin-bottom: 20px;">
      <div class="col-sm-12 col-lg-12">
        <div data-label="" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/configure-approvals.php" method="post" data-parsley-validate>
            <input type="hidden" name="level" value="2">
            <fieldset class="form-fieldset">
              <legend>Level 2 (District)</legend>
              <div class="form-row">
                <div class="form-group col-md-9">
                  <label class="d-block">Tag Usergroups with clearance to approve data at Level 2</label>
                  <?php
                    foreach($arrUsergroups as $group)
                    {
                      if($group['usergroup_id'] > 5)
                      {
                        $checked = '';
                        if(!empty($arrApprovals))
                        {
                          foreach($arrApprovals as $approve)
                          {
                            if($approve['usergroup_id'] == $group['usergroup_id'] && $approve['level'] == '2')
                            {
                              $checked = ' checked';
                              break;
                            }
                            else
                              $checked = '';
                          }
                        }
                        
                    ?>
                      <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="group-check-2-<?php echo $group['usergroup_id'];?>" name="group[<?php echo $group['usergroup_id'];?>]"<?php echo $checked;?>>
                        <label class="custom-control-label" for="group-check-2-<?php echo $group['usergroup_id'];?>"><?php echo $group['usergroup_name'];?></label>
                      </div>
                    <?php
                      }
                    }
                  ?>
                  
                </div>
              </div>

              <div class="form-row">
                <div class="form-group col-md-8">
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

    <div class="row row-xs" style="margin-bottom: 20px;">
      <div class="col-sm-12 col-lg-12">
        <div data-label="" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/configure-approvals.php" method="post" data-parsley-validate>
            <input type="hidden" name="level" value="3">
            <fieldset class="form-fieldset">
              <legend>Level 3 (National)</legend>
              <div class="form-row">
                <div class="form-group col-md-9">
                  <label class="d-block">Tag Usergroups with clearance to approve data at Level 3</label>
                  <?php
                    foreach($arrUsergroups as $group)
                    {
                      if($group['usergroup_id'] > 5)
                      {
                        $checked = '';
                        if(!empty($arrApprovals))
                        {
                          foreach($arrApprovals as $approve)
                          {
                            if($approve['usergroup_id'] == $group['usergroup_id'] && $approve['level'] == '3')
                            {
                              $checked = ' checked';
                              break;
                            }
                            else
                              $checked = '';
                          }
                        }
                        
                    ?>
                      <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="group-check-3-<?php echo $group['usergroup_id'];?>" name="group[<?php echo $group['usergroup_id'];?>]"<?php echo $checked;?>>
                        <label class="custom-control-label" for="group-check-3-<?php echo $group['usergroup_id'];?>"><?php echo $group['usergroup_name'];?></label>
                      </div>
                    <?php
                      }
                    }
                  ?>
                  
                </div>
              </div>

              <div class="form-row">
                <div class="form-group col-md-8">
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>