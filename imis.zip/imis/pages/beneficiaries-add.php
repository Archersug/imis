<?php
  if(isset($_SESSION['USER']['ASSIGNMENTS']['locations']))
  {
    $arrCats = dbGetBeneficiaryCategories();

    if($_SESSION['USER']['USERGROUPID'] < 10)
      $arrCegs = dbGetCegs();
    else
    {
      $options = array("locations" => $_SESSION['USER']['ASSIGNMENTS']['locations']['cegs']);
      $arrCegs = dbGetCegs($options);
    }

    $arrDisabilities = dbGetDisabilities();
  }
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Profiles</a></li>
            <li class="breadcrumb-item active" aria-current="page">Beneficiaries</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Add Beneficiary</h4>
      </div>
    </div>
    <?php
      if(isset($_SESSION['USER']['ASSIGNMENTS']['locations']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="New Beneficiary" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/beneficiaries-add.php" method="post" data-parsley-validate>
            <input type="hidden" value="" id="village_id" name="village_id">
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="beneficiary_name">Name</label>
                <input type="text" class="form-control capitalize" id="beneficiary_name" name="beneficiary_name" placeholder="Name" required>
              </div>
              <div class="form-group col-md-6">
                <label for="beneficiary_name">National ID Number</label>
                <input type="text" class="form-control" id="" name="nin" placeholder="NIN" required>
              </div>
              <div class="form-group col-md-6">
                <label for="usergroup">Gender</label>
                <select class="custom-select" name="beneficiary_gender" required>
                  <option value="" selected> </option>
                  <option value="MALE"> MALE </option>
                  <option value="FEMALE"> FEMALE</option>
                </select>
              </div>
              <div class="form-group col-md-6">
                <label for="usergroup">Marital Status</label>
                <select class="custom-select" name="marital_status" required>
                  <option value="" selected> </option>
                  <option value="SINGLE"> SINGLE </option>
                  <option value="MARRIED"> MARRIED</option>
                  <option value="DIVORCED"> DIVORCED </option>
                  <option value="WIDOWED"> WIDOWED</option>
                </select>
              </div>
              <div class="form-group col-md-6">
                <label for="phone">Phone</label>
                <input type="text" class="form-control" id="phone" name="beneficiary_phone" placeholder="Phone">
              </div>
              <div class="form-group col-md-6">
                <label for="beneficiary_dob">Date Of Birth</label>
                <input type="text" class="form-control" id="datepicker-birthday" name="beneficiary_dob" placeholder="Select Date" readonly>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label class="d-block">Select disabilities that apply</label>
                <div class="custom-control custom-checkbox">
                  <select class="form-control select2" name="disability_type[]" multiple="multiple">
                    <option value="1">None</option>
                  <?php
                    if(!empty($arrDisabilities))
                    {
                      foreach($arrDisabilities as $disability)
                      {
                      ?>
                        <option value="<?php echo $disability['disability_id'];?>"><?php echo $disability['disability_name'];?></option>
                      <?php
                        
                      }
                    }
                  ?>
                  </select>
                </div>
              </div>
              <div class="form-group col-md-6">
                <label for="beneficiary_name">Number of Dependents</label>
                <input type="number" class="form-control" name="dependents" placeholder="" min="0" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="category_id">Beneficiary Category</label>
                <select class="custom-select" name="category_id" required>
                  <option value="" selected> </option>
                  <?php
                    foreach($arrCats as $cat)
                    {
                  ?>
                  <option value="<?php echo $cat['category_id'];?>"><?php echo $cat['category_name'];?></option>
                  <?php
                    }
                  ?>
                </select>
              </div>
              <div class="form-group col-md-6">
                <label for="category_id">Literacy Level</label>
                <select class="custom-select" name="literacy_level" required>
                  <option value="" selected> </option>
                  <option value="0">0</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-8">
                <label for="ceg_id">Community Empowerment Group (CEG)</label>
                <select class="custom-select select2 beneficiary-add-ceg" name="ceg_id" required>
                  <option value="" selected> </option>
                  <?php
                    foreach($arrCegs as $ceg)
                    {
                  ?>
                    <option value="<?php echo $ceg['ceg_id'];?>">
                    <?php 
                      echo $ceg['ceg_name'] . ' ('.$ceg['village_name'].' Village, ' . $ceg['subcounty_name'].' Subcounty, '  . $ceg['district_name'].' District)';
                      ?>
                    </option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <!-- <div class="form-group">
              <label for="inputAddress">Address</label>
              <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
            </div> -->
            <button type="submit" class="btn btn-primary">Submit Form</button>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->
    <?php
      }
      else
      {
      ?>
        <div class="alert alert-primary d-flex align-items-center" role="alert">
        <i data-feather="alert-circle" class="mg-r-10"></i> You have not been assigned to a location. You cannot complete this action.
      </div>
      <?php
      }
    ?>

  </div><!-- container -->
</div>