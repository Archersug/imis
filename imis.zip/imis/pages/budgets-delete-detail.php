<?php
	$split = explode("-", $displayedPage['item']);
	$budgetId = $split[0];
	$detailId = $split[1];
?>
<script>
	window.location.href = "<?php echo $ROOT_FOLDER . "process/budgets-delete-detail.php?budget=$budgetId&item=$detailId"?>";
	//alert("Boo");
</script>