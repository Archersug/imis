<?php
  $arrUsergroups = dbGetUsergroups();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Usergroups</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">List of Usergroups</h4>
      </div>
      <!-- <div class="d-none d-md-block">
        <a href="" class="btn btn-sm pd-x-15 btn-primary btn-uppercase mg-l-5"><i data-feather="users" class="wd-10 mg-r-5"></i> Add Usergroup</a>
      </div> -->
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
            <div data-label="Usergroups" class="df-example demo-table">
        <table id="" class="table datatable">
          <thead>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="wd-45p">Name</th>
                  <th class="wd-10p">Members</th>
                  <th class="wd-20p">Actions</th>
              </tr>
          </thead>
          <tbody>
            <?php
              $i = 1;
              foreach($arrUsergroups as $group)
              {
            ?>
            <tr>
                <td><?php echo $i;?></td>
                <td><?php echo $group['usergroup_name'];?></td>
                <td></td>
                <td>
                  <a href="<?php echo $ROOT_FOLDER;?>usergroups/edit/<?php echo $group['usergroup_id'];?>" type="button" class="btn btn btn-outline-primary btn-icon btn-xs">
                    <i data-feather="edit"></i>
                  </a>
                  <a href="#" type="button" class="btn btn btn-outline-danger btn-icon btn-xs">
                    <i data-feather="trash"></i>
                  </a>
                </td>
            </tr>
            <?php
                $i++;
              }
            ?>
          </tbody>
      </table>
    </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>