<?php
  $arrDistricts = dbGetAllDistricts();
  $options = array('group_id' => '1');
  
  $arrCourses = dbGetTrainingCourses($options);
  $arrQuarters = dbGetCurrentQuarter();

  $options2 = array(
              'quarter_id' => $arrQuarters[0]['quarter_id'], 
              'district_id' => $_SESSION['USER']['ASSIGNMENTS']['locations']['districts'],
              'approved' => 'level1'
            );
  $arrTrained = dbGetFacilitatorsTrained($options2);
  //print_r($arrTrained);

?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Data Approval</a></li>
            <li class="breadcrumb-item active" aria-current="page">Level 2</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Level 2 Data Approval: Facilitator Training</h4>
      </div>
    </div>

        <!-- Alert User -->
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>
    <div class="row row-xs" style="margin-bottom: 10px;">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Entered Data" class="df-example demo-table">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2">District</th>
                <th scope="col" rowspan="2">Subcounty</th>
                <th scope="col" rowspan="2">Course</th>
                <th scope="col" rowspan="2">No. Trained</th>
              </tr>
              <tr>
                <th scope="col">L1</th>
                <th scope="col">L2</th>
                <th scope="col">L3</th>
              </tr>
            </thead>
            <tbody>
              <?php
                if(!empty($arrTrained))
                {
                  $i = 1;
                  foreach($arrTrained as $trained)
                  {
                  ?>
                    <tr>
                      <th scope="row"><?php echo $i;?></th>
                      <td><?php echo $trained['district_name'];?></td>
                      <td><?php echo $trained['subcounty_name'];?></td>
                      <td><?php echo $trained['course_name'];?></td>
                      <td><?php echo $trained['attended'];?></td>
                      <td>
                        <?php
                          if($trained['level1'])
                          {
                        ?>
                        <i data-feather="check-circle" class="feather-16"></i></td>
                        <?php
                          }
                          else
                          {
                          ?>
                          <i data-feather="more-horizontal" class="feather-16"></i>
                          <?php
                          }
                        ?>
                      <td>
                        <?php
                          if($trained['level2'])
                          {
                        ?>
                        <i data-feather="check-circle" class="feather-16"></i></td>
                        <?php
                          }
                          else
                          {
                          ?>
                          <i data-feather="more-horizontal" class="feather-16"></i>
                          <?php
                          }
                        ?>
                      </td>
                      <td>
                        <?php
                          if($trained['level3'])
                          {
                        ?>
                        <i data-feather="check-circle" class="feather-16"></i></td>
                        <?php
                          }
                          else
                          {
                          ?>
                          <i data-feather="more-horizontal" class="feather-16"></i>
                          <?php
                          }
                        ?>
                      </td>
                    </tr>
                  <?php
                    $i++;
                  }
                }
              ?>
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="row row-xs" style="margin-bottom: 10px;">
      <div class="col-sm-12 col-lg-12 tx-center">
        <a href="<?php echo $ROOT_FOLDER;?>process/modal-approve-data-facilitators-trained.php?quarter=<?php echo $arrQuarters[0]['quarter_id'];?>&subcounty=<?php echo $_SESSION['USER']['ASSIGNMENTS']['locations']['subcounties'];?>&level=2" class="btn btn-success">
          <i data-feather="check-circle" class="feather-16"></i> Approve</a>
        <button type="button" class="btn btn-danger" href="#modalApproveData" data-toggle="modal" data-subject="Facilitators Trained" data-desc="SANCTIONED! Facilitator Training data for <?php echo $arrTrained[0]['subcounty_name'];?> Subcounty, <?php echo $arrTrained[0]['district_name'];?> District" data-receiver-id="<?php echo $arrTrained[0]['user_id'];?>" data-sender-id="<?php echo $_SESSION['USER']['ICOLEW_USERID'];?>" data-receiver="<?php echo $arrTrained[0]['fullname'];?>">
          <i data-feather="alert-triangle" class="feather-16"></i> Sanction</button>
      </div>
    </div>

  </div><!-- container -->
</div>