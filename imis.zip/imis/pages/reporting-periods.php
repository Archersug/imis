<?php
  $arrQuarters = dbGetQuarters();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Project Settings</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Reporting Periods</h4>
      </div>
    </div>
    <div class="row row-xs" style="margin-bottom: 20px;">
      <div class="col-sm-12 col-lg-12">
        <div data-label="" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/users-add.php" method="post" data-parsley-validate>
            <fieldset class="form-fieldset">
              <legend>Quarters</legend>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label class="d-block">Current Reporting Quarter</label>
                  <select class="custom-select">
                    <option selected> </option>
                    <?php
                      if(!empty($arrQuarters))
                      {
                        foreach($arrQuarters as $quarter)
                        {
                        ?>
                          <option value="<?php echo $quarter['quarter_id'];?>"<?php echo($quarter['quarter_status'] == "OPEN")? ' selected':'';?>>
                            <?php echo $quarter['quarter_name'];?>
                          </option>
                        <?php
                        }
                      }
                    ?>
                  </select>
                  <p class="tx-gray-500" style="padding: 5px;">A reporting quarter automatically closes at midnight on the first day of the new quarter.</p>
                </div>
              </div>

              <div class="form-row">
                <div class="form-group col-md-8">
                  <button type="submit" class="btn btn-primary">Save</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>