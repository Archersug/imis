<?php
  // Receive report query filters
  if($displayedPage['reportQuery'])
  {
    $district = $displayedPage['reportQuery'][0];
    $subcounty = $displayedPage['reportQuery'][1];
    $year = $displayedPage['reportQuery'][2];
  }
  else
  {
    $district = 'ALL';
    $subcounty = 'ALL';
    $year = '2020';
  }

  $arrDistricts = dbGetAllDistricts();
  $arrIndicators = dbGetAllIndicators();
  $arrCats = dbGetBeneficiaryCategories();

  //----------REPORT Query----------------
  $qTargets = "SELECT tbl_indicator_targets.*
                FROM tbl_indicator_targets
                WHERE tbl_indicator_targets.year = " . MySQL::SQLValue($year);

  $arrTargets = $db->QueryArray($qTargets, MYSQLI_ASSOC);

  // Set Excel export session query
  $_SESSION['REPORT']['name'] = "Annual Indicator Report";
  $_SESSION['REPORT']['query'] = $qTargets;
  $_SESSION['REPORT']['params'] = array(
                                      array("label" => "START DATE", "value" => '$start'),
                                      array("label" => "END DATE", "value" => '$end'),
                                  );
  $_SESSION['REPORT']['headers'] = array("No.", "Date", "Title", "Amount");
  
  
  
  
  
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Reports</a></li>
            <li class="breadcrumb-item active" aria-current="page">Performance Reports</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1"> Annual Indicator Report</h4>
      </div>
      <div class="d-none d-md-block">
        <div class="dropdown">
          <button class="btn btn-white" onclick="PrintElem('print-div')"><i data-feather="printer" class="mg-r-5"></i> Print</button>
          <!-- <button class="btn btn-white mg-l-5"><i data-feather="mail" class="mg-r-5"></i> Email</button> -->
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Export
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="#">Excel</a>
            <a class="dropdown-item" href="#">PDF</a>
          </div>
        </div>
      </div>
    </div>

  <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
    <div class="d-sm-flex align-items-center justify-content-between">
      <div data-label="Filters" class="df-example demo-table col-md-12">
        <form method="post" action="<?php echo $ROOT_FOLDER;?>process/report-beneficiary-register.php">
          <div class="form-row">
            <div class="form-group col-md-3">
              <label>District</label>
              <select name="district_id" class="custom-select select2 dependable-select" data-initiates="sel-subregions" data-list="regions">
                <option value="0" selected>Select District</option>
                <?php
                    foreach($arrDistricts as $dist)
                    {
                  ?>
                  <option value="<?php echo $dist['district_id'];?>">
                    <?php echo ucwords(strtolower($dist['district_name']));?>
                  </option>
                  <?php
                    }
                  ?>
              </select>
            </div>
            <div class="form-group col-md-3">
              <label>Subcounty</label>
              <select id="sel-counties" name="county_id" class="custom-select">
                <option value="0" selected>Select Subcounty</option>
              </select>
            </div>
            <div class="form-group col-md-3">
              <label>Year</label>
              <select id="sel-counties" name="county_id" class="custom-select">
                <option value="2020" selected>2020</option>
                <option value="2019">2019</option>
                <option value="2018">2018</option>
              </select>
            </div>
            
          </div>

          <button type="submit" class="btn btn-primary">Go</button>
        </form>
      </div>
    </div>
  </div><!-- container -->

    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Report" class="df-example demo-table" id="print-div" style="width: 100%;">
          <div style="padding: 10px;">
         
            <h3>
              Annual Indicator Report
            </h3>
            <div>
              Year: 2020 | District: <?php echo $district;?> | Subcounty: <?php echo $subcounty;?>
            </div>
          </div>
          <table class="table table-sm table-striped table-bordered" >
            <thead>
              <tr>
                  <td colspan="13" class="wd-10p">
                    KEY: T = Target, A = Achieved, % = Percentage Achieved
                  </td>
              </tr>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="wd-15p">Indicator</th>
                  <th colspan="2" class="wd-10p text-center">Jan-Mar</th>
                  <th colspan="2" class="wd-10p text-center">Apr-Jun</th>
                  <th colspan="2" class="wd-10p text-center">Jul-Sep</th>
                  <th colspan="2" class="wd-10p text-center">Oct-Dec</th>
                 <!-- <th colspan="3" class="wd-10p text-center">Total</th>-->
              </tr>
              <tr>
                  <th class="wd-5p"></th>
                  <th class="wd-15p" style="white-space:inherit;"></th>
                  <th class="wd-10p text-center">T</th>
                  <th class="wd-10p text-center">A</th>
                  <!--<th class="wd-10p text-center">%</th>-->
                  <th class="wd-10p text-center">T</th>
                  <th class="wd-10p text-center">A</th>
                   <!--<th class="wd-10p text-center">%</th>-->
                  <th class="wd-10p text-center">T</th>
                  <th class="wd-10p text-center">A</th>
                   <!--<th class="wd-10p text-center">%</th>-->
                  <th class="wd-10p text-center">T</th>
                  <th class="wd-10p text-center">A</th>
                   <!--<th class="wd-10p text-center">%</th>-->
                  <!--<th class="wd-10p text-center">T</th>
                  <th class="wd-10p text-center">A</th>
                  <th class="wd-10p text-center">%</th>-->
              </tr>
            </thead>
            <tbody>
              <?php
                $i = 1;
                //print_r($arrTargets);
                foreach($arrIndicators as $ind)
                {
              ?>
              <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $ind['indicator_name'];?></td>
                  <td class="text-center">
                    <?php
                      $act1 = getIndicatorActuals($ind['indicator_id'],$quarter=32);
                      $act2 = getIndicatorActuals($ind['indicator_id'],$quarter=33);
                      $act3 = getIndicatorActuals($ind['indicator_id'],$quarter=34);
                      $act4 = getIndicatorActuals($ind['indicator_id'],$quarter=35);
                      $totalTarget = 0;
                      $totalActual = 0;
                      foreach($arrTargets as $target)
                      {
                        if(($target['indicator_id'] == $ind['indicator_id']) && ($target['quarter_number'] == 1))
                        {
                          echo number_format($target['target']);
                         // $totalTarget += $target['target']; 
                          break;
                        }
                      }
                    ?>
                  </td>
                  <td class="text-center">
                    <?php 
                      /*if(isset($target['target']))
                      {*/
                        $actual = $act1;
                        echo number_format($actual);
                        //$totalActual += $act1; 
                      //}
					   
                    ?>
                  </td>
                  <td class="text-center">
                    <?php
                      foreach($arrTargets as $target)
                      {
                        if(($target['indicator_id'] == $ind['indicator_id']) && ($target['quarter_number'] == 2))
                        {
                          echo number_format($target['target']);
                          //$totalTarget += $target['target']; 
                          break;
                        }
                      }
                    ?>
                  </td>
                  <td class="text-center">
                    <?php 
                     /* if(isset($target['target']))
                      {*/
                        $actual = $act2;
                        echo number_format($actual);
                        //$totalActual += $act2; 
                      //}
                    ?>
                  </td>
                  <td class="text-center">
                    <?php
                      foreach($arrTargets as $target)
                      {
                        if(($target['indicator_id'] == $ind['indicator_id']) && ($target['quarter_number'] == 3))
                        {
                          echo number_format($target['target']);
                          //$totalTarget += $target['target']; 
                          break;
                        }
                      }
                    ?>
                  </td>
                  <td class="text-center">
                    <?php 
                     /*if(isset($target['target']))
                      {*/
                        $actual = $act3;
                        echo number_format($actual);
                        //$totalActual += $act3; 
                      //}
                    ?>
                  </td>
                  <td class="text-center">
                    <?php
                      foreach($arrTargets as $target)
                      {
                        if(($target['indicator_id'] == $ind['indicator_id']) && ($target['quarter_number'] == 4))
                        {
                          echo number_format($target['target']);
                         // $totalTarget += $target['target']; 
                          break;
                        }
                      }
                    ?>
                  </td>
                  <td class="text-center">
                    <?php 
                    
                        $actual = $act4;
                        echo number_format($actual);
                        //$totalActual += $act4; 
                      
                    ?>
                  </td>
                  <!--<td class="text-center">
                    <?php echo $totalTarget;?>
                  </td>
                  <td class="text-center">
                    <?php echo $totalActual;?>
                  </td>
                  <td class="text-center">
                    <?php echo ($totalTarget > 0)? round(($totalActual / $totalTarget) * 100):'';?>
                  </td>-->
              </tr>
              <?php
                  $i++;
                }
              ?>
            </tbody>
          </table>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>