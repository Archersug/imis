<?php
  $options = array('message_id' => $displayedPage['item']);
  $arrMessage = getInboxMessages($options);

  if(empty($arrMessage))
  {
    include("404.php");
  }
  else
  {
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Profile</a></li>
            <li class="breadcrumb-item active" aria-current="page">Inbox</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Message</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="" class="df-example demo-table">
          <div class="card-body pd-20 pd-lg-25">
            <div class="media align-items-center mg-b-20">
              <div class="avatar"><span class="avatar-initial rounded-circle bg-indigo">
                      <?php echo substr($arrMessage[0]['sender'], 0, 1);?>
                    </span></div>
              <div class="media-body pd-l-15">
                <h6 class="mg-b-3"><?php echo $arrMessage[0]['sender'];?></h6>
                <span class="d-block tx-13 tx-color-03"><?php echo $arrMessage[0]['usergroup_name'];?></span>
              </div>
              <span class="d-none d-sm-block tx-12 tx-color-03 align-self-start"><?php echo date("l, M, j, Y, g:i a", strtotime($arrMessage[0]['message_date']));?></span>
            </div><!-- media -->
            <p class="mg-b-20">
              <?php echo nl2br($arrMessage[0]['message_body']);?>
            </p>

            <?php
              if(!empty($arrMessage[0]['replies']))
              {
                foreach($arrMessage[0]['replies'] as $reply)
                {
                  if($reply['message_date'] < $arrMessage[0]['message_date'])
                  {
                ?>
                  <div class="bd bg-gray-50 pd-y-15 pd-x-15 pd-sm-x-20" style="margin-bottom: 5px;">
                    <h6 class="tx-15 mg-b-3"><?php echo $reply['message_heading'];?></h6>
                    <span class="d-none d-sm-block tx-12 tx-color-03 align-self-start tx-right"><?php echo date("l, M, j, Y, g:i a", strtotime($reply['message_date']));?></span>
                    <p class="mg-b-0 tx-14"><?php echo nl2br($reply['message_body']);?></p>
                    <span class="tx-13 tx-color-03"><?php echo $reply['sender'];?></span>
                  </div>

                <?php
                  }
                }
              }
            ?>                
          </div>
        </div>
      </div><!-- col -->
    </div><!-- row -->
  </div><!-- container -->
  <div class="row tx-right">
    <div class="col-md-4">
      <button id="mailComposeBtn" class="btn btn-primary btn-block tx-uppercase tx-10 tx-medium tx-sans tx-spacing-4" data-toggle="modal" data-target="#composeModal" data-receiver-id="<?php echo $arrMessage[0]['sender_id'];?>" data-receiver="<?php echo $arrMessage[0]['sender'];?>" data-sender-id="<?php echo $arrMessage[0]['receiver_id'];?>">Reply</button>
    </div>
  </div>
</div>
<?php
  }
?>