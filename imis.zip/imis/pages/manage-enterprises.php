<?php
  $arrCats = dbGetCEGFarmEnterprises();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Project Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">CLC Farm Enterprises</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">CLC Farm Enterprises</h4>
      </div>
      <div class="d-none d-md-block">
        <a href="" class="btn btn-sm pd-x-15 btn-primary btn-uppercase mg-l-5" data-toggle="modal" data-target="#modalAddFarmEnterprises"> New Entry</a>
      </div>
    </div>
        <!-- Alert User -->
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>
    
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
            <div data-label="Farm Enterprises" class="df-example demo-table">
        <table id="" class="table datatable">
          <thead>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="wd-55p">Name</th>
      
                  <th class="wd-20p">Action</th>
              </tr>
          </thead>
          <tbody>
            <?php
              $i = 1;
              foreach($arrCats as $cat)
              {
            ?>
            <tr>
                <td><?php echo $i;?></td>
                <td><?php echo $cat['enterprise_name'];?></td>
    
                <td>
                  <a href="#" type="button" class="btn btn btn-outline-primary btn-icon btn-xs EditCLCFarmEnterprise" data-toggle="modal" data-target="#modalEditFarmEnterprises" data-cat-id="<?php echo $cat['enterprise_id'];?>">
                    <i data-feather="edit"></i>
                  </a>
                  <a href="#" type="button" class="btn btn btn-outline-danger btn-icon btn-xs">
                    <i data-feather="trash"></i>
                  </a>
                </td>
            </tr>
            <?php
                $i++;
              }
            ?>
          </tbody>
      </table>
    </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>

<!-- Modal -->
<div class="modal fade" id="modalAddFarmEnterprises" tabindex="-1" role="dialog" aria-labelledby="modalBudgetItemTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modalAddCLCFarmEnterprise.php" method="post">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Add CLC Farm Enterprise</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-row">
          <div class="form-group col-md-6">
             <label for="detail_name">Farm Enterprise</label>
            <input type="text" class="form-control" value="" name="enterprise_name" placeholder="Enterprise Name" required>
          </div>
        </div>
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalEditFarmEnterprises" tabindex="-1" role="dialog" aria-labelledby="modalBudgetItemTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modaEditCLCFarmEnterprise.php" method="post">
        <input type="hidden" id="enterprise_id" name="enterprise_id" value="">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Edit CLC Farm Enterprise</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="form-row">
          <div class="form-group col-md-6">
            <label for="detail_name">Farm Enterprise</label>
            <input type="text" class="form-control" value="" name="enterprise_name" id="enterprise_name" placeholder="Enterprise Name" >
          </div>
        </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>