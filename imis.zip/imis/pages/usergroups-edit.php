<?php
  $options = array('usergroup_id' => $displayedPage['item']);
  $arrGroup = dbGetUsergroups($options);
  $arrPermissions = dbGetMenuPermissions($displayedPage['item']);
  $arrPermittedPages = array();
  //print_r($arrPermissions);
   if(!empty($arrPermissions))
   {
      foreach($arrPermissions as $perm)
      {
         $arrPermittedPages[] = $perm;
      }
   }

?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Usergroups</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Edit Usergroup: <?php echo $arrGroup[0]['usergroup_name'];?></h4>
      </div>
    </div>
       <!-- Alert User -->
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
      ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Edit Usergroup" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/usergroups-edit.php" method="post" data-parsley-validate>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="usergroup_name">Usergroup Name</label>
                <input type="hidden" name="hidden_id" value="<?php echo $arrGroup[0]['usergroup_id'];?>">
                <input type="text" class="form-control" id="usergroup_name" name="usergroup_name" placeholder="Usergroup Name" value="<?php echo $arrGroup[0]['usergroup_name'];?>" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-9">
                <label for="usergroup_name">Page Access</label>
                <table id="" class="table table-hover">
                  <thead>
                      <tr>
                          <th class="wd-50p">Page</th>
                          <th class="wd-5p">Access</th>
                      </tr>
                  </thead>
                  <tbody>
                    <?php
                      $i = 1;
                      
                      foreach($arrMenuSections as $section)
                      {
                      ?>
                        <tr><td colspan="3"><?php echo strtoupper($section['section_name']);?></td></tr>
                        <?php
                          foreach($arrCats as $cat)
                          {
                            if($cat['section_id'] == $section['section_id'])
                            {
                          ?>
                            <tr><td colspan="3"><b><?php echo $cat['cat_name'];?></b></td></tr>
                                <?php
                                  foreach($arrMenuItems as $item)
                                  {
                                    if(in_array($item['item_id'], $arrPerms) && $item['item_category'] == $cat['cat_id'])
                                    {
                                ?>
                                <tr>
                                  <td><b>>> <?php echo $item['item_name'];?></b><br/>
                                    <?php echo $item['item_description'];?>
                                  </td>
                                  <td>
                                    <div class="custom-control custom-checkbox">
                                      <input type="checkbox" class="custom-control-input" id="customCheck<?php echo $item['item_id'];?>" value="<?php echo $item['item_id'];?>" name="check_permissions[]"<?php echo in_array($item['item_id'], $arrPermittedPages)? ' checked="checked"':'';?>>
                                      <label class="custom-control-label" for="customCheck<?php echo $item['item_id'];?>"></label>
                                    </div>
                                  </td>
                                </tr>
                                <?php
                                      $i++;
                                    }
                                  }
                                ?>
                                <tr><td colspan="3"></td></tr>  
                            <?php                        
                            }
                          }
                        
                      }
                    ?>
                  </tbody>
              </table>
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
        
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>