<?php
	$budgetId = $displayedPage['item'];
?>
<script>
	window.location.href = "<?php echo $ROOT_FOLDER . "process/budgets-delete.php?budget=$budgetId"?>";
	//alert("Boo");
</script>