<?php
  $options = array("clc_id" => $displayedPage['item']);
  $arrClc = dbGetCLCs($options);
  $arrPartnerships = dbGetAllCLCPartnerships($options);
  $arrServicesOffered = dbGetAllCLCServicesOffered($options);
  $arrGroups = dbGetCLCGroups($displayedPage['item']);
  $arrParish = dbGetParishFromId($arrClc[0]['parish_id']);
  $arrServices = dbGetAllCLCServices();
  $currentQuarter = dbGetCurrentQuarter();
   $options2 = array('quarter_id' => $currentQuarter[0]['quarter_id'], 'clc_id' => $displayedPage['item']);
  $arrUsers = dbGetCLCUsers($options2);
  $arrPartners = dbGetPartners();
?>

<div class="content-body">
  <div class="container pd-x-0 tx-13">
    <?php
      if(isset($_SESSION['ALERT-USER']))
      {
    ?>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-dismissible alert-solid alert-<?php echo $_SESSION['ALERT-USER']['type'];?> d-flex align-items-center" role="alert">
          <i data-feather="<?php echo ($_SESSION['ALERT-USER']['type']=="success")? 'check-circle':'x-circle';?>" class="mg-r-10"></i> <?php echo $_SESSION['ALERT-USER']['message'];?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
        </div>
      </div>
    </div>
    <?php
      unset($_SESSION['ALERT-USER']);
      }
    ?>
    <div class="media d-block d-lg-flex">
      <div class="profile-sidebar profile-sidebar-two pd-lg-r-15">

        <div class="row">
          <div class="col-sm-3 col-md-2 col-lg">
            <div class="avatar avatar-xxl avatar-online"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div>
          </div><!-- col -->
        </div>
        <div class="row">
          <div class="col-sm-8 col-md-7 col-lg mg-t-20 mg-sm-t-0 mg-lg-t-25">
            <h5 class="mg-b-2 tx-spacing--1"><?php echo $arrClc[0]['clc_name'];?></h5>
            <p class="tx-color-03 mg-b-25"><?php echo $arrClc[0]['clc_code'];?></p>

          </div><!-- col -->
        </div>
        <div class="row">
          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <label class="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">Contact Information</label>
            <ul class="list-unstyled profile-info-list">
              <li><i data-feather="map-pin"></i> <?php echo ucwords(strtolower($arrParish));?></li>
              <li>
                <a href="https://www.google.com/maps?sxsrf=ALeKk00vDkepkMrQrqsD7A8AWBdKAgwCIA:1612340054143&q=<?php echo $arrClc[0]['clc_coordinates'];?>&gs_lcp=CgZwc3ktYWIQAzoECAAQR1D6gNcEWPqA1wRg84bXBGgAcAR4AIABtgKIAbYCkgEDMy0xmAEAoAECoAEBqgEHZ3dzLXdpesgBCMABAQ&uact=5&um=1&ie=UTF-8&sa=X&ved=2ahUKEwj-_523yc3uAhWOlhQKHW5JDSQQ_AUoA3oECAEQBQ" target="_blank" title="Map Coordinates">
                  <i data-feather="map"></i> <?php echo $arrClc[0]['clc_coordinates'];?>
                </a>
              </li>
              <!-- <li><i data-feather="mail"></i> <?php //echo $arrClc[0]['ceg_email'];?></li> -->
            </ul>
          </div><!-- col -->
        </div>
        <div class="row">

          <div class="col-sm-6 col-md-5 col-lg mg-t-40">
            <label class="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">CEGs</label>
            <ul class="list-unstyled profile-info-list">
              <?php
                if(!empty($arrGroups))
                {
                  $i = 1;
                  foreach($arrGroups as $group)
                  {
                  ?>
                    <div class="beneficiary-list-item"><?php echo $i;?>. <a href="<?php echo $ROOT_FOLDER;?>cegs/view/<?php echo $group['ceg_id'];?>">
                      <?php echo $group['ceg_name'];?></a></div>
                  <?php
                    $i++;
                  }
                }
              ?>
              
            </ul>
          </div><!-- col -->
        </div><!-- row -->

      </div><!-- profile-sidebar -->
      <div class="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">


        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Services Offered</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalServices"><i data-feather="plus"></i> Add New Service</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <?php
              if(!empty($arrServicesOffered))
              {
                foreach($arrServicesOffered as $offered)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="slack" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $offered['service_name'];?></h6>
                          <p class="tx-12 mg-b-10"><?php if(!is_null($offered['service_description'])) echo nl2br(substr($offered['service_description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
            
          </div>
        </div><!-- card -->

        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">CLC Users</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalAddUsers"><i data-feather="plus"></i> Update Number of Visitors</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <div class="media">
                  <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                    <i data-feather="loader" class="tx-white-7 wd-20 ht-20"></i>
                  </div>
                  <div class="media-body pd-l-15">
                    <h6 class="tx-color-01 mg-b-5">Number of CLC Users: <?php echo $currentQuarter[0]['quarter_name'];?></h6>
                    <p class="tx-12 mg-b-10">Recorded Quarterly</p>
                  </div>
                </div><!-- media -->
              </div>
            </div>
            <div class="row">
              <div class="col-sm col-lg-12 col-xl">
                <table class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Service</th>
                      <th scope="col">Number</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      if(!empty($arrUsers))
                      {
                        $i = 1;
                        foreach($arrUsers as $users)
                        {
                        ?>
                          <tr>
                            <th scope="row"><?php echo $i;?></th>
                            <td><?php echo $users['service_name'];?></td>
                            <td><?php echo $users['users'];?></td>
                          </tr>
                        <?php
                        $i++;
                        }
                      }
                    ?>
                   
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div><!-- card -->

        <div class="card mg-b-20 mg-lg-b-25">
          <div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
            <h6 class="tx-13 tx-spacing-1 tx-uppercase tx-semibold mg-b-0">Partnerships</h6>
            <nav class="nav nav-with-icon tx-13">
              <a href="" class="nav-link" data-toggle="modal" data-target="#modalPartnerships"><i data-feather="plus"></i> Add New Partnership</a>
            </nav>
          </div><!-- card-header -->
          <div class="card-body pd-25">
            <?php
              if(!empty($arrPartnerships))
              {
                foreach($arrPartnerships as $partnership)
                {
                ?>
                  <div class="row">
                    <div class="col-sm col-lg-12 col-xl">
                      <div class="media">
                        <div class="wd-45 ht-45 bg-gray-900 rounded d-flex align-items-center justify-content-center">
                          <i data-feather="link" class="tx-white-7 wd-20 ht-20"></i>
                        </div>
                        <div class="media-body pd-l-15">
                          <h6 class="tx-color-01 mg-b-5"><?php echo $partnership['partner_name'].": ". $partnership['partnership_name'];?></h6>
                          <p class="tx-12 mg-b-10"><?php if(!is_null($partnership['partnership_description'])) echo nl2br(substr($partnership['partnership_description'], 0, 500));?> 
                          </p>
                        </div>
                      </div><!-- media -->
                      <hr>
                    </div>
                  </div>
                <?php
                }
              }
            ?>
            
          </div>
        </div><!-- card -->

      </div><!-- media-body -->

    </div><!-- media -->
  </div><!-- container -->
</div><!-- content-body -->


<!-- Modal Services -->
<div class="modal fade" id="modalServices" tabindex="-1" role="dialog" aria-labelledby="modalServicesTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-clc-services-offered.php" method="post">
        <input type="hidden" name="clc_id" value="<?php echo $displayedPage['item'];?>">
        <input type="hidden" name="user_id" value="<?php echo $displayedPage['item'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New Service Offered</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label>Service</label>
              <select name="service_id" class="custom-select" required>
                <option value="" selected>Choose One</option>
                <?php
                  foreach($arrServices as $service)
                  {
                  ?>
                    <option value="<?php echo $service['service_id'];?>">
                      <?php echo $service['service_name'];?>
                      </option>
                  <?php
                  }
                ?>
              </select>
            </div>

          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="date_started">Start Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item" name="date_started" placeholder="Select Date" required>
            </div>

          </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Add Users-->
<div class="modal fade" id="modalAddUsers" tabindex="-1" role="dialog" aria-labelledby="modalAddUsersTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-clc-users.php" method="post">
        <input type="hidden" name="clc_id" value="<?php echo $displayedPage['item'];?>">
        <input type="hidden" name="user_id" value="<?php echo $_SESSION['USER']['ICOLEW_USERID'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">CLC Users This Quarter (<?php echo $currentQuarter[0]['quarter_name'];?>)</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-sm col-lg-12 col-xl">
            <table class="table table-striped table-bordered table-sm">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Service</th>
                  <th scope="col">Number</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  if(!empty($arrServicesOffered))
                  {
                    $i = 1;
                    foreach($arrServicesOffered as $offered)
                    {
                    ?>
                      <tr>
                        <th scope="row"><?php echo $i;?></th>
                        <td><?php echo $offered['service_name'];?></td>
                        <td>
                          <div class="form-group col-md-6">
                            <input type="number" class="form-control" value="" name="users[<?php echo $offered['service_id'];?>]" required>
                          </div>
                        </td>
                      </tr>
                    <?php
                    $i++;
                    }
                  }
                ?>
               
              </tbody>
            </table>
          </div>
        </div> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save">
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Partnerships -->
<div class="modal fade" id="modalPartnerships" tabindex="-1" role="dialog" aria-labelledby="modalPartnershipsTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <form action="<?php echo $ROOT_FOLDER;?>process/modal-clc-new-partnership.php" method="post">
        <input type="hidden" name="clc_id" value="<?php echo $displayedPage['item'];?>">
        <input type="hidden" name="user_id" value="<?php echo $_SESSION['USER']['ICOLEW_USERID'];?>">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New Partnership</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-row">
            <div class="form-group col-md-4">
              <label>Partner</label>
              <select name="partner_id" class="custom-select" required>
                <option value="" selected>Choose One</option>
                <?php
                  foreach($arrPartners as $partner)
                  {
                  ?>
                    <option value="<?php echo $partner['partner_id'];?>">
                      <?php echo $partner['partner_name'];?>
                      </option>
                  <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-8">
              <label for="event_name">Partnership Name</label>
              <input type="text" class="form-control" name="partnership_name" placeholder="Partnership Name" value="" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="message-text" class="col-form-label">Partnership Description:</label>
              <textarea class="form-control" name="partnership_description"></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="date_started">Start Date</label>
              <input type="date" class="form-control datepicker" id="datepicker-item" name="start_date" placeholder="Select Date" required>
            </div>

          </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Save changes">
      </div>
      </form>
    </div>
  </div>
</div>