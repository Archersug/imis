<?php
  $arrComp = dbGetComponent($displayedPage['item']);
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Features</a></li>
            <li class="breadcrumb-item active" aria-current="page">Components</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1"><?php echo $arrComp['component_name'] . " (" . $arrComp['component_abbr'] . ")";?></h4>
      </div>
      <div class="d-none d-md-block">
        <a href="<?php echo $ROOT_FOLDER;?>users/add/1" class="btn btn-sm pd-x-15 btn-primary btn-uppercase mg-l-5"><i data-feather="user-plus" class="wd-10 mg-r-5"></i> Add New Unit</a>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
            <div data-label="Component Units" class="df-example demo-table">
        <table id="" class="table datatable">
          <thead>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="wd-15p">Name</th>
                  <th class="wd-60p">Description</th>
                  <th class="wd-10p">Actions</th>
              </tr>
          </thead>
          <tbody>
            <?php
              $i = 1;
              foreach($arrComp['units'] as $unit)
              {
            ?>
            <tr>
                <td><?php echo $i;?></td>
                <td><a href="#"><?php echo $unit['unit_name'];?></a></td>
                <td><?php echo $unit['unit_description'];?></td>
                <td>
                  <a href="#" type="button" class="btn btn btn-outline-primary btn-icon btn-xs">
                    <i data-feather="edit"></i>
                  </a>
                  <a href="#" type="button" class="btn btn btn-outline-danger btn-icon btn-xs">
                    <i data-feather="trash"></i>
                  </a>
                </td>
            </tr>
            <?php
                $i++;
              }
            ?>
          </tbody>
      </table>
    </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>