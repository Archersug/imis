<?php
  $arrRegions = dbGetAllRegions();
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Locations</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Add Subregion</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="New Subregion" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/subregions-add.php" method="post" data-parsley-validate>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="subregion_name">Name</label>
                <input type="text" class="form-control" id="subregion_name" name="subregion_name" placeholder="Subregion Name" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="region_id">Region</label>
                <select class="custom-select" name="region_id" required>
                  <option value="" selected> </option>
                  <?php
                    foreach($arrRegions as $region)
                    {
                  ?>
                  <option value="<?php echo $region['region_id'];?>"><?php echo $region['region_name'];?></option>
                  <?php
                    }
                  ?>
                </select>
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit Form</button>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>