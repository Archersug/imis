<?php
  // Receive report query filters
  if($displayedPage['reportQuery'])
  {
    $region = $displayedPage['reportQuery'][0];
    $subregion = $displayedPage['reportQuery'][1];
    $district = $displayedPage['reportQuery'][2];
    $county = $displayedPage['reportQuery'][3];
    $subcounty = $displayedPage['reportQuery'][4];
    $parish = $displayedPage['reportQuery'][5];
    $clc = $displayedPage['reportQuery'][6];
    $gender = $displayedPage['reportQuery'][7];
    $category = $displayedPage['reportQuery'][8];
    $disabled = $displayedPage['reportQuery'][9];
  }
  else
  {
    $region = '';
    $subregion = '';
    $district = '';
    $county = '';
    $subcounty = '';
    $parish = '';
    $clc = '';
    $gender = '';
    $category = '';
    $disabled = '';
  }

  $arrRegions = dbGetAllRegions();
  $arrCLCs = dbGetCLCs();
  $arrCats = dbGetBeneficiaryCategories();

  //----------REPORT Query----------------
  $qBenefs = "SELECT tbl_beneficiaries.*, tbl_beneficiary_categories.category_abbr, 
                tbl_ceg_leadership.position_name
              FROM tbl_beneficiaries
              LEFT JOIN tbl_beneficiary_categories ON tbl_beneficiary_categories.category_id = tbl_beneficiaries.category_id
              LEFT JOIN tbl_ceg_leadership ON tbl_ceg_leadership.position_id = tbl_beneficiaries.position_id
              WHERE 1";

  $arrBenefs = $db->QueryArray($qBenefs, MYSQLI_ASSOC);

  // Set Excel export session query
  $_SESSION['REPORT']['name'] = "Payment Summaries";
  $_SESSION['REPORT']['query'] = $qBenefs;
  $_SESSION['REPORT']['params'] = array(
                                      array("label" => "START DATE", "value" => '$start'),
                                      array("label" => "END DATE", "value" => '$end'),
                                  );
  $_SESSION['REPORT']['headers'] = array("No.", "Date", "Title", "Amount");
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Reports</a></li>
            <li class="breadcrumb-item active" aria-current="page">Engagement Reports</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1"> Beneficiary Register</h4>
      </div>
      <div class="d-none d-md-block">
        <div class="dropdown">
          <button class="btn btn-white" onclick="PrintElem('print-div')"><i data-feather="printer" class="mg-r-5"></i> Print</button>
          <!-- <button class="btn btn-white mg-l-5"><i data-feather="mail" class="mg-r-5"></i> Email</button> -->
          <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Export
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="#">Excel</a>
            <a class="dropdown-item" href="#">PDF</a>
          </div>
        </div>
      </div>
    </div>

  <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
    <div class="d-sm-flex align-items-center justify-content-between">
      <div data-label="Filters" class="df-example demo-table col-md-12">
        <form method="post" action="<?php echo $ROOT_FOLDER;?>process/report-beneficiary-register.php">
          <div class="form-row">
            <div class="form-group col-md-3">
              <label>Region</label>
              <select name="region_id" class="custom-select dependable-select" data-initiates="sel-subregions" data-list="regions">
                <option value="0" selected>Select Region</option>
                <?php
                    foreach($arrRegions as $region)
                    {
                  ?>
                  <option value="<?php echo $region['region_id'];?>">
                    <?php echo $region['region_name'];?>
                  </option>
                  <?php
                    }
                  ?>
              </select>
            </div>
            <div class="form-group col-md-3">
              <label>Sub Region</label>
              <select id="sel-subregions" name="subregion_id" class="custom-select dependable-select" data-initiates="sel-districts" data-list="subregions">
                <option value="0" selected>Select Region</option>
              </select>
            </div>
            <div class="form-group col-md-3">
              <label>District</label>
              <select id="sel-districts" name="district_id" class="custom-select dependable-select" data-initiates="sel-counties" data-list="districts">
                <option value="0" selected>Select Subregion</option>
              </select>
            </div>
            <div class="form-group col-md-3">
              <label>County</label>
              <select id="sel-counties" name="county_id" class="custom-select dependable-select" data-initiates="sel-subcounties" data-list="counties">
                <option value="0" selected>Select District</option>
              </select>
            </div>
            
          </div>
          <a class="btn btn-info" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">More Filters</a>

          <div class="collapse mg-t-5" id="collapseExample">
            <div class="form-row">
              <div class="form-group col-md-3">
                <label>Sub County</label>
                <select id="sel-subcounties" name="subcounty_id" class="custom-select dependable-select" data-initiates="sel-parishes" data-list="subcounties">
                  <option value="0" selected>Select County</option>
                </select>
              </div>
              <div class="form-group col-md-3">
                <label>Parish</label>
                <select id="sel-parishes" name="parish_id" class="custom-select dependable-select" data-initiates="sel-villages" data-list="parishes">
                  <option value="0" selected>Select Subcounty</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-3">
                <label>CLC</label>
                <select class="custom-select" name="clc_id">
                  <option value="0" selected>Select CLC</option>
                  <?php
                    if(!empty($arrCLCs))
                    {
                      foreach($arrCLCs as $clc)
                      {
                      ?>
                        <option value="<?php echo $clc['clc_id'];?>"><?php echo $clc['clc_name'];?></option>
                      <?php
                      }
                    }
                  ?>
                </select>
              </div>
              <div class="form-group col-md-3">
                <label>Gender</label>
                <select class="custom-select" name="gender">
                  <option value="0" selected>Select Gender</option>
                  <option value="MALE">Male</option>
                  <option value="FEMALE">Female</option>
                </select>
              </div>
              <div class="form-group col-md-3">
                <label>Category</label>
                <select class="custom-select" name="category_id">
                  <option value="0" selected>Select Category</option>
                   <?php
                    if(!empty($arrCats))
                    {
                      foreach($arrCats as $cat)
                      {
                      ?>
                        <option value="<?php echo $cat['category_id'];?>"><?php echo $cat['category_name'];?></option>
                      <?php
                      }
                    }
                  ?>
                </select>
              </div>
              <div class="form-group col-md-3">
                <label>Disabled</label>
                <select  class="custom-select" name="disabled">
                  <option value="-" selected>Select</option>
                  <option value="1">Yes</option>
                  <option value="0">No</option>
                </select>
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  </div><!-- container -->

    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Report" class="df-example demo-table" id="print-div" style="width: 100%;">
          <div style="padding: 10px;">
            <h6>ICOLEW Management Information System</h6>
            <h3>
              Beneficiary Register Report
            </h3>
            <div>
              Region: Central | Sub Region: Buganda | District: Mpigi 
            </div>
          </div>
          <table class="table table-sm table-striped">
            <thead>
              <tr>
                  <th class="wd-5p">#</th>
                  <th class="wd-15p">Name</th>
                  <th class="wd-10p">Gender</th>
                  <th class="wd-10p">Age</th>
                  <th class="wd-10p">Category</th>
                  <th class="wd-10p">Disabled</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $i = 1;
                foreach($arrBenefs as $ben)
                {
              ?>
              <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $ben['beneficiary_name'];?></td>
                  <td><?php echo $ben['beneficiary_gender'];?></td>
                  <td><?php echo calculateAgeFromDate($ben['beneficiary_dob']);?></td>
                  <td><?php echo $ben['category_abbr'];?></td>
                  <td><?php echo ($ben['beneficiary_disabled'])? 'YES':'';?> </td>
              </tr>
              <?php
                  $i++;
                }
              ?>
            </tbody>
          </table>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>