<?php
  $arrDistrict = dbGetDistrict($displayedPage['item']);
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Settings</a></li>
            <li class="breadcrumb-item active" aria-current="page">Locations</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Delete District</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div class="alert alert-warning d-flex align-items-center" role="alert">
          <i data-feather="alert-circle" class="mg-r-10"></i> This action cannot be undone. Only proceed if you are sure!!
        </div>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="Delete District" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/districts-delete.php" method="post" data-parsley-validate>
            <input type="hidden" name="district_id" value="<?php echo $arrDistrict['district_id'];?>">
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for=""><?php echo $arrDistrict['district_name'];?></label>
                
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Delete</button>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>