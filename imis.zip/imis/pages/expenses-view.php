<?php
  $options = array('expense_id' => $displayedPage['item']);
  $arrExpense = dbGetExpenseDetails($options);
?>

<div class="content-body tx-13">
  <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0" id="printableDiv">
    <div class="row">
      <div class="col-sm-6 col-lg-6 mg-t-40">
        <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Expense Details</label>
        <ul class="list-unstyled lh-7">
          <li class="d-flex">
            <span><b>Expense Name: </b></span>
            <span style="padding-left: 10px"> <?php echo $arrExpense[0]['expense_name'];?></span>
          </li>
          <li class="d-flex">
            <span><b>Expense Description: </b></span>
            <span style="padding-left: 10px"><?php echo $arrExpense[0]['expense_description'];?></span>
          </li>
          <li class="d-flex">
            <span><b>Expense Category: </b></span>
            <span style="padding-left: 10px"><?php echo $arrExpense[0]['category_name'];?></span>
          </li>
          <li class="d-flex">
            <span><b>Expense Date: </b></span>
            <span style="padding-left: 10px"><?php echo $arrExpense[0]['expense_date'];?></span>
          </li>
          <li class="d-flex">
            <span><b>Subcounty: </b></span>
            <span style="padding-left: 10px"><?php echo $arrExpense[0]['subcounty_name'];?></span>
          </li>
          <li class="d-flex">
            <span><b>District: </b></span>
            <span style="padding-left: 10px"><?php echo $arrExpense[0]['district_name'];?></span>
          </li>
        </ul>
      </div><!-- col -->
    </div><!-- row -->

    <div class="table-responsive mg-t-40">
      <table class="table table-invoice bd-b table-striped">
        <thead>
          <tr>
            <th class="wd-5p">#</th>
            <th class="wd-20p">Item</th>
            <th class="wd-40p d-none d-sm-table-cell">Description</th>
            <th class="tx-center">Quantity</th>
            <th class="tx-right">Unit Price</th>
            <th class="tx-right">Amount</th>
          </tr>
        </thead>
        <tbody>
          <?php
            if(!empty($arrExpense))
            {
              $i = 1;
              $totalAmount = 0;
              if(!empty($arrExpense['details']))
              {
                foreach($arrExpense['details'] as $item)
                {
                ?>
                <tr>
                  <td class="tx-nowrap"><?php echo $i;?></td>
                  <td class="tx-nowrap"><?php echo $item['detail_name'];?></td>
                  <td class="d-none d-sm-table-cell tx-color-03"><?php echo $item['detail_description'];?></td>
                  <td class="tx-center"><?php echo $item['detail_quantity'];?></td>
                  <td class="tx-right"><?php echo number_format($item['detail_price']);?></td>
                  <td class="tx-right"><?php echo number_format($item['detail_amount']);?></td>
                </tr>
                <?php
                  $totalAmount += $item['detail_amount'];
                  $i++;
                }
              }
            }
          ?>
          <tr>
            <td colspan="5" class="tx-right"><b>Total</b></td>
            <td class="tx-right"><b><?php echo number_format($totalAmount);?></b></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="row justify-content-between">
      <div class="col-sm-6 col-lg-6 order-2 order-sm-0 mg-t-40 mg-sm-t-0">
        
      </div><!-- col -->
      <div class="col-sm-6 col-lg-4 order-1 order-sm-0">

        <button class="btn btn-block btn-outline-light d-print-none" onclick="print();">Print</button>
      </div><!-- col -->
    </div><!-- row -->
  </div><!-- container -->
</div><!-- content -->