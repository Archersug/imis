<?php
?>
<div class="content-body">
  <div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb breadcrumb-style1 mg-b-10">
            <li class="breadcrumb-item"><a href="#">Repository</a></li>
            <li class="breadcrumb-item active" aria-current="page">Documents</li>
          </ol>
        </nav>
        <h4 class="mg-b-0 tx-spacing--1">Add Document</h4>
      </div>
    </div>
    <div class="row row-xs">
      <div class="col-sm-12 col-lg-12">
        <div data-label="New Document" class="df-example demo-table">
          <form action="<?php echo $ROOT_FOLDER;?>process/regions-add.php" method="post" data-parsley-validate>
            <div class="form-row">
              <div class="form-group col-md-10">
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="customFile">
                  <label class="custom-file-label" for="customFile">Choose file</label>
                </div>
              </div>
            </div>
            <button type="submit" class="btn btn-primary">Add Document</button>
          </form>
        </div>
      </div><!-- col -->
    </div><!-- row -->

  </div><!-- container -->
</div>