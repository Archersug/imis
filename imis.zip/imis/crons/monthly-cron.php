<?php
	/*********************************************
	The following functions will be run on the
	first day of every new month at midnight
	*********************************************/
	include("../includes/loader.php");

	updateCurrentReportingQuarter();
?>