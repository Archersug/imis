<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_activities", 
						"table_data" => $_POST, 
						"primary_field" => "activity_id", 
						"primary_data" => $_POST['activity_id']
					)
				);

	if($result['success'])
	{
		auditTrail("Edited CEG Activity " . $_POST["activity_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CEG Activity '".$_POST["activity_name"]."' successfully edited");
		header("Location: ../ceg-activity");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing CEG Activity'".$_POST["service_name"]."'. ". $result['message']);
		header("Location: ../ceg-activity");
	}

	
?>