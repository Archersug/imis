<?php
	include("../includes/loader.php");

	$db = new MySQL();

	$arrUsergroups = dbGetUsergroups();
	echo json_encode($arrUsergroups);
?>