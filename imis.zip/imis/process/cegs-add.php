<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_cegs", 
						"table_data" => $_POST, 
						"primary_field" => "ceg_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added CEG " . $_POST["ceg_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CEG '".$_POST["ceg_name"]."' successfully added");
		header("Location: ../cegs");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding ceg '".$_POST["ceg_name"]."'. " . $result['message']);
		header("Location: ../cegs");
	}

	
?>