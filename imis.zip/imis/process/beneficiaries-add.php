<?php
	include("../includes/loader.php");
	// Save new usergroups to db
	//print_r($_POST);

	$result = dbSaveTable(
				array("table_name" => "tbl_beneficiaries", 
						"table_data" => $_POST, 
						"primary_field" => "beneficiary_id", 
						"primary_data" => "NULL"
					)
				);
/*
	if($result)
	{
		auditTrail("Added beneficiary " . $_POST["beneficiary_name"]);
		header("Location: ../beneficiaries");
	}*/
	
	
	
	if($result['success'])
	{
		auditTrail("Added beneficiary " . $_POST["beneficiary_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Budget '".$_POST["budget_name"]."' successfully edited");
		header("Location: ../beneficiaries");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing Beneficiary '".$_POST["beneficiary_name"]."'. " . $result['message']);
		header("Location: ../beneficiaries");
	}
?>