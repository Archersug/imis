<?php
	include("../includes/loader.php");
	//print_r($_POST);
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_ceg_activities", 
						"table_data" => $_POST, 
						"primary_field" => "row_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added CEG activity ");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CEG activity successfully added");
		header("Location: ../cegs/view/".$_POST['ceg_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding CEG activity");
		header("Location: ../cegs/view/".$_POST['ceg_id']);
	}

	
?>