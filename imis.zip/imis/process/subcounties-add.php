<?php
	include("../includes/loader.php");

	//print_r($_POST);
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_subcounties", 
						"table_data" => $_POST, 
						"primary_field" => "subcounty_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added Subcounty " . $_POST["subregion_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Subcounty '".$_POST["subcounty_name"]."' successfully added");
		header("Location: ../subcounties");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding Subcounty '".$_POST["subcounty_name"]."'. " . $result['message']);
		header("Location: ../subcounties");
	}

	
?>