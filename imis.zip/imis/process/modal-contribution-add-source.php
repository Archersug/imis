<?php
	include("../includes/loader.php");
	
	// Save new contribution source to db
	$result = dbSaveTable(
				array("table_name" => "tbl_contribution_sources", 
						"table_data" => $_POST, 
						"primary_field" => "source_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added contribution source " . $_POST["source_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Contribution source '".$_POST["source_name"]."' successfully added");
		header("Location: ../contribution-sources");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding contribution source source'".$_POST["source_name"]."'. ". $result['message']);
		header("Location: ../contribution-sources");
	}

	
?>