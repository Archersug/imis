<?php
	session_start();
	//print_r($_POST);
	
	$region = $_POST['region_id'];
	$subregion = $_POST['subregion_id'];
	$district = $_POST['district_id'];
	$county = $_POST['county_id'];
	$subcounty = $_POST['subcounty_id'];
	$parish = $_POST['parish_id'];
	$clc = $_POST['clc_id'];
	$gender = $_POST['gender'];
	$category = $_POST['category_id'];
	$disabled = $_POST['disabled'];

	header("Location: ../reports/beneficiaries/$region/$subregion/$district/$county/$subcounty/$parish/$clc/$gender/$category/$disabled");
?>