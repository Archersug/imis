<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_regions", 
						"table_data" => $_POST, 
						"primary_field" => "region_id", 
						"primary_data" => $_POST["region_id"]
					)
				);

	if($result['success'])
	{
		auditTrail("Edited region " . $_POST["region_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Region '".$_POST["region_name"]."' successfully edited");
		header("Location: ../regions");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing region '".$_POST["region_name"]."'. ". $result['message']);
		header("Location: ../regions");
	}

	
?>