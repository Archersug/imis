<?php
	// Save new usergroups to db
	include("../includes/loader.php");
	
	$result = dbSaveTable(
			array("table_name" => "tbl_usergroups", 
					"table_data" => $_POST, 
					"primary_field" => "usergroup_id", 
					"primary_data" => "NULL"
				)
			);

	/*if($result)
	{
		auditTrail("Added user " . $_POST["fullname"]);
		header("Location: ../usergroups");
	}*/
	
	
	if($result['success'])
	{
		auditTrail("Added user group " . $_POST["fullname"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "user group '".$_POST["fullname"]."' successfully Added");
		header("Location: ../usergroups");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error Adding userg roup '".$_POST["fullname"]."'. ". $result['message']);
		header("Location: ../usergroups");
	}
?>