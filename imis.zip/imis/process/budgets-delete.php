<?php
	include("../includes/loader.php");
	
	// Delete budget detail
	$budgetId = $_GET['budget'];

	$result = dbDeleteFromTable(
				array("table_name" => "tbl_budgets", 
						"primary_field" => "budget_id", 
						"primary_data" => $budgetId
					)
				);

	if($result['success'])
	{
		auditTrail("Deleted budget " . $result['data']["budget_name"]);
		$_SESSION['ALERT-USER'] = array(
									"type" => "success", 
									"message" => "Budget '".$result['data']["budget_name"]."' successfully deleted"
								);
		header("Location: ../budgets");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error budget '".$result['data']["budget_name"]."'. " . $result['data']['message']);
		header("Location: ../budgets");
	}

	
?>