<?php
  include("../includes/loader.php");
  
  // Save new regions to db
  $result = dbSaveTable(
        array("table_name" => "tbl_constituencies", 
            "table_data" => $_POST, 
            "primary_field" => "constituency_id", 
            "primary_data" => "NULL"
          )
        );

  if($result['success'])
  {
    auditTrail("Edited County " . $_POST["subregion_name"]);
    $_SESSION['ALERT-USER'] = array("type" => "success", "message" => "County '".$_POST["constituency_name"]."' successfully edited");
    header("Location: ../counties");
  } 
  else
  {
    $_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding county '".$_POST["constituency_name"]."'. " . $result['message']);
    header("Location: ../counties");
  }

  
?>