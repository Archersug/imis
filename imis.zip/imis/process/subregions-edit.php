<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_sub_regions", 
						"table_data" => $_POST, 
						"primary_field" => "subregion_id", 
						"primary_data" => $_POST["subregion_id"]
					)
				);

	if($result['success'])
	{
		auditTrail("Edited subregion " . $_POST["subregion_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Subregion '".$_POST["subregion_name"]."' successfully edited");
		header("Location: ../subregions");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing subregion '".$_POST["subregion_name"]."'. ". $result['message']);
		header("Location: ../subregions");
	}

	
?>