<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_clc_services", 
						"table_data" => $_POST, 
						"primary_field" => "service_id", 
						"primary_data" => $_POST['service_id']
					)
				);

	if($result['success'])
	{
		auditTrail("Edited CLC Service " . $_POST["service_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CLC Service '".$_POST["service_name"]."' successfully edited");
		header("Location: ../clc-activities");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing CLC Activity'".$_POST["service_name"]."'.");
		header("Location: ../clc-activities");
	}

	
?>