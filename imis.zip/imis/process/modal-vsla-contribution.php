<?php
	include("../includes/loader.php");

	foreach ($_POST['contribution'] as $key => $value) {
		$row = array(
					'beneficiary_id' => $key,
					'ceg_id' => $_POST['ceg_id'],
					'vsla_id' => $_POST['vsla_id'],
					'contribution_date' => $_POST['contribution_date'],
					'contribution_amount' => $_POST['contribution'][$key]
					);
		// Save new VSLA contributions to db
		$result = dbSaveTable(
					array("table_name" => "tbl_vsla_contributions", 
							"table_data" => $row, 
							"primary_field" => "contribution_id", 
							"primary_data" => "NULL"
						)
					);

		if($result['success'])
		{
			auditTrail("Added VSLA contribution ");
			$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "VSLA contributions successfully added");
			//header("Location: ../cegs/view/".$_POST['ceg_id']);
		}	
		else
		{
			$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding Component progress");
			//header("Location: ../cegs/view/".$_POST['ceg_id']);
			die("Error adding VSLA contribution");
		} 
	}
	header("Location: ../cegs/view/".$_POST['ceg_id']);

	
?>