<?php
	include("../includes/loader.php");
	//print_r($_POST);

	$db = new MySQL();


	foreach ($_POST['facilitator_id'] as $key => $value) {
		$filter['quarter_id'] = MySQL::SQLValue($_POST['quarter_id']);
		$filter['facilitator_id'] = MySQL::SQLValue($key);
		$result= $db->DeleteRows("tbl_training_facilitators", $filter);

		foreach ($_POST['check_training'] as $key1 => $value1) {
			$split = explode("-", $key1);
			if($split[0] == $key)
			{
								
				$row = array(
					'facilitator_id' => $key,
					'course_id' => $split[1],
					'quarter_id' => $_POST['quarter_id'],
					'attendance' => 1,
					'user_id' => $_SESSION['USER']['ICOLEW_USERID']
					);
				
				$result = dbSaveTable(
					array("table_name" => "tbl_training_facilitators", 
							"table_data" => $row, 
							"primary_field" => "row_id", 
							"primary_data" => "NULL"
						)
					); 
			}
				
	}
	/*foreach ($_POST['check_training'] as $key => $value) {
		$split = explode("-", $key);
		$row = array(
					'facilitator_id' => $split[0],
					'course_id' => $split[1],
					'quarter_id' => $_POST['quarter_id'],
					'attendance' => 1
					); */
		//print_r($row);
		// Save new VSLA contributions to db
		/*$result = dbSaveTable(
					array("table_name" => "tbl_training_facilitators", 
							"table_data" => $row, 
							"primary_field" => "row_id", 
							"primary_data" => "NULL"
						)
					); 

		if($result['success'])
		{
			auditTrail("Added Facilitator training ");
			$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Facilitator training recorded successfully");
			//header("Location: ../cegs/view/".$_POST['ceg_id']);
		}	
		else
		{
			$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding Facilitator training");
			//header("Location: ../cegs/view/".$_POST['ceg_id']);
			die("Error adding adding Facilitator training");
		}*/
	}
	header("Location: ../data-entry/facilitators/1");

	
?>