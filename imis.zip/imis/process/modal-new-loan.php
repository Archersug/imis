<?php
	include("../includes/loader.php");
	//print_r($_POST);
	
	// Save new loan to db
	$result = dbSaveTable(
				array("table_name" => "tbl_vsla_loans", 
						"table_data" => $_POST, 
						"primary_field" => "loan_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added new loan for CEG " . $_POST['ceg_id']);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "New CEG loan successfully added");
		header("Location: ../cegs/view/".$_POST['ceg_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding CEG loan");
		header("Location: ../cegs/view/".$_POST['ceg_id']);
	}

	
?>