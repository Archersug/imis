<?php
	include("../includes/loader.php");

	if(isset($_POST['subcounty_id']))
	    $subcounties = implode(",", $_POST['subcounty_id']);
	else
	    $subcounties = '';

	if(isset($_POST['parish_id']))
	    $parishes = implode(",", $_POST['parish_id']);
	else
	    $parishes = '';

	if(isset($_POST['village_id']))
	    $villages = implode(",", $_POST['village_id']);
	else
	    $villages = '';
	
	if(isset($_POST['clc_id']))
	    $clcs = implode(",", $_POST['clc_id']);
	else
	    $clcs = '';
	
	if(isset($_POST['ceg_id']))    
	    $cegs = implode(",", $_POST['ceg_id']);
	else
	    $cegs = '';

	if($_POST['village_id'])
	{
		foreach($_POST["village_id"] as $vill)
		{
			$row = array(
				'village_id' => $vill,
				'user_id' => $_POST["user_id"]
			);

			$result = dbSaveTable(
				array("table_name" => "tbl_facilitators", 
						"table_data" => $row, 
						"primary_field" => "facilitator_id", 
						"primary_data" => "NULL"
					)
			);
		}
		
	}

	$result = dbDeleteFromTable(
				array("table_name" => "tbl_assigned_locations", 
						"primary_field" => "user_id", 
						"primary_data" => $_POST["user_id"]
					)
				);

	// Format assigned array
	$row = array(
				'user_id' => $_POST["user_id"],
				'cegs' => $cegs,
				'clcs' => $clcs,
				'villages' => $villages,
				'parishes' => $parishes,
				'subcounties' => $subcounties,
				'districts' => $_POST['district_id']
			);
	
	// Save new configuration contributions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_assigned_locations", 
						"table_data" => $row, 
						"primary_field" => "assignment_id", 
						"primary_data" => "NULL"
					)
				); 

	
	if($result['success'])
	{
		auditTrail("Configured assignments for User ID " . $_POST["user_id"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Assignments configured successfully");
		header("Location: ../configure-assignments");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "ERROR! Assigment failed!");
		header("Location: ../configure-assignments");
	}
	
?>