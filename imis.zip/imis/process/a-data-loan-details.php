<?php
	include("../includes/loader.php");

	$db = new MySQL();
	$loanId = $_GET['id'];
	$arrLoan = dbGetLoanDetails($loanId);
	echo json_encode($arrLoan);
?>