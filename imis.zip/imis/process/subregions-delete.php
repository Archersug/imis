<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbDeleteFromTable(
				array("table_name" => "tbl_sub_regions", 
						"primary_field" => "subregion_id", 
						"primary_data" => $_POST["subregion_id"]
					)
				);

	if($result['success'])
	{
		auditTrail("Deleted subregion " . $result['data']["subregion_name"]);
		$_SESSION['ALERT-USER'] = array(
									"type" => "success", 
									"message" => "Subregion '".$result['data']["subregion_name"]."' successfully deleted"
								);
		header("Location: ../subregions");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error deleting subregion '".$result['data']["subregion_name"]."'. " . $result['data']['message']);
		header("Location: ../subregions");
	}

	
?>