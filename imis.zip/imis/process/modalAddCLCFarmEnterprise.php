<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_farm_enterprises", 
						"table_data" => $_POST, 
						"primary_field" => "enterprise_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added CLC Farm Enterprise " . $_POST["enterprise_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CLC Farm Enterprise '".$_POST["enterprise_name"]."' successfully added");
		header("Location: ../manage-enterprises");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding CLC Farm Enterprise'".$_POST["enterprise_name"]."'. " . $result['message']);
		header("Location: ../manage-enterprises");
	}

	
?>