<?php
	include("../includes/loader.php");
	
	// Save new budget to db
	$result = dbSaveTable(
				array("table_name" => "tbl_budgets", 
						"table_data" => $_POST, 
						"primary_field" => "budget_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added budget " . $_POST["budget_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Budget '".$_POST["budget_name"]."' successfully added");
		header("Location: ../budgets");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding budget '".$_POST["budget_name"]."'. " . $result['message']);
		header("Location: ../budgets");
	}

	
?>