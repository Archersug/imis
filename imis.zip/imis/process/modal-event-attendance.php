<?php
	include("../includes/loader.php");

	$result = dbDeleteFromTable(
			array("table_name" => "tbl_event_attendance", 
					"primary_field" => "event_id", 
					"primary_data" => $_POST["event_id"]
				)
			);

	foreach ($_POST['beneficiaries'] as $key => $value) {
		$at = 0;
		if(array_key_exists($key,$_POST['attended']))
			$at = 1;

		$row = array(
					'beneficiary_id' => $key,
					'event_id' => $_POST['event_id'],
					'attended' => $at,
					'reason' => $_POST['reason'][$key]
					);

		// Save attendance to db
		$result = dbSaveTable(
					array("table_name" => "tbl_event_attendance", 
							"table_data" => $row, 
							"primary_field" => "row_id", 
							"primary_data" => "NULL"
						)
					); 

	}
	//header("Location: ../cegs/view/".$_POST['ceg_id']);
	if($result['success'])
	{
		auditTrail("Added event attendance ");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Event attendance successfully added");
		header("Location: ../cegs/view/".$_SESSION['USER']['current_ceg_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding Event attendance");
		header("Location: ../cegs/view/".$_SESSION['USER']['current_ceg_id']);
	} 
	
?>