<?php
	include("../includes/loader.php");
	// Save new usergroups to db
	print_r($_POST);
	
	$db = new MySQL();
	
	foreach ($_POST['facilitator_id'] as $key => $value) {
		$filter['quarter_id'] = MySQL::SQLValue($_POST['quarter_id']);
		//$filter['facilitator_id'] = MySQL::SQLValue($key);
		$result= $db->DeleteRows("tbl_facilitator_remuneration", $filter);		
	}
	foreach ($_POST['facilitator_id'] as $key1 => $value1) {
								
				$row = array(
					'facilitator_id' => $key1,
					'district_id' => $_POST['district_id'],
					'subcounty_id' => $_POST['subcounty_id'],
					'quarter_id' => $_POST['quarter_id'],
					'remuneration_id' => 1,
					'user_id' => $_SESSION['USER']['ICOLEW_USERID']
					);
					print_r($row);
					
				$result = dbSaveTable(
				array("table_name" => "tbl_facilitator_remuneration", 
						"table_data" => $row, 
						"primary_field" => "row_id", 
						"primary_data" => "NULL"
					)
				);
				
		}
	
if($result['success'])
	{
		auditTrail("Added Facilitator renumeration ");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Facilitator Renumeration successfully added");
		header("Location: ../data-entry/facilitators/1");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding Facilitator renumeration'".$_POST["enterprise_name"]."'. ".$result['message']);
		header("Location: ../data-entry/facilitators/1");
	}

	
?>