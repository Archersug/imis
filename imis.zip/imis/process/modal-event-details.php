<?php
	include("../includes/loader.php");
	//print_r($_POST);
	
	// Save new event to db
	$result = dbSaveTable(
				array("table_name" => "tbl_events", 
						"table_data" => $_POST, 
						"primary_field" => "event_id", 
						"primary_data" => $_POST['event_id']
					)
				);

	if($result['success'])
	{

		auditTrail("Edited CEG event '".$_POST['event_name']."'");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CEG event successfully edit");
		header("Location: ../cegs/view/".$_SESSION['USER']['current_ceg_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing CEG event");
		header("Location: ../cegs/view/".$_SESSION['USER']['current_ceg_id']);
	}

	
?>