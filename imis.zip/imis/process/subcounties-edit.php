<?php
  include("../includes/loader.php");
  
  // Save new regions to db
  $result = dbSaveTable(
        array("table_name" => "tbl_subcounties", 
            "table_data" => $_POST, 
            "primary_field" => "subcounty_id", 
            "primary_data" => $_POST['subcounty_id']
          )
        );

  if($result['success'])
  {
    auditTrail("Edited Subcounty " . $_POST["subcounty_name"]);
    $_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Subcounty '".$_POST["subcounty_name"]."' successfully edited");
    header("Location: ../subcounties");
  } 
  else
  {
    $_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing subcounty '".$_POST["constituency_name"]."'. ". $result['message']);
    header("Location: ../subcounties");
  }

  
?>