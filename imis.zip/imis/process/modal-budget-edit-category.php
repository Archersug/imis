<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_budget_categories", 
						"table_data" => $_POST, 
						"primary_field" => "category_id", 
						"primary_data" => $_POST['category_id']
					)
				);

	if($result['success'])
	{
		auditTrail("Edited budget category " . $_POST["category_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Budget category '".$_POST["category_name"]."' successfully edited");
		header("Location: ../budget-categories");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing budget category'".$_POST["category_name"]."'. ". $result['message']);
		header("Location: ../budget-categorie");
	}

	
?>