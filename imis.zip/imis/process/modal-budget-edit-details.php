<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_budget_details", 
						"table_data" => $_POST, 
						"primary_field" => "budget_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added budget item " . $_POST["detail_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Budget item '".$_POST["detail_name"]."' successfully added");
		header("Location: ../budgets/edit/".$_POST['budget_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding budget item'".$_POST["detail_name"]."'. ". $result['message']);
		header("Location: ../budgets/edit/".$_POST['budget_id']);
	}

	
?>