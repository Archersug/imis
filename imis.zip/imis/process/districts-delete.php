<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbDeleteFromTable(
				array("table_name" => "tbl_districts", 
						"primary_field" => "district_id", 
						"primary_data" => $_POST["district_id"]
					)
				);

	if($result['success'])
	{
		auditTrail("Deleted district " . $result['data']["district_name"]);
		$_SESSION['ALERT-USER'] = array(
									"type" => "success", 
									"message" => "District '".$result['data']["district_name"]."' successfully deleted"
								);
		header("Location: ../districts");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error deleting district '".$result['data']["district_name"]."'. " . $result['data']['message']);
		header("Location: ../districts");
	}

	
?>