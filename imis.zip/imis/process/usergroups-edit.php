<?php
	include("../includes/loader.php");
	$db = new MySQL;

	if(isset($_POST))
	{
		$today = date("Y-m-d");
		
		//Receive and prepare values for mysql insertion
		$values = array();
		$values["usergroup_name"] = MySQL::SQLValue($_POST['usergroup_name']); 
		
		if(isset($_POST['check_permissions']))
			$permissions = $_POST['check_permissions'];
		
		//START DATABASE TRANSACTION
		$db->TransactionBegin();
		
		// Execute the update 
		$whereArray['usergroup_id'] = MySQL::SQLValue($_POST['hidden_id'],MySQL::SQLVALUE_NUMBER);
		$qUpdate = $db->BuildSQLUpdate("tbl_usergroups",$values,$whereArray);
		if(!$result = $db->Query($qUpdate))
			$db->Error();
		
		//Delete previous permissions 
		$filter["usergroup_id"] = MySQL::SQLValue($_POST['hidden_id'],MySQL::SQLVALUE_NUMBER);
		$db->DeleteRows("tbl_user_permissions", $filter);
		
		//Create permission array to insert into the database
		if(isset($permissions))
		{
			$values2 = array();
			foreach($permissions as $perm)
			{
				$values2["usergroup_id"] = MySQL::SQLValue($_POST['hidden_id'],MySQL::SQLVALUE_NUMBER);
				$values2["item_id"] = $perm;
				
				// Execute the insert for user group permissions
				$result = $db->InsertRow("tbl_user_permissions", $values2);
			}
		}
						
		//Enter audit trail action
		//$AT = "Edited user group '".$values["groupName"]."'";
		//auditTrail($AT);
		
		//END DATABASE TRANSACTION
		$db->TransactionEnd();
		
		$message = "The user group <strong>". $values["usergroup_name"] ."</strong> has been edited.";
		$_SESSION['msg'] = $message;
		header("Location: ../usergroups/edit/".$_POST['hidden_id']);		
	}
?>