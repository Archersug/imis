<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_partners", 
						"table_data" => $_POST, 
						"primary_field" => "partner_id", 
						"primary_data" => $_POST['partner_id']
					)
				);

	if($result['success'])
	{
		auditTrail("Edited Partner " . $_POST["partner_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Partner '".$_POST["partner_name"]."' successfully edited");
		header("Location: ../partners");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing Partner'".$_POST["partner_name"]."'. ". $result['message']);
		header("Location: ../partners");
	}

	
?>