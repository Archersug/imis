<?php
	include("../includes/loader.php");
	$currentQuarter = dbGetCurrentQuarter();

	$result = dbDeleteFromTable(
			array("table_name" => "tbl_clc_users", 
					"primary_field" => "quarter_id", 
					"primary_data" => $currentQuarter[0]["quarter_id"]
				)
			);

	foreach ($_POST['users'] as $key => $value) {

		$row = array(
					'clc_id' => $_POST['clc_id'],
					'service_id' => $key,
					'users' => $value,
					'quarter_id' => $currentQuarter[0]["quarter_id"],
					'user_id' => $_POST['user_id']
					); 


		// Save attendance to db
		$result = dbSaveTable(
					array("table_name" => "tbl_clc_users", 
							"table_data" => $row, 
							"primary_field" => "row_id", 
							"primary_data" => "NULL"
						)
					);

	}
	if($result['success'])
	{
		auditTrail("Updated CLC users for CLC ".$_POST['clc_id']);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CLC users successfully updated");
		header("Location: ../clcs/view/".$_POST['clc_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error updating clc users");
		header("Location: ../clcs/view/".$_POST['clc_id']);
	}
	
?>