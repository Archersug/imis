<?php
	include("../includes/loader.php");

	$target_dir = "../uploads/";
	$target_file = $target_dir . basename($_FILES["data_file"]["name"]);
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

	// Check if image file is a actual image or fake image
	if(isset($_POST["submit"])) {
	  $check = getimagesize($_FILES["data_file"]["tmp_name"]);
	  if($check !== false) {
	    echo "File is an image - " . $check["mime"] . ".";
	    $uploadOk = 1;
	  } else {
	    echo "File is not an image.";
	    $uploadOk = 0;
	  }
	}

	// Check if file already exists
	if (file_exists($target_file)) {
		$_SESSION['ALERT-USER'] = array("type" => "danger", 
							"message" => "Error uploading report '".$_POST["data_title"]."'. File already exists");
		header("Location: ../data-entry/qualitative/1");
	  $uploadOk = 0;
	}

	// Check file size
	if ($_FILES["data_file"]["size"] > 5000000) {
		$_SESSION['ALERT-USER'] = array("type" => "danger", 
							"message" => "Error uploading report '".$_POST["data_title"]."'. File is too large");
		header("Location: ../data-entry/qualitative/1");

	  $uploadOk = 0;
	}

	// Allow certain file formats
	if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	&& $imageFileType != "gif" && $imageFileType != "docx" && $imageFileType != "doc" && $imageFileType != "xls" && $imageFileType != "xlsx") {
	  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
	  $uploadOk = 0;
	}

	// Check if $uploadOk is set to 0 by an error
	if ($uploadOk == 0) {
	  echo "Sorry, your file was not uploaded.";
	// if everything is ok, try to upload file
	} else {
	  if (move_uploaded_file($_FILES["data_file"]["tmp_name"], $target_file)) {
	    // Save new data to db
		$result = dbSaveTable(
					array("table_name" => "tbl_qualitative_data", 
							"table_data" => $_POST, 
							"primary_field" => "data_id", 
							"primary_data" => "NULL"
						)
					);

		// Save file name to db
		$db = new MySQL;
		$values['data_file'] = MySQL::SQLValue(htmlspecialchars( basename( $_FILES["data_file"]["name"])));
		$whereArray['data_id'] = MySQL::SQLValue($result['last_id'],MySQL::SQLVALUE_NUMBER);
		$qUpdate = $db->BuildSQLUpdate("tbl_qualitative_data",$values,$whereArray);
		if(!$result2 = $db->Query($qUpdate))
			$db->Error();

		if($result['success'])
		{
			auditTrail("Added qualitative report '".$_POST['data_title']."'");
			$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Report '".$_POST["data_title"]."' successfully added");
			header("Location: ../data-entry/qualitative/1");
		}	
		else
		{
			$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error uploading report '".$_POST["data_title"]."'.");
			header("Location: ../data-entry/qualitative/1");
		}
	  } 
	  else {
	    echo "Sorry, there was an error uploading your file.";
	  }
	}

	
?>