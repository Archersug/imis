<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_disability_types", 
						"table_data" => $_POST, 
						"primary_field" => "disability_id", 
						"primary_data" => $_POST['disability_id']
					)
				);

	if($result['success'])
	{
		auditTrail("Edited Disability Types" . $_POST["disability_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Disability '".$_POST["disability_name"]."' successfully edited");
		header("Location: ../manage-disabilities");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing Disability'".$_POST["disability_name"]."'. ". $result['message']);
		header("Location: ../manage-disabilities");
	}

	
?>