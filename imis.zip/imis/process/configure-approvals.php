<?php
	include("../includes/loader.php");
	//print_r($_POST);

	$result = dbDeleteFromTable(
				array("table_name" => "tbl_approval_settings", 
						"primary_field" => "level", 
						"primary_data" => $_POST["level"]
					)
				);


	foreach ($_POST['group'] as $key => $value) {
		$row = array(
					'usergroup_id' => $key,
					'level' => $_POST['level'],
				);
		//print_r($row);
		
		// Save new configuration contributions to db
		$result = dbSaveTable(
					array("table_name" => "tbl_approval_settings", 
							"table_data" => $row, 
							"primary_field" => "row_id", 
							"primary_data" => "NULL"
						)
					); 

	}
	if($result['success'])
	{
		auditTrail("Configured data approval ");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Approvals configured successfully");
		header("Location: ../configure-approvals");
	}
	
?>