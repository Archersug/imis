<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_districts", 
						"table_data" => $_POST, 
						"primary_field" => "district_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added district " . $_POST["subregion_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "District '".$_POST["district_name"]."' successfully added");
		header("Location: ../districts");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding district '".$_POST["district_name"]."'. " . $result['message']);
		header("Location: ../districts");
	}

	
?>