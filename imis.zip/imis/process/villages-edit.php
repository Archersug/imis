<?php
	include("../includes/loader.php");

	//print_r($_POST);
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_villages", 
						"table_data" => $_POST, 
						"primary_field" => "village_id", 
						"primary_data" => $_POST['village_id']
					)
				);

	if($result['success'])
	{
		auditTrail("Edited Village " . $_POST["village_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Village '".$_POST["village_name"]."' successfully edited");
		header("Location: ../villages");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing village '".$_POST["village_name"]."'. ". $result['message']);
		header("Location: ../villages");
	}

	
?>