<?php
	include("../includes/loader.php");

	//print_r($_POST);
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_parishes", 
						"table_data" => $_POST, 
						"primary_field" => "parish_id", 
						"primary_data" => $_POST['parish_id']
					)
				);

	if($result['success'])
	{
		auditTrail("Added Parish " . $_POST["parish_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Parish '".$_POST["parish_name"]."' successfully edited");
		header("Location: ../parishes");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding Parish '".$_POST["parish_name"]."'. ". $result['message']);
		header("Location: ../parishes");
	}

	
?>