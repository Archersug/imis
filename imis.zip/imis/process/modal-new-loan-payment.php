<?php
	include("../includes/loader.php");
	//print_r($_POST);
	
	// Save new loan to db
	$result = dbSaveTable(
				array("table_name" => "tbl_vsla_loan_payments", 
						"table_data" => $_POST, 
						"primary_field" => "payment_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added new loan payment for loan " . $_POST['loan_id']);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "New loan payment successfully added");
		header("Location: ../cegs/view/".$_SESSION['USER']['current_ceg_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding CEG loan payment");
		header("Location: ../cegs/view/".$_SESSION['USER']['current_ceg_id']);
	}

	
?>