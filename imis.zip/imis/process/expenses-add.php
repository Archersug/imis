<?php
	include("../includes/loader.php");
	
	// Save new expense to db
	$result = dbSaveTable(
				array("table_name" => "tbl_expenses", 
						"table_data" => $_POST, 
						"primary_field" => "expense_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added expense " . $_POST["expense_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Expense '".$_POST["expense_name"]."' successfully added");
		header("Location: ../expenses");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding expense '".$_POST["expense_name"]."'. " . $result['message']);
		header("Location: ../expenses");
	}

	
?>