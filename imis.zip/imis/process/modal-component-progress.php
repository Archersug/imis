<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_component_progress", 
						"table_data" => $_POST, 
						"primary_field" => "progress_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added Component progress ");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Component progress successfully added");
		header("Location: ../cegs/view/".$_POST['ceg_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding Component progress");
		header("Location: ../cegs/view/".$_POST['ceg_id']);
	}

	
?>