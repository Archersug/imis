<?php
	include("../includes/loader.php");
	$db = new MySQL();
	$id = $_GET['id'];
  $item = $_GET['item'];
  $arrResult = array();
  $idField = '';

  switch($item)
  {
    case "sel-subregions":
      $arrResult = dbGetAllSubRegions($id);
      $idField = "subregion_id";
      $nameField = "subregion_name";
      break;

    case "sel-districts":
      $arrResult = dbGetAllDistricts($id);
      $idField = "district_id";
      $nameField = "district_name";
      break;

    case "sel-counties":
      $arrResult = dbGetAllCounties($id);
      $idField = "constituency_id";
      $nameField = "constituency_name";
      break;

    case "sel-subcounties":
      $arrResult = dbGetDistrictSubCounties($id);
      $idField = "subcounty_id";
      $nameField = "subcounty_name";
      break;

    case "sel-parishes":
      $arrResult = dbGetAllParishes($id);
      $idField = "parish_id";
      $nameField = "parish_name";
      break;

    case "sel-villages":
      $arrResult = dbGetAllVillages($id);
      $idField = "village_id";
      $nameField = "village_name";
      break;

    case "check-villages":
      $arrResult = dbGetAllSubcountyVillages($id);
      $idField = "village_id";
      $nameField = "village_name";
      break;

    case "check-subcounty-locations":
      $arrResult = dbGetAllSubcountyLocations($id);
      $idField = "village_id";
      $nameField = "village_name";
      break;

    case "check-facilitators":
      $options = array('subcounty_id' => $id);
      $arrResult = dbGetAllFacilitators($options);
      $idField = "facilitator_id";
      $nameField = "fullname";
      break;
	  
	case "check-facilitators-equipment":
      $options = array('subcounty_id' => $id);
      $arrResult = dbGetAllFacilitators($options);
      $idField = "facilitator_id";
      $nameField = "fullname";
      break;

    case "facilitator-training":
      $options = array('subcounty_id' => $id);
      $arrResult = dbGetAllFacilitatorsTrained($options);
      $idField = "facilitator_id";
      $nameField = "fullname";
      break;

    case "clc-establishment":
      $options = array('subcounty_id' => $id);
      $arrResult = dbGetCLCs($options);
      $idField = "clc_id";
      $nameField = "clc_name";
      break;

    case "clc-coordinator-training":
      $options = array('subcounty_id' => $id);
      $arrResult = dbGetCLCCoordinatorsTraining($options);
      $idField = "coordinator_id";
      $nameField = "fullname";
      break;

    case "sel-component-units":
      $arrResult = dbGetComponentUnits($id);
      $idField = "unit_id";
      $nameField = "unit_name";
      break;

    case "budget-category":
      $options['category_id'] = $id;
      $arrResult = dbGetBudgetCategories($options);
      $idField = "category_id";
      $nameField = "category_name";
      break;
	  
    case "user-assignments":
      $arrResult = dbGetUserAssignments($id);
      $idField = "user_id";
      $nameField = "fullname";
      break;
	  
	  //---------aDDED by Achilley Kiwanuka
	  
	  case "beneficiary-category":
      $options['category_id'] = $id;
      $arrResult = dbGetBeneficiaryCategories($options);
      $idField = "category_id";
      $nameField = "category_name";
	  //$category_abbr = "category_abbr";
      break;
	  case "partners":
      $options['partner_id'] = $id;
      $arrResult = dbGetCLCPartners($options);
      $idField = "partner_id";
      $nameField = "partner_name";
      break;
	  case "ceg-activity":
      $options['activity_id'] = $id;
      $arrResult = dbGetSetupActvities($options);
      $idField = "activity_id";
      $nameField = "activity_name";
      break;
	  case "clc-activity":
      $options['service_id'] = $id;
      $arrResult = dbGetCLCActvities($options);
      $idField = "service_id";
      $nameField = "service_name";
      break;
	  
	  case "clc-thematicarea":
      $options['thematic_id'] = $id;
      $arrResult = dbGetCLCThematicArea($options);
      $idField = "thematic_id";
      $nameField = "thematic_name";
      break;
	  case "manage-disabilities":
      $options['disability_id'] = $id;
      $arrResult = dbGetDisabilities($options);
      $idField = "disability_id";
      $nameField = "disability_name";
      break;
	  
	  //
	  case "FarmEnterprise":
      $options['enterprise_id'] = $id;
      $arrResult = dbGetCEGFarmEnterprises($options);
      $idField = "enterprise_id";
      $nameField = "enterprise_name";
      break;
	  //-------edit Components
	   case "components":
      $options['component_id'] = $id;
      $arrResult = dbGetComponents($options);
      $idField = "component_id";
      $nameField = "component_name";
	  //$nameField = "component_abbrev";
      break;
	  //---------End Added by Achilley Kiwanuka

    default:
      break;
  }

  if($arrResult)
  {
    echo json_encode(array("id" => $idField, "name" => $nameField, "results" => $arrResult));
  }
  else
  {
    echo json_encode(array());
  }

	// $arrSubRegions = dbGetAllSubRegions($regionId);
	// if($arrSubRegions)
 //  		echo json_encode($arrSubRegions);
 //  	else
 //  	{
 //  		$arrSubRegions = array(array("subregion_id" => '',
 //  									 "subregion_name" => "No Match Found")
 //  						);
 //  		echo json_encode($arrRegions);
 //  	}
?>