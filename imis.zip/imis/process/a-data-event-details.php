<?php
	include("../includes/loader.php");

	$db = new MySQL();
	$eventId = $_GET['id'];
	$arrEvent = dbGetEventDetails($eventId);
	echo json_encode($arrEvent);
?>