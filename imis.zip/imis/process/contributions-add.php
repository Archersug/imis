<?php
	include("../includes/loader.php");
	
	// Save new contribution to db
	$result = dbSaveTable(
				array("table_name" => "tbl_contributions", 
						"table_data" => $_POST, 
						"primary_field" => "contribution_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added contribution " . $_POST["contribution_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Budget '".$_POST["contribution_name"]."' successfully added");
		header("Location: ../contributions");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding contribution '".$_POST["contribution_name"]."'. " . $result['message']);
		header("Location: ../contributions");
	}

	
?>