<?php
	include("../includes/loader.php");
	
	// Delete budget detail
	$detailId = $_GET['item'];
	$budgetId = $_GET['budget'];

	$result = dbDeleteFromTable(
				array("table_name" => "tbl_budget_details", 
						"primary_field" => "detail_id", 
						"primary_data" => $detailId
					)
				);

	if($result['success'])
	{
		auditTrail("Deleted budget item " . $result['data']["detail_name"]);
		$_SESSION['ALERT-USER'] = array(
									"type" => "success", 
									"message" => "Budget item '".$result['data']["detail_name"]."' successfully deleted"
								);
		header("Location: ../budgets/edit/$budgetId");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error budget item '".$result['data']["detail_name"]."'. " . $result['data']['message']);
		header("Location: ../budgets/edit/$budgetId");
	}

	
?>