<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_clcs", 
						"table_data" => $_POST, 
						"primary_field" => "clc_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added CLC " . $_POST["clc_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CLC '".$_POST["clc_name"]."' successfully added");
		header("Location: ../clcs");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding clc '".$_POST["clc_name"]."'. " . $result['message']);
		header("Location: ../clcs");
	}

	
?>