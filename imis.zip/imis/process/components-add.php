<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_components", 
						"table_data" => $_POST, 
						"primary_field" => "component_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added Component " . $_POST["component_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Component '".$_POST["component_name"]."' successfully added");
		header("Location: ../components");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding Component'".$_POST["component_name"]."'. " . $result['message']);
		header("Location: ../components");
	}

	
?>