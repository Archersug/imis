<?php
	include("../includes/loader.php");
	//print_r($_POST);
	
	$db = new MySQL;

	$values = array(
				'level1' => MySQL::SQLValue($_SESSION['USER']['ICOLEW_USERID'])
			);

	// Get records
	$qRecs = "SELECT tbl_training_facilitators.row_id 
			FROM tbl_training_facilitators 
			LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_training_facilitators.facilitator_id 
			LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
			LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
			LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
			WHERE tbl_subcounties.subcounty_id = '".$_GET['subcounty']."'";
	$arrRecs = $db->QueryArray($qRecs, MYSQLI_ASSOC);

	foreach($arrRecs as $rec)
	{
		// Execute the update 
		$whereArray['row_id'] = MySQL::SQLValue($rec['row_id'],MySQL::SQLVALUE_NUMBER);
		$qUpdate = $db->BuildSQLUpdate("tbl_training_facilitators",$values,$whereArray);
		$db->Query($qUpdate);

		if($db->Error())
		die("Approval error: " . $db->Error());
	}

	auditTrail("Approved data for Level1 '");
	$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Data successfully approved");
	header("Location: ../approve/facilitators-trained-1/1");
?>