<?php
	include("../includes/loader.php");
	
	// Save new expense item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_expense_details", 
						"table_data" => $_POST, 
						"primary_field" => "expense_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added expense item " . $_POST["detail_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Expense item '".$_POST["detail_name"]."' successfully added");
		header("Location: ../expenses/edit/".$_POST['expense_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding expense item'".$_POST["detail_name"]."'.");
		header("Location: ../expenses/edit/".$_POST['expense_id']);
	}

	
?>