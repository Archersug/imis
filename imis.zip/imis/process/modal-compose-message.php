<?php
	include("../includes/loader.php");
	//print_r($_POST);
	
	// Save new message item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_inbox_messages", 
						"table_data" => $_POST, 
						"primary_field" => "message_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Sent a message ");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Message sent successfully");
		header("Location: ../inbox");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding budget category'".$_POST["category_name"]."'.");
		header("Location: ../budget-categorie");
	}

	
?>