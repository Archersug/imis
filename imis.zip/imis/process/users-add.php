<?php
	include("../includes/loader.php");
	// Save new usergroups to db

	$result = dbSaveTable(
				array("table_name" => "tbl_users", 
						"table_data" => $_POST, 
						"primary_field" => "user_id", 
						"primary_data" => "NULL"
					)
				);

	/*if($result)
	{
		auditTrail("Added user " . $_POST["fullname"]);
		header("Location: ../users");
	}
*/
if($result['success'])
	{
		auditTrail("Added user " . $_POST["fullname"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "User '".$_POST["fullname"]."' successfully Added");
		header("Location: ../users");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error Adding User '".$_POST["fullname"]."'. ". $result['message']);
		header("Location: ../users");
	}

	
?>