<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_clc_thematicarea", 
						"table_data" => $_POST, 
						"primary_field" => "thematic_id", 
						"primary_data" => $_POST['thematic_id']
					)
				);

	if($result['success'])
	{
		auditTrail("Edited CLC Thematic Area " . $_POST["thematic_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CLC Thematic Area '".$_POST["thematic_name"]."' successfully edited");
		header("Location: ../clc-thematicarea");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing CLC Thematic'".$_POST["service_name"]."'. ". $result['message']);
		header("Location: ../clc-thematicarea");
	}

	
?>