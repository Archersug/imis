<?php
	include("../includes/loader.php");
	
	// Save new Partner item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_partners", 
						"table_data" => $_POST, 
						"primary_field" => "partner_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added Beneficiary Category " . $_POST["partner_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Partner '".$_POST["partner_name"]."' successfully added");
		header("Location: ../partners");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding Partners'".$_POST["category_name"]."'. ". $result['message']);
		header("Location: ../partners");
	}

	
?>