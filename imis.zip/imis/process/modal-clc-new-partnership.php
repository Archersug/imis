<?php
	include("../includes/loader.php");
	//print_r($_POST);
	
	// Save new event to db
	$result = dbSaveTable(
				array("table_name" => "tbl_clc_partnerships", 
						"table_data" => $_POST, 
						"primary_field" => "partnership_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{

		auditTrail("Added new CLC partnership event '".$_POST['partnership_name']."'");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CLC partnership successfully added");
		header("Location: ../clcs/view/".$_POST['clc_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing CEG event");
		header("Location: ../clcs/view/".$_POST['clc_id']);
	}

	
?>