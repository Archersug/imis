<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_disability_types", 
						"table_data" => $_POST, 
						"primary_field" => "disability_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added disability " . $_POST["disbility_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Disability '".$_POST["disability_name"]."' successfully added");
		header("Location: ../manage-disabilities");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding disability'".$_POST["disbility_name"]."'. ". $result['message']);
		header("Location: ../manage-disabilities");
	}

	
?>