<?php
	include("../includes/loader.php");

	$db = new MySQL();
	$id = $_GET['id'];
	$table = $_GET['table'];
	$field = $_GET['field'];

	$arrItem = dbGetTableItem($table, $field, $id);
	echo json_encode($arrItem);
?>