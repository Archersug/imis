<?php
	include("../includes/loader.php");
	// Save new usergroups to db

	$result = dbSaveTable(
				array("table_name" => "tbl_users", 
						"table_data" => $_POST, 
						"primary_field" => "user_id", 
						"primary_data" => "NULL"
					)
				);

	if($result)
	{
		auditTrail("Added user " . $_POST["fullname"]);
		header("Location: ../users");
	}

	
?>