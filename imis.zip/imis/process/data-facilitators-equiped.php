<?php
	include("../includes/loader.php");
	//print_r($_POST);

	$db = new MySQL();


	foreach ($_POST['facilitator_id'] as $key => $value) {
		$filter['quarter_id'] = MySQL::SQLValue($_POST['quarter_id']);
		$filter['facilitator_id'] = MySQL::SQLValue($key);
		$result= $db->DeleteRows("tbl_training_facilitators", $filter);

		foreach ($_POST['check_training'] as $key1 => $value1) {
			$split = explode("-", $key1);
			if($split[0] == $key)
			{
								
				$row = array(
					'facilitator_id' => $key,
					'course_id' => $split[1],
					'quarter_id' => $_POST['quarter_id'],
					'attendance' => 1,
					'user_id' => $_SESSION['USER']['ICOLEW_USERID']
					);
				
				/*$result = dbSaveTable(
					array("table_name" => "tbl_training_facilitators", 
							"table_data" => $row, 
							"primary_field" => "row_id", 
							"primary_data" => "NULL"
						)
					);  */
			}
				
	}

	}
	header("Location: ../data-entry/facilitators/1");

	
?>