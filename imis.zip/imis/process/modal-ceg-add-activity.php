<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_activities", 
						"table_data" => $_POST, 
						"primary_field" => "activity_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added CEG Activity " . $_POST["activity_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CLC Service '".$_POST["activity_name"]."' successfully added");
		header("Location: ../ceg-activity");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding CEG Activity'".$_POST["activity_name"]."'. ". $result['message']);
		header("Location: ../ceg-activity");
	}

	
?>