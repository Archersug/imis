<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_regions", 
						"table_data" => $_POST, 
						"primary_field" => "region_id", 
						"primary_data" => "NULL"
					)
				);

	/*if($result)
	{
		auditTrail("Added region " . $_POST["region_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Region '".$_POST["region_name"]."' successfully added");
		header("Location: ../regions");
	}*/

if($result['success'])
	{
		auditTrail("Added region " . $_POST["region_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Region '".$_POST["region_name"]."' successfully Added");
		header("Location: ../regions");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error Adding region '".$_POST["region_name"]."'. ". $result['message']);
		header("Location: ../regions");
	}

	
?>