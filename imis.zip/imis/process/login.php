<?php
    //session_start();
    include("../includes/loader.php");

    $user = new User();

    if($_POST['email'] && $_POST['password'])
    {
        $status = $user->login($_POST['email'], $_POST['password']);
        if($status['SUCCESS'])
        {
            auditTrail("Logged in");
            //header("Location: " . $_SESSION['LAST_REQUEST_URI']);
            header("Location: ../dashboard");
        }
        else
        {
            $_SESSION['loginMessage'] = $status['MESSAGE'];
            header("Location: ../");
        }
    }
    else
    {
        $_SESSION['loginMessage'] = "Please enter a valid email address and password";
        header("Location: ../");
    }
?>