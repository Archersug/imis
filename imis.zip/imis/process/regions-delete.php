<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbDeleteFromTable(
				array("table_name" => "tbl_regions", 
						"primary_field" => "region_id", 
						"primary_data" => $_POST["region_id"]
					)
				);

	if($result['success'])
	{
		auditTrail("Deleted region " . $result['data']["region_name"]);
		$_SESSION['ALERT-USER'] = array(
									"type" => "success", 
									"message" => "Region '".$result['data']["region_name"]."' successfully deleted"
								);
		header("Location: ../regions");
	}
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error deleting region '".$result['data']["region_name"]."'. " . $result['data']['message']);
		header("Location: ../regions");
	}

	
?>