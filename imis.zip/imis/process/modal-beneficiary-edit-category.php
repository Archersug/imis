<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_beneficiary_categories", 
						"table_data" => $_POST, 
						"primary_field" => "category_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Edited Beneficiary Category " . $_POST["category_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Beneficiary Category '".$_POST["category_name"]."' successfully added");
		header("Location: ../beneficiary-categories");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error Editing Beneficiary Category'".$_POST["category_name"]."'. ". $result['message']);
		header("Location: ../beneficiary-categories");
	}

	
?>