<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_sub_regions", 
						"table_data" => $_POST, 
						"primary_field" => "subregion_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added subregion " . $_POST["subregion_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Subregion '".$_POST["subregion_name"]."' successfully added");
		header("Location: ../subregions");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding subregion '".$_POST["subregion_name"]."'. ". $result['message']);
		header("Location: ../subregions");
	}

	
?>