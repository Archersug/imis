<?php
	include("../includes/loader.php");
	
	// Save new regions to db
	$result = dbSaveTable(
				array("table_name" => "tbl_clc_services_offered", 
						"table_data" => $_POST, 
						"primary_field" => "row_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added CLC service");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CLC service successfully added");
		header("Location: ../clcs/view/".$_POST['clc_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding CLC service");
		header("Location: ../clcs/view/".$_POST['clc_id']);
	}

	
?>