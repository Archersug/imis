<?php
	include("../includes/loader.php");

	print_r($_POST);
	
	// Save project settings to db
	$result = dbSaveTable(
				array("table_name" => "tbl_project_settings", 
						"table_data" => $_POST, 
						"primary_field" => "setting_name", 
						"primary_data" => MySQL::SQLValue($_POST['setting_name'])
					)
				);

	if($result)
	{
		auditTrail("Updated default presets for " . $_POST["setting_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Updated default presets for '".$_POST["setting_name"]."' successfully");
		header("Location: ../default-presets");
	}

	
?>