<?php
	include("../includes/loader.php");
	
	// Save new contribution category to db
	$result = dbSaveTable(
				array("table_name" => "tbl_contribution_categories", 
						"table_data" => $_POST, 
						"primary_field" => "category_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added contribution category " . $_POST["category_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Contribution category '".$_POST["category_name"]."' successfully added");
		header("Location: ../contribution-categories");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding contribution category'".$_POST["category_name"]."'. ". $result['message']);
		header("Location: ../contribution-categorie");
	}

	
?>