<?php
	include("../includes/loader.php");
	//print_r($_POST);
	
	// Save new event to db
	$result = dbSaveTable(
				array("table_name" => "tbl_events", 
						"table_data" => $_POST, 
						"primary_field" => "event_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		// retrieve CEG beneficiaries
		$options = array("ceg_id" => $_SESSION['USER']['current_ceg_id']);
		$arrBens = dbGetBeneficiaries($options);

		$row = array(
					"ceg_id" => $_SESSION['USER']['current_ceg_id'],
					"event_id" => $result['last_id']
				);
		// Attach saved event ID to CEG
		$result1 = dbSaveTable(
				array("table_name" => "tbl_ceg_events", 
						"table_data" => $row, 
						"primary_field" => "row_id", 
						"primary_data" => "NULL"
					)
				);

		// Insert default attendance to newly created CEG
		foreach($arrBens as $ben)
		{
			$row = array(
					"event_id" => $result1['last_id'],
					"beneficiary_id" => $ben['beneficiary_id'],
					"attended" => "1"
						);
			$result2 = dbSaveTable(
				array("table_name" => "tbl_event_attendance", 
						"table_data" => $row, 
						"primary_field" => "row_id", 
						"primary_data" => "NULL"
					)
				);
		}

		auditTrail("Added new CEG event '".$_POST['event_name']."'");
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CEG event successfully added");
		header("Location: ../cegs/view/".$_SESSION['USER']['current_ceg_id']);
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding CEG event");
		header("Location: ../cegs/view/".$_SESSION['USER']['current_ceg_id']);
	}

	
?>