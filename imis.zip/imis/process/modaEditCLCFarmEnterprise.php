<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_farm_enterprises", 
						"table_data" => $_POST, 
						"primary_field" => "enterprise_id", 
						"primary_data" => $_POST['enterprise_id']
					)
				);

	if($result['success'])
	{
		auditTrail("Edited Farm Enterprise" . $_POST["enterprise_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "Farm Enterprise '".$_POST["enterprise_name"]."' successfully edited");
		header("Location: ../manage-enterprises");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error editing Farm Enterprise'".$_POST["service_name"]."'. " . $result['message']);
		header("Location: ../manage-enterprises");
	}

	
?>