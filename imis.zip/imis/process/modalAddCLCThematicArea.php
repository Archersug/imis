<?php
	include("../includes/loader.php");
	
	// Save new budget item to db
	$result = dbSaveTable(
				array("table_name" => "tbl_clc_thematicarea", 
						"table_data" => $_POST, 
						"primary_field" => "thematic_id", 
						"primary_data" => "NULL"
					)
				);

	if($result['success'])
	{
		auditTrail("Added CLC Thematic Area" . $_POST["thematic_name"]);
		$_SESSION['ALERT-USER'] = array("type" => "success", "message" => "CLC Thematic area '".$_POST["thematic_name"]."' successfully added");
		header("Location: ../clc-thematicarea");
	}	
	else
	{
		$_SESSION['ALERT-USER'] = array("type" => "danger", "message" => "Error adding CLC Activity'".$_POST["service_name"]."'. " . $result['message']);
		header("Location: ../clc-thematicarea");
	}

	
?>