<?php
    // Retrieve all menu sections from db
    $arrMenuSections = dbGetMenuSections();

    // Retrieve all menu categories from db
    $arrCats = dbGetMenuCategories();

    // Retrieve menu items from db
    $arrMenuItems = dbGetMenuItems();
    //print_r($arrMenuItems);

    // Retrieve menu permissions for logged in group
    $arrPerms = dbGetMenuPermissions($_SESSION['USER']['USERGROUPID']);
    //print_r($arrPerms);
    $arrPermittedPages = array();
    //print_r($arrPermissions);
    if(!empty($arrPerms))
    {
      foreach($arrPerms as $perm)
      {
         $arrPermittedPages[] = $perm;
      }
    }

    //-----------------------------------------------------
    //Retrieve permissions for current user group
    $qPerm = "SELECT tbl_user_permissions.*, tbl_menu_items.item_category, 
                tbl_menu_items.item_link, tbl_menu_categories.section_id
              FROM tbl_user_permissions 
              LEFT JOIN tbl_menu_items ON tbl_menu_items.item_id = tbl_user_permissions.item_id
              LEFT JOIN tbl_menu_categories ON tbl_menu_categories.cat_id = tbl_menu_items.item_category
              WHERE tbl_user_permissions.usergroup_id = '".$_SESSION['USER']['USERGROUPID']."'";

    $arrPerm = $db->QueryArray($qPerm);
    $numPermRows = $db->RowCount();
    $hasPerms = 0;
    if($numPermRows)
      $hasPerms = $numPermRows;

     //Determine the menu categories to show
    $hasCats = array();
    $hasSecs = array();
    if($numPermRows > 0)
    {
      foreach($arrPerm as $p)
      {
        $hasCats[] = $p['item_category'];
        $hasSecs[] = $p['section_id'];
      }
    }

    // Determine seciont to show
    $hasSections = [];
    foreach($arrMenuSections as $sec)
    {
      if(in_array($sec['section_id'], $hasSecs))
        $hasSections[] = $sec['section_id'];
    }

?>
<ul class="nav nav-aside">
  <li class="nav-label">Dashboard</li>
  <li class="nav-item<?php echo ($displayedPage['category'] == 'OVERSIGHT')? ' active':'';?>"><a href="<?php echo $ROOT_FOLDER;?>dashboard" class="nav-link"><i data-feather="shopping-bag"></i> <span>Oversight</span></a></li>
  <?php
    if($_SESSION['USER']['USERGROUPID'] < 2)
    {
  ?>
  
  <!-- <li class="nav-item"><a href="<?php echo $ROOT_FOLDER;?>dashboard" class="nav-link"><i data-feather="globe"></i> <span>Operations</span></a></li> -->
  <li class="nav-item<?php echo ($displayedPage['category'] == 'MNE')? ' active':'';?>"><a href="<?php echo $ROOT_FOLDER;?>dashboard-mne" class="nav-link"><i data-feather="pie-chart"></i> <span>M & E</span></a></li>
  <li class="nav-item<?php echo ($displayedPage['category'] == 'TECHNICAL')? ' active':'';?>"><a href="<?php echo $ROOT_FOLDER;?>dashboard-technical" class="nav-link"><i data-feather="life-buoy"></i> <span>Technical</span></a></li>
  <?php
    }
  ?>

  <?php
    foreach($arrMenuSections as $section)
    {
      if(in_array($section['section_id'],$hasSections))
      {
    ?>
      <li class="nav-label mg-t-25"><?php echo $section['section_name'];?></li>
      <?php
        foreach($arrCats as $cat)
        {
          if(in_array($cat['cat_id'],$hasCats))
          {
            if($cat['section_id'] == $section['section_id'])
            {
            ?>
            <li class="nav-item with-sub<?php echo ($displayedPage['category'] == $cat['cat_name'])? ' active show':'';?>">
              <a href="" class="nav-link">
                <i data-feather="<?php echo $cat['cat_icon'];?>"></i> 
                <span><?php echo $cat['cat_name'];?></span>
              </a>
              <ul>
                <?php
                  foreach($arrMenuItems as $item)
                  {
                    if(in_array($item['item_id'], $arrPerms) && $item['item_category'] == $cat['cat_id'])
                    {
                ?>
                  <li <?php echo ($item['item_link'] == $displayedPage['link'])? 'class="active"':'';?>>
                  <a href="<?php echo $ROOT_FOLDER . $item['item_link'];?>">
                    <?php echo $item['item_name'];?>
                    </a>
                  </li>
                <?php
                    }
                  }
                ?>
              </ul>
            </li>
          <?php
            }
          }
        }
      }
    }
  ?>
</ul>