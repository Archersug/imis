<?php
	/**
	 * Page router class to handle navigation in the app
	 */
	class Router
	{
		private $pageDirectory = "app-pages";
		private $arrPages = array(
						'dashboard' => array(
										'file' => 'dashboard.php', 
										'heading' => 'Dashboard',
										'category' => 'OVERSIGHT',
									),
						'api-configure' => array(
										'file' => 'api.php', 
										'heading' => 'Dashboard',
										'category' => 'System',
									),
						'dashboard-mne' => array(
										'file' => 'dashboard-mne.php', 
										'heading' => 'Dashboard',
										'category' => 'MNE',
									),
						'dashboard-technical' => array(
										'file' => 'dashboard-technical.php', 
										'heading' => 'Dashboard',
										'category' => 'TECHNICAL',
									),

						'audit-trail' => array(
										'file' => 'audit-trail.php', 
										'heading' => 'Faciitators Trained',
										'category' => 'System',
									),
						'configure-approvals' => array(
										'file' => 'configure-approvals.php', 
										'heading' => 'Faciitators Trained',
										'category' => 'Project Settings',
									),
						'inbox' => array(
										'file' => 'inbox.php', 
										'heading' => 'Faciitators Trained',
										'category' => 'Inbox',
										'subs' => array(
														'view' => array(
																	'file' => 'inbox-view.php', 
																	'heading' => 'Add New',
																	'category' => '',
														),
													)
									),

						'configure-assignments' => array(
										'file' => 'configure-assignments.php', 
										'heading' => 'Faciitators Trained',
										'category' => 'Project Settings',
									),
						'default-presets' => array(
										'file' => 'default-presets.php', 
										'heading' => 'Faciitators Trained',
										'category' => 'Project Settings',
									),
						'reporting-periods' => array(
										'file' => 'reporting-periods.php', 
										'heading' => 'Faciitators Trained',
										'category' => 'Project Settings',
									),
						'manage-facilitators' => array(
										'file' => 'manage-facilitators.php', 
										'heading' => 'Manage Facilitators',
										'category' => 'Project Settings',
									),
						'manage-disabilities' => array(
										'file' => 'manage-disabilities.php', 
										'heading' => 'Manage Facilitators',
										'category' => 'Project Settings',
									),
						//-------------Added by-Achilley Kiwanuka 19 march 2021------------
						'clc-activities' => array('file' => 'clc-activities.php', 
													'heading' => 'Manage CLC Activities',
													'category' => 'Project Settings',
																					),														
						'clc-thematicarea' => array('file' => 'clc-thematicarea.php', 
													'heading' => 'Manage CLC Thematic Areas',
													'category' => 'Project Settings',
																					),
						'partners' => array('file' => 'partners.php', 
													'heading' => 'Partners',
													'category' => 'Project Settings',),
													
						'manage-enterprises' => array('file' => 'manage-enterprises.php', 
													'heading' => 'Manage Enterprises',
													'category' => 'Project Settings',),
						'ceg-activity' => array('file' => 'ceg-activity.php', 
													'heading' => 'CEG Activity',
													'category' => 'Project Settings',),	
						'beneficiary-categories' => array(
										'file' => 'beneficiary-categories.php',
										'heading' => 'Beneficiary Categories',
										'category' => 'Beneficiaries',
										
										
									),
													
							/*
							
						'beneficiary-categories' => array(
										'file' => 'beneficiary-categories.php', 
										'category' => 'Beneficiaries',
										'heading' => 'Beneficiary Categories',
										'subs' => array(
														'add' => array(
																	'file' => 'beneficiary_categories-add.php', 
																	'heading' => 'Add New Beneficiary Category',
																	'category' => 'Beneficiaries',
														),
														'edit' => array(
															'file' => 'beneficiary_categories-edit.php', 
															'heading' => 'Edit Beneficiary Category',
															'category' => 'Beneficiaries',
														),
														'delete' => array(
																	'file' => 'beneficiary_categories-delete.php', 
																	'heading' => 'Delete Beneficiary Category',
																	'category' => 'Beneficiaries',
														)
												)
									),
									*/
							
											
																					
						//-------------End of Achilley Kiwanuka Ssebwana-------------

						'components' => array(
										'file' => 'components.php', 
										'category' => 'Components',
										'heading' => 'List of Regions',
										'subs' => array(
														'add' => array(
																	'file' => 'components-add.php', 
																	'heading' => 'Add New ReComponentgion',
																	'category' => 'Components',
														),
														'edit' => array(
															'file' => 'components-edit.php', 
															'heading' => 'Edit Component',
															'category' => 'Components',
														),
														'delete' => array(
																	'file' => 'components-delete.php', 
																	'heading' => 'Delete Component',
																	'category' => 'Components',
														),
														
														'view' => array(
																	'file' => 'components-view.php', 
																	'heading' => 'Delete Component',
																	'category' => 'Components',
														)
												)
									),
						'approve' => array(
										'file' => '', 
										'category' => 'Components',
										'heading' => 'List of Regions',
										'subs' => array(
														'facilitators-trained-1' => array(
																	'file' => 'approve-data-facilitators-trained-1.php', 
																	'heading' => '',
																	'category' => 'Level 1',
														),
														'facilitators-trained-2' => array(
																	'file' => 'approve-data-facilitators-trained-2.php', 
																	'heading' => '',
																	'category' => 'Level 2',
														),
														'facilitators-trained-3' => array(
																	'file' => 'approve-data-facilitators-trained-3.php', 
																	'heading' => '',
																	'category' => 'Level 3',
														),
												)
									),
						'beneficiaries' => array(
										'file' => 'beneficiaries.php', 
										'category' => 'Beneficiaries',
										'heading' => 'List of Beneficiaries',
										'subs' => array(
														'add' => array(
																	'file' => 'beneficiaries-add.php', 
																	'heading' => 'Add New Beneficiary',
																	'category' => 'Beneficiaries',
														),
														'edit' => array(
															'file' => 'beneficiaries-edit.php', 
															'heading' => 'Edit Beneficiaries',
															'category' => 'Beneficiaries',
														),
														'delete' => array(
																	'file' => 'beneficiaries-delete.php', 
																	'heading' => 'Delete Beneficiary',
																	'category' => 'Beneficiaries',
														),
														'view' => array(
																	'file' => 'beneficiaries-profile.php', 
																	'heading' => 'Delete Beneficiary',
																	'category' => 'Beneficiaries',
														)
												)
									),
						'cegs' => array(
										'file' => 'cegs.php', 
										'category' => 'CEG Profiles',
										'heading' => 'List of CEGs',
										'subs' => array(
														'view' => array(
																	'file' => 'cegs-profile.php', 
																	'heading' => 'CEG Profile',
																	'category' => 'CEG Profiles',
														),
														'add' => array(
																	'file' => 'cegs-add.php', 
																	'heading' => 'Add New CEG',
																	'category' => 'CEG Profiles',
														),
														'edit' => array(
															'file' => 'cegs-edit.php', 
															'heading' => 'Edit CEG',
															'category' => 'CEGs',
														),
														'delete' => array(
																	'file' => 'cegs-delete.php', 
																	'heading' => 'Delete CEG',
																	'category' => 'CEG Profiles',
														)
												)
									),
						'clcs' => array(
										'file' => 'clcs.php', 
										'category' => 'CLC Profiles',
										'heading' => 'List of CEGs',
										'subs' => array(
														'view' => array(
																	'file' => 'clcs-profile.php', 
																	'heading' => 'CEG Profile',
																	'category' => 'CLC Profiles',
														),
														'add' => array(
																	'file' => 'clcs-add.php', 
																	'heading' => 'Add New CEG',
																	'category' => 'CLC Profiles',
														),
														'edit' => array(
															'file' => 'cegs-edit.php', 
															'heading' => 'Edit CEG',
															'category' => 'Engagement',
														),
														'delete' => array(
																	'file' => 'cegs-delete.php', 
																	'heading' => 'Delete CEG',
																	'category' => 'Engagement',
														)
												)
									),
						'documents' => array(
										'file' => 'documents.php', 
										'category' => 'Documents',
										'heading' => 'List of Documents',
										'subs' => array(
														'view' => array(
																	'file' => 'clcs-profile.php', 
																	'heading' => 'CEG Profile',
																	'category' => 'Engagement',
														),
														'add' => array(
																	'file' => 'documents-add.php', 
																	'heading' => 'Add New CEG',
																	'category' => 'Documents',
														),
														'edit' => array(
															'file' => 'cegs-edit.php', 
															'heading' => 'Edit CEG',
															'category' => 'Engagement',
														),
														'delete' => array(
																	'file' => 'cegs-delete.php', 
																	'heading' => 'Delete CEG',
																	'category' => 'Engagement',
														)
												)
									),
						'budgets' => array(
										'file' => 'budgets.php', 
										'category' => 'Documents',
										'heading' => 'List of Documents',
										'subs' => array(
														'view' => array(
																	'file' => 'budgets-view.php', 
																	'heading' => 'View Budget',
																	'category' => 'Budgets',
														),
														'add' => array(
																	'file' => 'budgets-add.php', 
																	'heading' => 'Add New Budget',
																	'category' => 'Budgets'
														),
														'edit' => array(
															'file' => 'budgets-edit.php', 
															'heading' => 'Edit Budget',
															'category' => 'Budgets',
														),
														'edit-budget' => array(
															'file' => 'budgets-edit-budget.php', 
															'heading' => 'Edit Budget',
															'category' => 'Budgets',
														),
														'delete' => array(
																	'file' => 'budgets-delete.php', 
																	'heading' => 'Delete Budget',
																	'category' => 'Budgets',
														),
														'delete-detail' => array(
																	'file' => 'budgets-delete-detail.php', 
																	'heading' => 'Delete Budget',
																	'category' => 'Budgets',
														),
														
												)
									),
						'contributions' => array(
										'file' => 'contributions.php', 
										'category' => 'Contributions',
										'heading' => 'List of Documents',
										'subs' => array(
														'view' => array(
																	'file' => 'contributions-view.php', 
																	'heading' => 'View Budget',
																	'category' => 'Contributions',
														),
														'add' => array(
																	'file' => 'contributions-add.php', 
																	'heading' => 'Add New Budget',
																	'category' => 'Contributions'
														),
														'edit' => array(
															'file' => 'contributions-edit.php', 
															'heading' => 'Edit Budget',
															'category' => 'Contributions',
														),
														'edit-budget' => array(
															'file' => 'contributions-edit-budget.php', 
															'heading' => 'Edit Budget',
															'category' => 'Contributions',
														),
														'delete' => array(
																	'file' => 'contributions-delete.php', 
																	'heading' => 'Delete Budget',
																	'category' => 'Contributions',
														),
														'delete-detail' => array(
																	'file' => 'contributions-delete-detail.php', 
																	'heading' => 'Delete Budget',
																	'category' => 'Contributions',
														),
														
												)
									),
						'expenses' => array(
										'file' => 'expenses.php', 
										'category' => 'Expenses',
										'heading' => 'List of Documents',
										'subs' => array(
														'view' => array(
																	'file' => 'expenses-view.php', 
																	'heading' => 'View Budget',
																	'category' => 'Expenses',
														),
														'add' => array(
																	'file' => 'expenses-add.php', 
																	'heading' => 'Add New Budget',
																	'category' => 'Expenses'
														),
														'edit' => array(
															'file' => 'expenses-edit.php', 
															'heading' => 'Edit Budget',
															'category' => 'Expenses',
														),
														'edit-budget' => array(
															'file' => 'expenses-edit-budget.php', 
															'heading' => 'Edit Budget',
															'category' => 'Expenses',
														),
														'delete' => array(
																	'file' => 'expenses-delete.php', 
																	'heading' => 'Delete Budget',
																	'category' => 'Expenses',
														),
														'delete-detail' => array(
																	'file' => 'expenditures-delete-detail.php', 
																	'heading' => 'Delete Budget',
																	'category' => 'Expenditures',
														),
														
												)
									),
						'budget-categories' => array(
										'file' => 'budgets-categories.php', 
										'heading' => 'Delete Budget',
										'category' => 'Budgets',
							),
						'contribution-categories' => array(
										'file' => 'contribution-categories.php', 
										'heading' => 'Delete Budget',
										'category' => 'Contributions',
							),
						'contribution-sources' => array(
										'file' => 'contribution-sources.php', 
										'heading' => 'Delete Budget',
										'category' => 'Contributions',
							),
						'expense-categories' => array(
										'file' => 'expense-categories.php', 
										'heading' => 'Delete Budget',
										'category' => 'Expenses',
							),
						'glossary' => array(
										'file' => 'glossary.php', 
										'category' => 'Glossary',
										'heading' => 'List of Documents',
										'subs' => array(
														'view' => array(
																	'file' => 'clcs-profile.php', 
																	'heading' => 'CEG Profile',
																	'category' => 'Engagement',
														),
														'add' => array(
																	'file' => 'cegs-add.php', 
																	'heading' => 'Add New CEG',
																	'category' => 'Engagement',
														),
														'edit' => array(
															'file' => 'cegs-edit.php', 
															'heading' => 'Edit CEG',
															'category' => 'Engagement',
														),
														'delete' => array(
																	'file' => 'cegs-delete.php', 
																	'heading' => 'Delete CEG',
																	'category' => 'Engagement',
														)
												)
									),
						'regions' => array(
										'file' => 'regions.php', 
										'category' => 'Locations',
										'heading' => 'List of Regions',
										'subs' => array(
														'add' => array(
																	'file' => 'regions-add.php', 
																	'heading' => 'Add New Region',
																	'category' => 'Locations',
														),
														'edit' => array(
															'file' => 'regions-edit.php', 
															'heading' => 'Edit Region',
															'category' => 'Locations',
														),
														'delete' => array(
																	'file' => 'regions-delete.php', 
																	'heading' => 'Delete Region',
																	'category' => 'Locations',
														)
												)
									),
						'subregions' => array(
										'file' => 'subregions.php', 
										'category' => 'Locations',
										'heading' => 'List of Subregions',
										'subs' => array(
														'add' => array(
																	'file' => 'subregions-add.php', 
																	'heading' => 'Add New Subregion',
																	'category' => 'Locations',
														),
														'edit' => array(
															'file' => 'subregions-edit.php', 
															'heading' => 'Edit Subregion',
															'category' => 'Locations',
														),
														'delete' => array(
																	'file' => 'subregions-delete.php', 
																	'heading' => 'Delete Region',
																	'category' => 'Locations',
														)
												)
									),
						'districts' => array(
										'file' => 'districts.php', 
										'category' => 'Locations',
										'heading' => 'List of Districts',
										'subs' => array(
														'add' => array(
																	'file' => 'districts-add.php', 
																	'heading' => 'Add New District',
																	'category' => 'Locations',
														),
														'edit' => array(
															'file' => 'districts-edit.php', 
															'heading' => 'Edit District',
															'category' => 'Locations',
														),
														'delete' => array(
																	'file' => 'districts-delete.php', 
																	'heading' => 'Delete Region',
																	'category' => 'Locations',
														)
												)
									),
						'counties' => array(
										'file' => 'counties.php', 
										'category' => 'Locations',
										'heading' => 'List of Counties',
										'subs' => array(
														'add' => array(
																	'file' => 'counties-add.php', 
																	'heading' => 'Add New County',
																	'category' => 'Locations',
														),
														'edit' => array(
															'file' => 'counties-edit.php', 
															'heading' => 'Edit County',
															'category' => 'Locations',
														),
														'delete' => array(
																	'file' => 'counties-delete.php', 
																	'heading' => 'Delete County',
																	'category' => 'Locations',
														)
												)
									),
						'subcounties' => array(
										'file' => 'subcounties.php', 
										'category' => 'Locations',
										'heading' => 'List of Subcounties',
										'subs' => array(
														'add' => array(
																	'file' => 'subcounties-add.php', 
																	'heading' => 'Add New Subcounty',
																	'category' => 'Locations',
														),
														'edit' => array(
															'file' => 'subcounties-edit.php', 
															'heading' => 'Edit Subcounty',
															'category' => 'Locations',
														),
														'delete' => array(
																	'file' => 'subcounties-delete.php', 
																	'heading' => 'Delete Subcounty',
																	'category' => 'Locations',
														)
												)
									),
						'parishes' => array(
										'file' => 'parishes.php', 
										'category' => 'Locations',
										'heading' => 'List of Parishes',
										'subs' => array(
														'add' => array(
																	'file' => 'parishes-add.php', 
																	'heading' => 'Add New Parish',
																	'category' => 'Locations',
														),
														'edit' => array(
															'file' => 'parishes-edit.php', 
															'heading' => 'Edit Parish',
															'category' => 'Locations',
														),
														'delete' => array(
																	'file' => 'parishes-delete.php', 
																	'heading' => 'Delete Parish',
																	'category' => 'Locations',
														)
												)
									),
						'villages' => array(
										'file' => 'villages.php', 
										'category' => 'Locations',
										'heading' => 'List of Villages',
										'subs' => array(
														'add' => array(
																	'file' => 'villages-add.php', 
																	'heading' => 'Add New Village',
																	'category' => 'Locations',
														),
														'edit' => array(
															'file' => 'villages-edit.php', 
															'heading' => 'Edit Village',
															'category' => 'Locations',
														),
														'delete' => array(
																	'file' => 'villages-delete.php', 
																	'heading' => 'Delete Village',
																	'category' => 'Locations',
														)
												)
									),
						'usergroups' => array(
										'file' => 'usergroups.php', 
										'category' => 'Usergroups',
										'heading' => 'Usergroups',
										'subs' => array(
														'add' => array(
																	'file' => 'usergroups-add.php', 
																	'heading' => 'Add New User',
																	'category' => 'Users',
														),
														'edit' => array(
															'file' => 'usergroups-edit.php', 
															'heading' => 'Edit Usergroup',
															'category' => 'Usergroups',
														),
														'view' => array(
																	'file' => 'user-details.php', 
																	'heading' => 'User Details',
																	'category' => 'Users',
														)
												)
									),
						'users' => array(
										'file' => 'users.php', 
										'category' => 'Users',
										'heading' => 'List of Users',
										'subs' => array(
														'add' => array(
																	'file' => 'users-add.php', 
																	'heading' => 'Add New User',
																	'category' => 'Users',
														),
														'edit' => array(
															'file' => 'edit-user.php', 
															'heading' => 'Edit User',
															'category' => 'Users',
														),
														'view' => array(
																	'file' => 'users-profile.php', 
																	'heading' => 'User Details',
																	'category' => 'Users',
														)
												)
									),
						'data-entry' => array(
										'file' => 'users.php', 
										'category' => 'Users',
										'heading' => 'List of Users',
										'subs' => array(
														'qualitative' => array(
																	'file' => 'data-qualitative.php', 
																	'heading' => 'Data Entry',
																	'category' => 'Forms',
														),
														'facilitator-training' => array(
															'file' => 'data-facilitators-trained.php', 
															'heading' => 'Edit User',
															'category' => 'Facilitators',
														),
														'facilitator-remuneration' => array(
															'file' => 'data-facilitator-remuneration.php', 
															'heading' => 'Edit User',
															'category' => 'Facilitators',
														),
														'facilitator-equipment' => array(
															'file' => 'data-facilitator-equipment.php', 
															'heading' => 'Edit User',
															'category' => 'Facilitators',
														),
														'clc-establishment' => array(
															'file' => 'data-clc-establishment.php', 
															'heading' => 'Edit User',
															'category' => 'CLC Data',
														),
														
														'clc-coordinator-training' => array(
															'file' => 'data-clc-coordinator-training.php', 
															'heading' => 'Edit User',
															'category' => 'CLC Data',
														),
														'learning-sites' => array(
																	'file' => 'data-learning-sites.php', 
																	'heading' => 'User Details',
																	'category' => 'Locations',
														),
														'structures-established' => array(
																	'file' => 'data-structures-established.php', 
																	'heading' => 'User Details',
																	'category' => 'Locations',
														),
														'structures-strengthened' => array(
																	'file' => 'data-structures-strengthened.php', 
																	'heading' => 'User Details',
																	'category' => 'Locations',
														),
														'villages-mobilized' => array(
																	'file' => 'data-villages-mobilized.php', 
																	'heading' => 'User Details',
																	'category' => 'Locations',
														),
														'quarterly-reporting' => array(
																	'file' => 'data-quarterly-reporting.php', 
																	'heading' => 'User Details',
																	'category' => 'Facilitators',
														),
														'national-meetings' => array(
																	'file' => 'data-national-meetings.php', 
																	'heading' => 'User Details',
																	'category' => 'Meetings',
														),
														'imtc-meetings' => array(
																	'file' => 'data-imtc-meetings.php', 
																	'heading' => 'User Details',
																	'category' => 'Meetings',
														),
														'district-meetings' => array(
																	'file' => 'data-district-meetings.php', 
																	'heading' => 'User Details',
																	'category' => 'Meetings',
														),
														'meetings' => array(
																	'file' => 'meetings.php', 
																	'heading' => 'Meetings',
																	'category' => 'Meetings',
														),
														'scorecards' => array(
																	'file' => 'data-scorecards.php', 
																	'heading' => 'User Details',
																	'category' => 'CLC Data',
														),
														'sitan-sessions' => array(
																	'file' => 'data-sitan-sessions.php', 
																	'heading' => 'User Details',
																	'category' => 'Locations',
														),
														//------Added by Achilley K----------
														'facilitators' => array(
															'file' => 'dataEntryFacilitator.php', 
															'heading' => 'Data Entry',
															'category' => 'Facilitators',
														),
														
														'dataEntryClc' => array(
															'file' => 'dataEntryClc.php', 
															'heading' => 'Data Entry',
															'category' => 'CLC Data',
														),
														//-------end-Achilley K ------------------
												)
									),
									
									
									
						'reports' => array(
										'file' => 'settings.php', 
										'category' => 'Users',
										'heading' => 'Settings Page',
										'subs' => array(
														'beneficiaries' => array(
																	'file' => 'report-beneficiaries.php', 
																	'heading' => 'Report',
																	'category' => 'Engagement Reports',
														),
														'beneficiary-profile' => array(
																	'file' => 'report-beneficiary-profile.php', 
																	'heading' => 'Report',
																	'category' => 'Engagement Reports',
														),
														'facilitator-quarter' => array(
																	'file' => 'report-facilitator-quarter.php', 
																	'heading' => 'Summaries',
																	'category' => 'Performance Reports',
														),
														'district-quarter' => array(
																	'file' => 'report-district-quarter.php', 
																	'heading' => 'Summaries',
																	'category' => 'Performance Reports',
														),
														'programme-annual' => array(
																	'file' => 'report-programme-annual.php', 
																	'heading' => 'Farmers',
																	'category' => 'Reports',
														),
														'farmer-details' => array(
																	'file' => 'report-farmer-details.php', 
																	'heading' => 'Farmers',
																	'category' => 'Reports',
														),
														'farmer-enrollment' => array(
																	'file' => 'report-farmer-enrollment.php', 
																	'heading' => 'Farmers',
																	'category' => 'Reports',
														),
														'esworkers' => array(
																	'file' => 'report-esworkers.php', 
																	'heading' => 'Farmers',
																	'category' => 'Reports',
														),
														'casuals' => array(
																	'file' => 'report-casuals.php', 
																	'heading' => 'Casuals',
																	'category' => 'Reports',
														),
												)
									),
						'my-profile' => array(
										'file' => 'profile.php', 
										'heading' => 'My Profile',
										'category' => 'Users',
									),
						'settings' => array(
										'file' => 'settings.php', 
										'heading' => 'Settings Page'
									),
						'search' => array(
										'file' => 'search-results.php', 
										'heading' => 'Search Results'
									),
					);
		
		function __construct()
		{
			# code...
		}

		// adjust the first items of the route array depending on the root folder of the application
		function getRoute($url)
        {
            $url = trim($url, '/');
            $urlSegments = explode('/', $url);
            array_shift($urlSegments);
            array_shift($urlSegments);
            //array_shift($urlSegments);
            //print_r($urlSegments);
            return $urlSegments;

        }

		function navigate($queryString)
		{
			$db = new MySQL();

			// Retrieve accessible pages for active user
			$qAcessible = "SELECT item_id
						   FROM tbl_user_permissions
						   WHERE usergroup_id = '" . $_SESSION['USER']['USERGROUPID'] . "'
						   ";
			$arrAccessible = $db->QueryArray($qAcessible, MYSQLI_ASSOC);
			// Save them to an array
			$accessiblePages = array();
			if(!empty($arrAccessible))
			{
				foreach($arrAccessible as $acc)
				{
					$accessiblePages[] = $acc['item_id'];
				}
			}
			

			$displayPage = array('file' => "dashboard.php",
								 'category' => "Dashboard",
								 'link' => 'dashboard',
								 'heading' => 'baaaah',
								 'accessible' => $accessiblePages
								);

			$arrQuery = explode("/", $queryString);
			if($arrQuery[0])
			{
				// Handle logout request
				if($arrQuery[0] == "logout")
				{
					auditTrail("logged out");
					$_SESSION = array();
    
					if (ini_get("session.use_cookies")) {
						$params = session_get_cookie_params();
						setcookie(session_name(), '', time() - 42000,
							$params["path"], $params["domain"],
							$params["secure"], $params["httponly"]
						);
					}
					session_destroy();
					header("Location: ./");
				}
				elseif ($arrQuery[0] == "reports") 
				{
					if(isset($arrQuery[1]))
					{
						// Check if the specified report exists
						if(array_key_exists($arrQuery[1], $this->arrPages['reports']['subs']))
						{
							$displayPage['file'] = $this->arrPages['reports']['subs'][$arrQuery[1]]['file'];
							$displayPage['link'] = "reports/".$arrQuery[1];
							$displayPage['category'] = $this->arrPages['reports']['subs'][$arrQuery[1]]['category'];
							$displayPage['heading'] = $this->arrPages['reports']['subs'][$arrQuery[1]]['heading'];
							
							$displayPage['reportQuery'] = array_slice($arrQuery, 2);
						}
						else
						{

						}
					}
					else // No report specified
					{

					}
				}

				elseif ($arrQuery[0] == "search") 
				{
					if(isset($arrQuery[1]))
					{
						$displayPage['file'] = "search-results.php";
						$displayPage['link'] = "search/".$arrQuery[1];
						$displayPage['category'] = "Farmers";
						
						$displayPage['searchQuery'] = array_slice($arrQuery, 2);
					}
					else // No report specified
					{

					}
				}
				elseif ($arrQuery[0] == "trace") 
				{
					if(isset($arrQuery[1]))
					{
						$displayPage['file'] = "trace.php";
						$displayPage['link'] = "trace/".$arrQuery[1];
						$displayPage['category'] = "Trace";
						
						$displayPage['searchQuery'] = array_slice($arrQuery, 2);
					}
					else // No report specified
					{
						$displayPage['file'] = "trace.php";
						$displayPage['link'] = "trace/";
						$displayPage['category'] = "Trace";
					}
				}
				else
				{
					// Handle other router requests
					if(array_key_exists($arrQuery[0], $this->arrPages))
					{
						// Get the first item on the url, most probably a listing page/category name
						$firstItem = $this->arrPages[$arrQuery[0]];

						// If there is a second item in the url, like a detail or edit page
						if(isset($arrQuery[1]))
						{
							// Check if the first item has sub pages i.e detail, edit, etc
							if(array_key_exists("subs", $firstItem))
							{
								$secondItem = $firstItem['subs']; 
								if(isset($arrQuery[2]) && is_int($arrQuery[2]))
								{
									$displayPage['file'] = $secondItem['view'];
									$displayPage['link'] = $arrQuery[0];
									$displayPage['category'] = $secondItem[$arrQuery[1]]['category'];
									$displayPage['heading'] = $secondItem[$arrQuery[1]]['heading'];
									$displayPage['item'] = $arrQuery[2];
								}

								if(array_key_exists($arrQuery[1], $secondItem))
								{
									$displayPage['file'] = $secondItem[$arrQuery[1]]['file'];
									$displayPage['category'] = $secondItem[$arrQuery[1]]['category'];
									$displayPage['heading'] = $secondItem[$arrQuery[1]]['heading'];
									if($arrQuery[0] == 'reports')
									{
										$displayPage['link'] = $arrQuery[1];
									}
									else
									{
										$displayPage['link'] = $arrQuery[0];
										$displayPage['item'] = $arrQuery[2];
									}
									
									
								}
							}
						}
						// Else just get the first page
						else
						{
							$displayPage['file'] = $firstItem['file'];
							$displayPage['link'] = $arrQuery[0];
							$displayPage['category'] = $firstItem['category'];
							$displayPage['heading'] = $firstItem['heading'];
						}

						if(!$arrQuery[0])
						{
							$displayPage['file'] = "dashboard.php";
							$displayPage['category'] = "Dashboard";
							$displayPage['link'] = 'dashboard';
							$displayPage['heading'] = 'Dashboard';
						}
					}
					// Requested page does not exist
					else
					{
						$displayPage['file'] = "404.php";
						$displayPage['category'] = "Error";
						$displayPage['link'] = '';
						$displayPage['heading'] = 'Error';
					}
				}
			}
			else
			{
				$displayPage['file'] = "dashboard.php";
				$displayPage['category'] = "Dashboard";
				$displayPage['link'] = 'dashboard';
				$displayPage['heading'] = 'Error';
			}
			
			return $displayPage;
		}

		function adjust_root()
		{
			if(isset($arrURL[1]))
				$ROOT_FOLDER = "../";
			if(isset($arrURL[2]))
				$ROOT_FOLDER = "../../";

			if(isset($arrURL[3]))
				$ROOT_FOLDER = "../../../";
				
			if(isset($arrURL[4]))
				$ROOT_FOLDER = "../../../../";
		}
	}
?>