<?php
	/*******************************************************
	Include only the relevant javascript files in index.php
	*******************************************************/
	$arrJavascriptFiles = [];
	switch ($displayedPage['file']) 
	{
		case 'dashboard.php':
		case 'dashboard-mne.php':
		case 'dashboard-technical.php':
			// Page Vendor
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/jquery.flot/jquery.flot.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/jquery.flot/jquery.flot.stack.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/jquery.flot/jquery.flot.resize.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'assets/js/custom-dashboard.js"></script>';
			break;

		case 'usergroups.php':
		case 'users.php':
		case 'regions.php':
		case 'subregions.php':
		case 'districts.php':
		case 'counties.php':
		case 'subcounties.php':
		case 'parishes.php':
		case 'villages.php':
		case 'components.php':
		case 'beneficiaries.php':
		case 'cegs.php':
		case 'clcs.php':
		case 'budgets.php':
		case 'expenses.php':
		case 'contributions.php':
		case 'audit-trail.php':
		case 'cegs-profile.php':
		case 'contribution-sources.php':
		case 'cegs-profile.php':
		case 'users-profile.php':
			$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/datatables.net/js/jquery.dataTables.min.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/datatables.net-dt/js/dataTables.dataTables.min.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/datatables.net-responsive/js/dataTables.responsive.min.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/datatables.net-responsive-dt/js/responsive.dataTables.min.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'assets/js/custom-datatables.js"></script>';
			break;
		case 'inbox.php':
			$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/quill/quill.min.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'assets/js/dashforge.mail.js"></script>';
			break;

		case 'configure-approvals.php':
			$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/prismjs/prism.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>';
    		$arrJavascriptFiles[] = '<script src="'.$ROOT_FOLDER.'lib/typeahead.js/typeahead.bundle.min.js"></script>';
    		break;
		default:
			# code...
			break;
	}

	if(!empty($arrJavascriptFiles))
	{
		foreach ($arrJavascriptFiles as $key => $file) 
		{
			echo $file . "\n\t";
		}
	}
?>