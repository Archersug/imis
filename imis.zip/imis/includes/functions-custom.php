<?php

	/*********************************************/
	function FirestoreAuth()
	{
		$url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=AIzaSyD-thNrOtjcBIgYmHcuFLWXMvngpKq6edM/";

		$headers = array(
					"Content-Type: application/json"
				);

		$data = array(); 
		
		// Initiate curl handle
		$curl = curl_init();

		curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
		  	CURLOPT_RETURNTRANSFER => true,
		  	CURLOPT_ENCODING => "",
		  	CURLOPT_MAXREDIRS => 10,
		  	CURLOPT_TIMEOUT => 30,
		  	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  	CURLOPT_CUSTOMREQUEST => "POST",
		  	CURLOPT_SSL_VERIFYPEER => false,
		  	CURLOPT_HEADER => true,
		  	CURLOPT_HTTPHEADER => $headers,
		  	CURLOPT_POSTFIELDS => $data,
		  	CURLINFO_HEADER_OUT => true
		));

		$response = curl_exec($curl);
		$information = curl_getinfo($curl, CURLINFO_HEADER_OUT);
		$informationAll = curl_getinfo($curl);
		//print_r($informationAll);
		print_r($response);
		
		/*$err = curl_error($curl);
		if ($err) 
		{
			$message =  "cURL Error #:" . $err;

			return array(
				"success" => 0,
				"message" => $message
			);
		} 
		else 
		{
		    $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
			curl_close($curl);
			$header_size = $informationAll['header_size'];
			$header = substr($response, 0, $header_size);
			$body = substr($response, $header_size);

			return array(
				"success" => 1,
				"message" => "Good",
				"httpcode" => $httpcode,
				"header" => $header,
				"body" => $body
			);
		}*/
	}

	function FirestoreAuthx($numberList, $message)
	{
		$url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=AIzaSyD-thNrOtjcBIgYmHcuFLWXMvngpKq6edM/";
		$headers = array(
					"Content-Type: application/json"
				);
		$data = array(
			'NUMBERS' => $numberList,
			'MESSAGE' => $message
		); 
		$url .=  http_build_query($data);
		$options = array(
	        CURLOPT_HEADER         => false,    // don't return headers
	        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
	        CURLOPT_ENCODING       => "",       // handle all encodings
	        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
	        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
	        CURLOPT_TIMEOUT        => 120,      // timeout on response
	        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
	        CURLOPT_SSL_VERIFYPEER => 0,     // Disabled SSL Cert checks
	        CURLOPT_SSL_VERIFYHOST => 0,
	        CURLOPT_RETURNTRANSFER => 1,
	        CURLOPT_HTTPHEADER => $headers,
    	);
		$ch = curl_init( $url );
	    curl_setopt_array( $ch, $options );
		$ch_result = curl_exec($ch);
		curl_close($ch);

		return $ch_result;
	}

	function FirestoreConnect($numberList, $message)
	{
		$url = "https://firestore.googleapis.com/v1/projects/icolewmis-771dc/databases/(default)/";
		$data = array(
			'NUMBERS' => $numberList,
			'MESSAGE' => $message
		); 
		$url .=  http_build_query($data);
		$options = array(
	        CURLOPT_HEADER         => false,    // don't return headers
	        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
	        CURLOPT_ENCODING       => "",       // handle all encodings
	        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
	        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
	        CURLOPT_TIMEOUT        => 120,      // timeout on response
	        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
	        CURLOPT_SSL_VERIFYPEER => 0,     // Disabled SSL Cert checks
	        CURLOPT_SSL_VERIFYHOST => 0,
	        CURLOPT_RETURNTRANSFER => 1
    	);
		$ch = curl_init( $url );
	    curl_setopt_array( $ch, $options );
		$ch_result = curl_exec($ch);
		curl_close($ch);

		return $ch_result;
	}

	function dbGetAllComponents($options = null)
	{
		$db = new MySQL();
		$qComps = "SELECT tbl_components.*
                   FROM tbl_components
                   ";
	    $arrCos = $db->QueryArray($qComps, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Component query error: " . $db->Error());

	   if($db->RowCount())
	   {
		   //$arrComps = []
	   	$arrComps = array();
	   	foreach($arrCos as $comp)
	   	{
	   		$arrUnits = dbGetComponentUnits($comp['component_id']);
	   		$comp['units'] = $arrUnits;
	   		$arrComps[] = $comp;
	   	}
	   	return $arrComps;
	   }
	   else
	   {
	   	return array();
	   }
	}


	function dbGetTrainingCourses($options = null)
	{
		$db = new MySQL();
		$qComps = "SELECT tbl_training_courses.*
                   FROM tbl_training_courses
                   WHERE 1
                   ";
        
        // Optional WHERE clauses
        if($options['group_id'])
        	$qComps .= " AND FIND_IN_SET(".$options['group_id'].", tbl_training_courses.course_group)";

	    $arrComps = $db->QueryArray($qComps, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Course query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrComps;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetAllActivities($options = null)
	{
		$db = new MySQL();
		$qActs = "SELECT tbl_activities.*
                   FROM tbl_activities
                   ";
	    $arrActs = $db->QueryArray($qActs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Activity query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrActs;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetQuarters($options = null)
	{
		$db = new MySQL();
		$qQuarters = "SELECT tbl_quarters.*
               		FROM tbl_quarters
               		ORDER BY tbl_quarters.quarter_start DESC
                   ";
	    $arrQuarters = $db->QueryArray($qQuarters, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Quarter query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuarters;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetCurrentQuarter()
	{
		$db = new MySQL();
		$qQuarters = "SELECT tbl_quarters.*
               		FROM tbl_quarters
               		WHERE tbl_quarters.quarter_status = 'OPEN'
                   ";
	    $arrQuarters = $db->QueryArray($qQuarters, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Quarter query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuarters;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetPartners()
	{
		$db = new MySQL();
		$qPartners = "SELECT tbl_partners.*
               		FROM tbl_partners
                   ";
	    $arrPartners = $db->QueryArray($qPartners, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Partner query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrPartners;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetAllChallenges($options = null)
	{
		$db = new MySQL();
		$qChals = "SELECT tbl_challenges.*
                   FROM tbl_challenges
                   ";
	    $arrChals = $db->QueryArray($qChals, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Challenge query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrChals;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetComponent($componentId)
	{
		if($componentId)
		{
			$db = new MySQL();
			$componentId = MySQL::SQLValue($componentId);
			$qComp = "SELECT tbl_components.*
	                   FROM tbl_components
	                   WHERE tbl_components.component_id = $componentId
	                   ";
		    $arrComp = $db->QuerySingleRowArray($qComp, MYSQLI_ASSOC);
		    if($db->Error())
		        die("Component query error: " . $db->Error());

		   	if($db->RowCount())
		   	{
		   		$qUnits = "SELECT tbl_component_units.*
		   					FROM tbl_component_units
		   					WHERE tbl_component_units.component_id = $componentId
		   					";
		   		$arrUnits = $db->QueryArray($qUnits, MYSQLI_ASSOC);
		   		if($db->Error())
		        	die("Unit query error: " . $db->Error());

		        if($db->RowCount())
		        {
		        	$arrComp['units'] = $arrUnits;
		        }
		        else
		        {
		        	$arrComp['units'] = array();
		        }
		   		return $arrComp;
		   	}
		   	else
		   	{
		   		return array();
		   	}
		}
		else
		{
			return array();
		}
	}

	function dbGetAllIndicators($options = null)
	{
		$db = new MySQL();
		$qIndicators = "SELECT tbl_indicators.*
                   FROM tbl_indicators
                   WHERE 1
                   ";
	    $arrIndicators = $db->QueryArray($qIndicators, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Indicator query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrIndicators;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetFacilitatorsTrained($options)
	{
		$db = new MySQL();
		$qTrained = "SELECT
						tbl_subcounties.subcounty_name,tbl_districts.district_name, tbl_training_courses.course_name,tbl_training_courses.course_id, tbl_training_facilitators.level1, tbl_training_facilitators.level2,tbl_training_facilitators.level3, tbl_training_facilitators.user_id, tbl_users.fullname,
						SUM(CASE WHEN tbl_training_facilitators.attendance = '1' THEN 1 ELSE 0 END) AS attended
					    FROM tbl_training_facilitators 
					LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_training_facilitators.facilitator_id 
					LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
					LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
					LEFT JOIN tbl_training_courses ON tbl_training_courses.course_id = tbl_training_facilitators.course_id
					LEFT JOIN tbl_users ON tbl_users.user_id = tbl_training_facilitators.user_id
					WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
        	$qTrained .= "AND tbl_training_facilitators.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
        	$qTrained .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
        	$qTrained .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

       	$qTrained .= " GROUP BY tbl_training_facilitators.course_id";
       	//$qTrained .= " GROUP BY tbl_subcounties.subcounty_id";

	    $arrTrained = $db->QueryArray($qTrained, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Training query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrTrained;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

//tbl_clc_scorecardsessions
function dbGetscorecardsessions($options)
	{
		$db = new MySQL();
		$qEquiped = "SELECT
						tbl_subcounties.subcounty_name,tbl_districts.district_name, tbl_facilitator_equiped.user_id, tbl_users.fullname,
						SUM(CASE WHEN tbl_clc_scorecardsessions.scorecard_session = '1' THEN 1 ELSE 0 END) AS scorecard
					    FROM tbl_clc_scorecardsessions 
					LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_clc_scorecardsessions.parish_id 
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
					LEFT JOIN tbl_users ON tbl_users.user_id = tbl_clc_scorecardsessions.user_id
					WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
        	$qEquiped .= "AND tbl_clc_scorecardsessions.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
        	$qEquiped .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
        	$qEquiped .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

       	//$qTrained .= " GROUP BY tbl_facilitator_equiped.facilitator_id";
       	$qEquiped .= " GROUP BY tbl_subcounties.subcounty_id";

	    $qEquiped = $db->QueryArray($qEquiped, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator Equiped query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $qEquiped;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}




function dbGetFacilitatorsEquiped($options)
	{
		$db = new MySQL();
		$qEquiped = "SELECT
						tbl_subcounties.subcounty_name,tbl_districts.district_name, tbl_facilitator_equiped.user_id, tbl_users.fullname,
						SUM(CASE WHEN tbl_facilitator_equiped.equiped = '1' THEN 1 ELSE 0 END) AS equiped
					    FROM tbl_facilitator_equiped 
					LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_facilitator_equiped.facilitator_id 
					LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
					LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
					LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitator_equiped.user_id
					WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
        	$qEquiped .= "AND tbl_facilitator_equiped.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
        	$qEquiped .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
        	$qEquiped .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

       	//$qTrained .= " GROUP BY tbl_facilitator_equiped.facilitator_id";
       	$qEquiped .= " GROUP BY tbl_subcounties.subcounty_id";

	    $qEquiped = $db->QueryArray($qEquiped, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator Equiped query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $qEquiped;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}
function dbGetFacilitatorsRemunerated($options)
	{
		$db = new MySQL();
		$qEquiped = "SELECT
						tbl_subcounties.subcounty_name,tbl_districts.district_name, tbl_facilitator_remuneration.user_id, tbl_users.fullname,
						SUM(CASE WHEN tbl_facilitator_remuneration.remuneration_id = '1' THEN 1 ELSE 0 END) AS remunerated
					    FROM tbl_facilitator_remuneration 
					LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_facilitator_remuneration.facilitator_id 
					LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
					LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
					LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitator_remuneration.user_id
					WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
        	$qEquiped .= "AND tbl_facilitator_remuneration.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
        	$qEquiped .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
        	$qEquiped .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

       	//$qTrained .= " GROUP BY tbl_facilitator_equiped.facilitator_id";
       	$qEquiped .= " GROUP BY tbl_subcounties.subcounty_id";

	    $qEquiped = $db->QueryArray($qEquiped, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator Remunerated query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $qEquiped;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}


//---------learning Sites-----

function dbGetFacilitatorLearningSites($options)
	{
		$db = new MySQL();
		$sql = "SELECT
						tbl_subcounties.subcounty_name,tbl_districts.district_name, tbl_facilitator_learningsites.user_id, tbl_users.fullname,
						SUM(CASE WHEN tbl_facilitator_learningsites.learning_sites = '1' THEN 1 ELSE 0 END) AS learning_sites
					    FROM tbl_facilitator_learningsites 
					LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_facilitator_learningsites.facilitator_id 
					LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
					LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
					LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitator_learningsites.user_id
					WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
        	$sql .= "AND tbl_facilitator_learningsites.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
        	$sql .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
        	$sql .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

       	//$qTrained .= " GROUP BY tbl_facilitator_equiped.facilitator_id";
       	$sql .= " GROUP BY tbl_subcounties.subcounty_id";

	    $sql = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator Learning Sites query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $sql;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}



//---------Sitan Sessions-----

function dbGetFacilitatorSitanSessions($options)
	{
		$db = new MySQL();
		$sql = "SELECT
						tbl_subcounties.subcounty_name,tbl_districts.district_name, tbl_facilitator_sitansessions.user_id, tbl_users.fullname,
						SUM(CASE WHEN tbl_facilitator_sitansessions.sitan_sessions = '1' THEN 1 ELSE 0 END) AS sitan_sessions
					    FROM tbl_facilitator_sitansessions 
					LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_facilitator_sitansessions.facilitator_id 
					LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
					LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
					LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitator_sitansessions.user_id
					WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
        	$sql .= "AND tbl_facilitator_sitansessions.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
        	$sql .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
        	$sql .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

       	//$qTrained .= " GROUP BY tbl_facilitator_equiped.facilitator_id";
       	$sql .= " GROUP BY tbl_subcounties.subcounty_id";

	    $sql = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator Sitan Sessions query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $sql;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}



//----Vilages Mobilized and Sensitized

function dbGetVillagesMobilizedAndSensitized($options)
	{
		$db = new MySQL();
		$sql = "SELECT
						tbl_subcounties.subcounty_name,tbl_districts.district_name, tbl_facilitator_villagesMobilizedSensitized.user_id, tbl_users.fullname,
						SUM(CASE WHEN tbl_facilitator_villagesMobilizedSensitized.villages_mobilized = '1' THEN 1 ELSE 0 END) AS villages_mobilized
					    FROM tbl_facilitator_villagesMobilizedSensitized 
					LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_facilitator_villagesMobilizedSensitized.facilitator_id 
					LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
					LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
					LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitator_villagesMobilizedSensitized.user_id
					WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
        	$sql .= "AND tbl_facilitator_villagesMobilizedSensitized.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
        	$sql .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
        	$sql .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

       	//$qTrained .= " GROUP BY tbl_facilitator_equiped.facilitator_id";
       	$sql .= " GROUP BY tbl_subcounties.subcounty_id";

	    $sql = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator Villages Mobilized and Sensitized query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $sql;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

//dbGetStructuresStrengthened

function dbGetStructuresStrengthened($options)
	{
		$db = new MySQL();
		$sql = "SELECT
						tbl_subcounties.subcounty_name,tbl_districts.district_name, tbl_facilitator_structures_strengthened.user_id, tbl_users.fullname,
						SUM(CASE WHEN tbl_facilitator_structures_strengthened.structures_strengthened = '1' THEN 1 ELSE 0 END) AS structures_strengthened
					    FROM tbl_facilitator_structures_strengthened 
					LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_facilitator_structures_strengthened.facilitator_id 
					LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
					LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
					LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitator_structures_strengthened.user_id
					WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
        	$sql .= "AND tbl_facilitator_structures_strengthened.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
        	$sql .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
        	$sql .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

       	//$qTrained .= " GROUP BY tbl_facilitator_equiped.facilitator_id";
       	$sql .= " GROUP BY tbl_subcounties.subcounty_id";

	    $sql = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator Structures Strengthened query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $sql;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}
	
	//dbGetStructuresEstablished
	
	function dbGetStructuresEstablished($options)
	{
		$db = new MySQL();
		$sql = "SELECT
						tbl_subcounties.subcounty_name,tbl_districts.district_name, tbl_facilitator_structures_established.user_id, tbl_users.fullname,
						SUM(CASE WHEN tbl_facilitator_structures_established.structures_established = '1' THEN 1 ELSE 0 END) AS structures_established
					    FROM tbl_facilitator_structures_established 
					LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_facilitator_structures_established.facilitator_id 
					LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id 
					LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id 
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id 
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
					LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitator_structures_established.user_id
					WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
        	$sql .= "AND tbl_facilitator_structures_established.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
        	$sql .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
        	$sql .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

       	//$qTrained .= " GROUP BY tbl_facilitator_equiped.facilitator_id";
       	$sql .= " GROUP BY tbl_subcounties.subcounty_id";

	    $sql = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator Structures Established query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $sql;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}
	//-------SITANS,District and National Meetings
	function dbGetMeetings($options)
	{
		$db = new MySQL();
		$qTrained = "SELECT tbl_subcounties.subcounty_name,
		 tbl_districts.district_name,
		 tbl_meeting_types.meeting_type,
		 tbl_meeting_types.meeting_id,tbl_meetings.meeting_name,tbl_meetings.description,
		 COUNT(meeting_name) AS attended
		  FROM tbl_meetings LEFT JOIN tbl_meeting_types ON tbl_meeting_types.meeting_id = tbl_meetings.meeting_type LEFT JOIN tbl_subcounties
		   ON tbl_subcounties.subcounty_id = tbl_meetings.subcounty_id 
		   LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id 
		   WHERE 1 
                   ";

        if(isset($options['quarter_id']))
        {
   $qTrained .= "AND tbl_meetings.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['subcounty_id']))
        {
   $qTrained .= "AND tbl_subcounties.subcounty_id = '".$options['subcounty_id']."'";
        }

        if(isset($options['district_id']))
        {
   $qTrained .= "AND tbl_districts.district_id = '".$options['district_id']."'";
        }

   $qTrained .= " GROUP BY tbl_meetings.meeting_name";
  //$qTrained .= " GROUP BY tbl_subcounties.subcounty_id";

	    $arrTrained = $db->QueryArray($qTrained, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Training query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrTrained;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetAllCLCServices($options = null)
	{
		$db = new MySQL();
		$qServices = "SELECT tbl_clc_services.*
                   FROM tbl_clc_services
                   WHERE 1
                   ";
	    $arrServices = $db->QueryArray($qServices, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC service query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrServices;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetCLCUsers($options)
	{
		$db = new MySQL();
		$qUsers = "SELECT tbl_clc_users.*, tbl_clc_services.service_name
                   FROM tbl_clc_users
                   LEFT JOIN tbl_clc_services ON tbl_clc_services.service_id = tbl_clc_users.service_id
                   WHERE 1
                   ";

        if(isset($options['quarter_id']))
        {
        	$qUsers .= "AND tbl_clc_users.quarter_id = '".$options['quarter_id']."'";
        }

        if(isset($options['clc_id']))
        {
        	$qUsers .= "AND tbl_clc_users.clc_id = '".$options['clc_id']."'";
        }

	    $arrUsers = $db->QueryArray($qUsers, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC service query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrUsers;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetDisabilities($options=NULL)
	{
		$db = new MySQL();
		$qDisabilities = "SELECT tbl_disability_types.*
                   FROM tbl_disability_types
                   WHERE 1
                   ";
				   if(isset($options['disability_id']))
        {
        	$qDisabilities .= "AND tbl_disability_types.disability_id = '".$options['disability_id']."'";
        }


	    $arrDisabilities = $db->QueryArray($qDisabilities, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Disability query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrDisabilities;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetAllCLCServicesOffered($options = null)
	{
		$db = new MySQL();
		$qServices = "SELECT tbl_clc_services_offered.*, tbl_clc_services.service_name, tbl_clc_services.service_description
                   FROM tbl_clc_services_offered
                   LEFT JOIN tbl_clc_services ON tbl_clc_services.service_id = tbl_clc_services_offered.service_id
                   LEFT JOIN tbl_clcs ON tbl_clcs.clc_id = tbl_clc_services_offered.clc_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_clcs.parish_id
                   WHERE 1
                   ";

        // Optional WHERE clauses
        if($options['clc_id'])
        	$qServices .= " AND tbl_clc_services_offered.clc_id = '" . $options['clc_id'] . "' ";

	    $arrServices = $db->QueryArray($qServices, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC service query error: " . $db->Error());


	   	if($db->RowCount())
	   	{
	   		return $arrServices;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetAllCLCPartnerships($options = null)
	{
		$db = new MySQL();
		$qParts = "SELECT tbl_clc_partnerships.*, tbl_partners.*, tbl_clcs.clc_name
                   FROM tbl_clc_partnerships
                   LEFT JOIN tbl_partners ON tbl_partners.partner_id = tbl_clc_partnerships.partner_id
                   LEFT JOIN tbl_clcs ON tbl_clcs.clc_id = tbl_clc_partnerships.clc_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_clcs.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   WHERE 1
                   ";

        // Optional WHERE clauses
        if($options['clc_id'])
        	$qParts .= " AND tbl_clc_partnerships.clc_id = '" . $options['clc_id'] . "' ";

	    $arrParts = $db->QueryArray($qParts, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC partnership query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrParts;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetCEGEvents($options = null)
	{
		$db = new MySQL();
		$qEvents = "SELECT tbl_ceg_events.*, tbl_events.*
                   FROM tbl_ceg_events
                   LEFT JOIN tbl_events ON tbl_events.event_id = tbl_ceg_events.event_id
                   WHERE 1
                   ";

        // Optional WHERE clauses
        if($options['ceg_id'])
        	$qEvents .= " AND tbl_ceg_events.ceg_id = '" . $options['ceg_id'] . "' ";

        $qEvents .= " ORDER BY tbl_events.start_date DESC";
        
	    $arrEvents = $db->QueryArray($qEvents, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CEG event query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrEvents;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetEventDetails($eventId)
	{
		$db = new MySQL();
		$qEvents = "SELECT tbl_ceg_events.*, tbl_events.*
                   FROM tbl_ceg_events
                   LEFT JOIN tbl_events ON tbl_events.event_id = tbl_ceg_events.event_id
                   WHERE tbl_events.event_id = '$eventId'
                   ";
        
	    $arrEvent = $db->QuerySingleRowArray($qEvents, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CEG event query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		// Get attendance
	   		$qAttendance = "SELECT tbl_event_attendance.*, tbl_beneficiaries.beneficiary_name
	   						FROM tbl_event_attendance
	   						LEFT JOIN tbl_beneficiaries ON tbl_beneficiaries.beneficiary_id = tbl_event_attendance.beneficiary_id
	   						WHERE tbl_event_attendance.event_id = '$eventId'
	   						";
	   		$arrAttendance = $db->QueryArray($qAttendance, MYSQLI_ASSOC);

	   		if($db->RowCount())
	   			$arrEvent['attendance'] = $arrAttendance;
	   		else
	   			$arrEvent['attendance'] = array();

	   		return $arrEvent;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetEventTypes($options = null)
	{
		$db = new MySQL();
		$qTypes = "SELECT tbl_event_types.*
                   FROM tbl_event_types
                   WHERE 1
                   ";
	    $arrTypes = $db->QueryArray($qTypes, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Event type query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrTypes;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetBeneficiary($beneficiaryId)
	{
		if($beneficiaryId)
		{
			$db = new MySQL();
			$beneficiaryId = MySQL::SQLValue($beneficiaryId);
			$qBenefs = "SELECT tbl_beneficiaries.*, tbl_beneficiary_categories.category_abbr, tbl_ceg_leadership.position_name, tbl_cegs.ceg_name, tbl_cegs.ceg_code
	                   FROM tbl_beneficiaries
	                   LEFT JOIN tbl_cegs ON tbl_cegs.ceg_id = tbl_beneficiaries.ceg_id
	                   LEFT JOIN tbl_beneficiary_categories ON tbl_beneficiary_categories.category_id = tbl_beneficiaries.category_id
	                   LEFT JOIN tbl_ceg_leadership ON tbl_ceg_leadership.position_id = tbl_beneficiaries.position_id
	                   WHERE tbl_beneficiaries.beneficiary_id = $beneficiaryId 
	                   ";

		    $arrBenefs = $db->QuerySingleRowArray($qBenefs, MYSQLI_ASSOC);
		    if($db->Error())
		        die("Beneficiary query error: " . $db->Error());

		   	if($db->RowCount())
		   	{
		   		$qContribs = "SELECT tbl_vsla_contributions.*
		   					  FROM tbl_vsla_contributions
		   					  WHERE tbl_vsla_contributions.beneficiary_id = $beneficiaryId
		   					  ";
		   		$arrContribs = $db->QueryArray($qContribs, MYSQLI_ASSOC);
		   		if($db->Error())
		        	die("Beneficiary query error: " . $db->Error());

		        if($db->RowCount())
		        {
		        	$arrBenefs['contributions'] = $arrContribs;
		        }
		        else
		        {
		        	$arrBenefs['contributions'] = array();
		        }

		   		return $arrBenefs;
		   	}
		   	else
		   	{
		   		return array();
		   	}
		}
		else
	   	{
	   		return array();
	   	}
	}

	function dbGetBeneficiariesNumber()
	{
		$db = new MySQL();
		$qNum = "SELECT COUNT(*)
				 FROM tbl_beneficiaries
				 WHERE 1
				 ";
		$num = $db->QuerySingleValue($qNum);
		return $num;
	}

	function dbGetCEGsNumber()
	{
		$db = new MySQL();
		$qNum = "SELECT COUNT(*)
				 FROM tbl_cegs
				 WHERE 1
				 ";
		$num = $db->QuerySingleValue($qNum);
		return $num;
	}

	function dbGetCLCsNumber()
	{
		$db = new MySQL();
		$qNum = "SELECT COUNT(*)
				 FROM tbl_clcs
				 WHERE 1
				 ";
		$num = $db->QuerySingleValue($qNum);
		return $num;
	}

	function dbGetTotalSavings($options)
	{
		$db = new MySQL();
		$qSum = "SELECT SUM( tbl_vsla_contributions.contribution_amount) AS total_saving 
				FROM tbl_vsla_contributions 
				WHERE '".$options['start_date']."' < tbl_vsla_contributions.contribution_date < '".$options['stop_date']."'";
		$totalSaving = $db->QuerySingleValue($qSum);

		return $totalSaving;
	}

	function dbGetAverageSavings($options)
	{
		$db = new MySQL();
		$qSum = "SELECT AVG( tbl_vsla_contributions.contribution_amount) AS average_saving 
				FROM tbl_vsla_contributions 
				WHERE '".$options['start_date']."' < tbl_vsla_contributions.contribution_date < '".$options['stop_date']."'";
		$averageSaving = $db->QuerySingleValue($qSum);

		return $averageSaving;
	}

	function dbGetBeneficiaries($options = null)
	{
		$db = new MySQL();
		$qBenefs = "SELECT tbl_beneficiaries.*, tbl_beneficiary_categories.category_abbr, tbl_ceg_leadership.position_name
                   FROM tbl_beneficiaries
                   LEFT JOIN tbl_beneficiary_categories ON tbl_beneficiary_categories.category_id = tbl_beneficiaries.category_id
                   LEFT JOIN tbl_ceg_leadership ON tbl_ceg_leadership.position_id = tbl_beneficiaries.position_id
                   WHERE 1 
                   ";

        // Optional WHERE clauses
        if(isset($options['ceg_id']))
        	$qBenefs .= " AND tbl_beneficiaries.ceg_id = '" . $options['ceg_id'] . "' ";

        if(isset($options['locations']))
    	{
			$array = array_map('intval', explode(',', $options['locations']));
			$array = implode("','",$array);
    		$qBenefs .= "AND tbl_beneficiaries.ceg_id IN ('" . $array . "') ";
    	}

        // End query
        if(isset($options['ceg_id']))
        	$qBenefs .= " ORDER BY tbl_beneficiaries.position_id DESC, tbl_beneficiaries.beneficiary_name ASC";

	    $arrBenefs = $db->QueryArray($qBenefs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Beneficiary query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrBenefs;
	   }
	   else
	   {
	   	return array();
	   }
	}

	

	function dbGetCLCs($options = null)
	{
		$db = new MySQL();
		$qCls = "SELECT tbl_clcs.*,  
					tbl_subcounties.subcounty_name, tbl_parishes.parish_name, tbl_districts.district_name
                   FROM tbl_clcs
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_clcs.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id
                   WHERE 1 
                   ";
        if(!empty($options))
        {
        	if(isset($options['clc_id']))
        		$qCls .= "AND tbl_clcs.clc_id = '" . $options['clc_id'] . "' ";

        	if(isset($options['subcounty_id']))
        		$qCls .= "AND tbl_subcounties.subcounty_id = '" . $options['subcounty_id'] . "' ";

        	if(isset($options['parishes']))
        	{
				$array = array_map('intval', explode(',', $options['parishes']));
				$array = implode("','",$array);
        		$qCls .= "AND tbl_clcs.parish_id IN ('" . $array . "') ";
        	}
        }

	    $arrCls = $db->QueryArray($qCls, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCls;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetCLCGroups($groupId)
	{
		$db = new MySQL();
		$qGroups = "SELECT tbl_cegs.*, tbl_villages.village_name, tbl_users.fullname, 
					tbl_subcounties.subcounty_name, tbl_parishes.parish_name
                   FROM tbl_cegs
                   LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_cegs.village_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_cegs.facilitator_id
                   LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitators.user_id
                   WHERE tbl_cegs.clc_id = '$groupId'
                   ";

	    $arrGroups = $db->QueryArray($qGroups, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Groups query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrGroups;
	   }
	   else
	   {
	   	return array();
	   }
	}

	/*********************************************************************
	This function retrieves CEGs based on the options added to the options
	array
	**********************************************************************/
	function dbGetCegs($options = null)
	{
		$db = new MySQL();
		$qCegs = "SELECT tbl_cegs.*, tbl_villages.village_name, tbl_users.fullname, 
					tbl_subcounties.subcounty_name, tbl_parishes.parish_name, 
					tbl_districts.district_name, tbl_vslas.vsla_id, tbl_vslas.vsla_name
                   FROM tbl_cegs
                   LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_cegs.village_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id
                   LEFT JOIN tbl_facilitators ON tbl_facilitators.facilitator_id = tbl_cegs.facilitator_id
                   LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitators.user_id
                   LEFT JOIN tbl_vslas ON tbl_vslas.ceg_id = tbl_cegs.ceg_id
                   WHERE 1 
                   ";

        if(!empty($options))
        {
        	if(isset($options['ceg_id']))
        		$qCegs .= "AND tbl_cegs.ceg_id = '" . $options['ceg_id'] . "' ";

        	if(isset($options['villages']))
        	{
				$array = array_map('intval', explode(',', $options['villages']));
				$array = implode("','",$array);
        		$qCegs .= "AND tbl_cegs.village_id IN ('" . $array . "') ";
        	}
        }

        //echo $qCegs;

	    $arrCegs = $db->QueryArray($qCegs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CEG query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCegs;
	   }
	   else
	   {
	   	return array();
	   }
	}

	/*****************************************************************
	This function retrieves the CEGs assigned to a particular user
	based on their user_id. CEG assignments are saved in the tbl_assign_ceg
	table and this is where the user_id is queried to return the IDs of 
	the CEGs assigned to that user.
	*****************************************************************/
	function dbGetUserCegs($userId)
	{
		$db = new MySQL();
		$qCegs = "SELECT tbl_cegs.*, tbl_villages.village_name, 
					tbl_users.fullname, tbl_subcounties.subcounty_name, 
					tbl_parishes.parish_name, tbl_districts.district_name
                   FROM tbl_assign_cegs
                   LEFT JOIN tbl_cegs ON tbl_cegs.ceg_id = tbl_assign_cegs.ceg_id
                   LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_cegs.village_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id
                   LEFT JOIN tbl_users ON tbl_users.user_id = tbl_cegs.facilitator_id
                   WHERE 1
                   ";

        if($userId)
        	$qCegs .= "AND tbl_assign_cegs.user_id = '$userId'";

        $arrCegs = $db->QueryArray($qCegs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CEG query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrCegs;
	   	}
	   	else
	   	{
	   		return array();
	   	}
    }

    /*****************************************************************
	This function retrieves the beneficiaries of CEGs assigned to a particular user
	based on their user_id. CEG assignments are saved in the tbl_assign_ceg
	table and this is where the user_id is queried to return the IDs of 
	the CEGs assigned to that user.
	*****************************************************************/
	function dbGetUserBeneficiaries($userId)
	{
		$db = new MySQL();
		$qBens = "SELECT tbl_beneficiaries.*, tbl_beneficiary_categories.category_abbr, tbl_ceg_leadership.position_name 
				 FROM tbl_beneficiaries 
				 LEFT JOIN tbl_assign_cegs ON tbl_assign_cegs.ceg_id = tbl_beneficiaries.ceg_id 
				 LEFT JOIN tbl_beneficiary_categories ON tbl_beneficiary_categories.category_id = tbl_beneficiaries.category_id
				 LEFT JOIN tbl_ceg_leadership ON tbl_ceg_leadership.position_id = tbl_beneficiaries.position_id
				 WHERE 1
                   ";

        if($userId)
        	$qBens .= "AND tbl_assign_cegs.user_id = '$userId'";

        $qBens .= " GROUP BY tbl_beneficiaries.beneficiary_id";

        $arrBens = $db->QueryArray($qBens, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Beneficiary query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrBens;
	   	}
	   	else
	   	{
	   		return array();
	   	}
    }

	function dbGetComponentProgress($cegId)
	{
		$db = new MySQL();
		$qProg = "SELECT a.progress_id, a.ceg_id, a.unit_id , 
					a.unit_status,	a.status_date, 
					tbl_component_units.unit_name, tbl_components.component_name
                   FROM tbl_component_progress AS a
                   LEFT JOIN tbl_component_units ON tbl_component_units.unit_id = a.unit_id
                   LEFT JOIN tbl_components ON tbl_components.component_id = tbl_component_units.component_id
                   INNER JOIN (
                        SELECT tbl_component_progress.unit_id, MAX(tbl_component_progress.status_date) status_date
                        FROM tbl_component_progress
                        GROUP BY tbl_component_progress.unit_id
                    ) AS b ON a.unit_id = b.unit_id AND a.status_date = b.status_date
                   WHERE a.ceg_id = '$cegId'  
                   ORDER BY a.unit_id
                   ";

	    $arrProg = $db->QueryArray($qProg, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Progress query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrProg;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetAllFacilitators($options = null)
	{
		$db = new MySQL();
		$qFacs = "SELECT tbl_facilitators.*, tbl_users.fullname
                   FROM tbl_facilitators
                   LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitators.user_id
                   LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   WHERE 1
                   ";
        if(!empty($options))
        {
        	if($options['subcounty_id'])
        		$qFacs .= "AND tbl_subcounties.subcounty_id = '" . $options['subcounty_id'] . "' ";
        }

        $qFacs .= " GROUP BY tbl_facilitators.user_id";

	    $arrFacs = $db->QueryArray($qFacs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrFacs;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetAllFacilitatorsTrained($options)
	{
		$db = new MySQL();
		if($options['subcounty_id'] < 1)
			$options['subcounty_id'] = 0;

		$qFacs = "SELECT tbl_facilitators.*, tbl_users.fullname
                   FROM tbl_facilitators
                   LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitators.user_id
                   LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   WHERE tbl_subcounties.subcounty_id = '" . $options['subcounty_id'] . "' 
                   ";
        // if(!empty($options))
        // {
        // 	if($options['subcounty_id'])
        // 		$qFacs .= "AND tbl_subcounties.subcounty_id = '" . $options['subcounty_id'] . "' ";
        // }

        $qFacs .= " GROUP BY tbl_facilitators.user_id";

	    $arrFacs = $db->QueryArray($qFacs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator query error: " . $db->Error());

	    $qCourses = "SELECT tbl_training_courses.*
                   FROM tbl_training_courses
                   WHERE FIND_IN_SET('1', tbl_training_courses.course_group)
                   ";
       	$arrCourses = $db->QueryArray($qCourses, MYSQLI_ASSOC);

	   if($db->RowCount())
	   {
	   	return array("facilitators" => $arrFacs, "courses" => $arrCourses);
	   }
	   else
	   {
	   	return array();
	   }
	}



function dbGetAllFacilitatorRenumeration($options)
	{
		$db = new MySQL();
		if($options['subcounty_id'] < 1)
			$options['subcounty_id'] = 0;

		$qFacs = "SELECT tbl_facilitator_remuneration.*, tbl_users.fullname
                   FROM tbl_facilitator_remuneration
                   LEFT JOIN tbl_users ON tbl_users.user_id = tbl_facilitator_remuneration.facilitator_id
                   LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_facilitators.village_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   WHERE tbl_subcounties.subcounty_id = '" . $options['subcounty_id'] . "' 
                   ";
        // if(!empty($options))
        // {
        // 	if($options['subcounty_id'])
        // 		$qFacs .= "AND tbl_subcounties.subcounty_id = '" . $options['subcounty_id'] . "' ";
        // }

        $qFacs .= " GROUP BY tbl_facilitator_remuneration.row_id";

	    $arrFacs = $db->QueryArray($qFacs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Facilitator query error: " . $db->Error());

	    $qCourses = "SELECT tbl_training_courses.*
                   FROM tbl_training_courses
                   WHERE FIND_IN_SET('1', tbl_training_courses.course_group)
                   ";
       	$arrCourses = $db->QueryArray($qCourses, MYSQLI_ASSOC);

	   if($db->RowCount())
	   {
	   	return array("facilitators" => $arrFacs, "courses" => $arrCourses);
	   }
	   else
	   {
	   	return array();
	   }
	}


	function dbGetCLCCoordinators($options = null)
	{
		$db = new MySQL();
		$qCoords = "SELECT tbl_clc_coordinators.*, tbl_users.fullname
                   FROM tbl_clc_coordinators
                   LEFT JOIN tbl_users ON tbl_users.user_id = tbl_clc_coordinators.user_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_clc_coordinators.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   WHERE 1
                   ";
        if(!empty($options))
        {
        	if($options['subcounty_id'])
        		$qCoords .= "AND tbl_subcounties.subcounty_id = '" . $options['subcounty_id'] . "' ";
        }

	    $arrCoords = $db->QueryArray($qCoords, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC Coordinator query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrCoords;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetCLCCoordinatorsTraining($options = null)
	{
		$db = new MySQL();
		$qCoords = "SELECT tbl_clc_coordinators.*, tbl_users.fullname
                   FROM tbl_clc_coordinators
                   LEFT JOIN tbl_users ON tbl_users.user_id = tbl_clc_coordinators.user_id
                   LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_clc_coordinators.parish_id
                   LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
                   WHERE 1
                   ";
        if(!empty($options))
        {
        	if($options['subcounty_id'])
        		$qCoords .= "AND tbl_subcounties.subcounty_id = '" . $options['subcounty_id'] . "' ";
        }

	    $arrCoords = $db->QueryArray($qCoords, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC Coordinator query error: " . $db->Error());

	    $qCourses = "SELECT tbl_training_courses.*
                   FROM tbl_training_courses
                   WHERE FIND_IN_SET('1', tbl_training_courses.course_group)
                   ";
       	$arrCourses = $db->QueryArray($qCourses, MYSQLI_ASSOC);

	   	if($db->RowCount())
	   	{
	   		//return $arrCoords;
	   		return array("coordinators" => $arrCoords, "courses" => $arrCourses);
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetInstructors($options = null)
	{
		$db = new MySQL();
		$qInstructors = "SELECT tbl_instructors.instructor_id, tbl_users.full_name, 
					  tbl_academies.academy_name
                   FROM tbl_instructors
                   LEFT JOIN tbl_users ON tbl_users.user_id = tbl_instructors.user_id
                   LEFT JOIN tbl_academies ON tbl_academies.academy_id = tbl_instructors.academy_id
                   ";
	    $arrInstructors = $db->QueryArray($qInstructors, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Instructor query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrInstructors;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetComponentUnits($componentId)
	{
		$db = new MySQL();
		$qUnits = "SELECT tbl_component_units.*
					FROM tbl_component_units
					WHERE tbl_component_units.component_id = '$componentId'
					";
		$arrUnits = $db->QueryArray($qUnits, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Unit query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrUnits;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetCompleteComponentUnits($componentId, $cegId)
	{
		$db = new MySQL();
		$qUnits = "SELECT tbl_component_progress.*, tbl_component_units.unit_name
					FROM tbl_component_progress
					LEFT JOIN tbl_component_units ON tbl_component_units.unit_id = tbl_component_progress.unit_id
					WHERE tbl_component_units.component_id = '$componentId' 
					AND tbl_component_progress.unit_status = 'COMPLETE'
					AND tbl_component_progress.ceg_id = '$cegId'
					";
		$arrUnits = $db->QueryArray($qUnits, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Unit query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrUnits;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetCegActivities($cegId)
	{
		$db = new MySQL();
		$qActs = "SELECT tbl_ceg_activities.*, tbl_activities.activity_name, tbl_farm_enterprises.enterprise_name
					FROM tbl_ceg_activities
					LEFT JOIN tbl_activities ON tbl_activities.activity_id = tbl_ceg_activities.activity_id
					LEFT JOIN tbl_farm_enterprises ON tbl_farm_enterprises.enterprise_id = tbl_ceg_activities.enterprise_id
					WHERE tbl_ceg_activities.ceg_id = '$cegId' 
					";
		$arrActs = $db->QueryArray($qActs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Activity query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrActs;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetActivities()
	{
		$db = new MySQL();
		$qActs = "SELECT tbl_activities.*
					FROM tbl_activities
					";
		$arrActs = $db->QueryArray($qActs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Activity query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrActs;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetFarmEnterprises()
	{
		$db = new MySQL();
		$qEnts = "SELECT tbl_farm_enterprises.*
					FROM tbl_farm_enterprises
					";
		$arrEnts = $db->QueryArray($qEnts, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Enterprise query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrEnts;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetQualitativeDataTypes()
	{
		$db = new MySQL();
		$qTypes = "SELECT tbl_qualitative_data_types.*
					FROM tbl_qualitative_data_types
					";
		$arrTypes = $db->QueryArray($qTypes, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Type query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrTypes;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetQualitativeData($options = null)
	{
		$db = new MySQL();
		$qData = "SELECT tbl_qualitative_data.*, tbl_qualitative_data_types.type_name
					FROM tbl_qualitative_data
					LEFT JOIN tbl_qualitative_data_types ON tbl_qualitative_data_types.type_id = tbl_qualitative_data.data_type
					WHERE 1
					";

		if(isset($options['user_id']))
			$qData .= "AND tbl_qualitative_data.user_id = '".$options['user_id']."'";

		if(isset($options['quarter_id']))
			$qData .= "AND tbl_qualitative_data.quarter_id = '".$options['quarter_id']."'";

		$arrData = $db->QueryArray($qData, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Type query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrData;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetVSLA($options)
	{
		$db = new MySQL();
		$qVsla = "SELECT tbl_vslas.*
					FROM tbl_vslas
					WHERE 1 
					";

		if($options['ceg_id'])
			$qVsla .= " AND tbl_vslas.ceg_id = '" . $options['ceg_id'] . "' ";

		$arrVsla = $db->QuerySingleRowArray($qVsla, MYSQLI_ASSOC);
	    if($db->Error())
	        die("VSLA query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		// Get contributions
	   		$qContribs = "SELECT tbl_vsla_contributions.*
	   					  FROM tbl_vsla_contributions
	   					  WHERE tbl_vsla_contributions.vsla_id = '" . $arrVsla['vsla_id'] . "' ";
	   		$arrContribs = $db->QueryArray($qContribs, MYSQLI_ASSOC);

	   		if($db->Error())
	   			die("Contribution query error: " . $db->Error());

	   		// Get Loans
	   		$qLoans = "SELECT tbl_vsla_loans.*, tbl_beneficiaries.beneficiary_name
	   					  FROM tbl_vsla_loans
	   					  LEFT JOIN tbl_beneficiaries ON tbl_beneficiaries.beneficiary_id = tbl_vsla_loans.beneficiary_id
	   					  WHERE tbl_vsla_loans.vsla_id = '" . $arrVsla['vsla_id'] . "' ";
	   		$arrLoans = $db->QueryArray($qLoans, MYSQLI_ASSOC);

	   		if($db->Error())
	   			die("Contribution query error: " . $db->Error());

	   		if($db->RowCount())
	   		{
	   			$arrVsla['contributions'] = $arrContribs;
	   			$arrVsla['loans'] = $arrLoans;
	   		}

	   	return $arrVsla;
	   }
	   else
	   {
	   	return array();
	   }
	} 

	function dbGetLoanDetails($loanId)
	{
		$db = new MySQL();
		$qLoan = "SELECT tbl_vsla_loans.*, tbl_beneficiaries.beneficiary_name
				  FROM tbl_vsla_loans
				  LEFT JOIN tbl_beneficiaries ON tbl_beneficiaries.beneficiary_id = tbl_vsla_loans.beneficiary_id
				  WHERE tbl_vsla_loans.loan_id = '$loanId'
				 ";
		$arrLoan = $db->QuerySingleRowArray($qLoan, MYSQLI_ASSOC);

		 if($db->Error())
		 	die("Loan detail query error: " . $db->Error());

		if($db->RowCount())
		{
			// Get loan payments
			$qPayments = "SELECT tbl_vsla_loan_payments.*
						  FROM tbl_vsla_loan_payments
						  WHERE tbl_vsla_loan_payments.loan_id = '$loanId'
						  ";
			$arrPayments = $db->QueryArray($qPayments, MYSQLI_ASSOC);

			if($db->RowCount())
			{
				$arrLoan['payments'] = $arrPayments;
			}
			else
			{
				$arrLoan['payments'] = array();
			}
		}

		return $arrLoan;
	}

	function dbGetBeneficiaryLoans($benId)
	{
		$db = new MySQL();
		$qLoan = "SELECT tbl_vsla_loans.*, tbl_beneficiaries.beneficiary_name
				  FROM tbl_vsla_loans
				  LEFT JOIN tbl_beneficiaries ON tbl_beneficiaries.beneficiary_id = tbl_vsla_loans.beneficiary_id
				  WHERE tbl_vsla_loans.beneficiary_id = '$benId'
				 ";
		$arrLoans = $db->QueryArray($qLoan, MYSQLI_ASSOC);

		 if($db->Error())
		 	die("Loan detail query error: " . $db->Error());

		if($db->RowCount())
		{
			$j = 0;
			// Get loan payments
			foreach($arrLoans as $loan)
			{
				$qPayments = "SELECT tbl_vsla_loan_payments.*
						  FROM tbl_vsla_loan_payments
						  WHERE tbl_vsla_loan_payments.loan_id = '".$loan['loan_id']."'
						  ";
				$arrPayments = $db->QueryArray($qPayments, MYSQLI_ASSOC);

				if($db->RowCount())
					$arrLoans[$j]['payments'] = $arrPayments;

				$j++;
			}
			
			return $arrLoans;
		}
		else
		{
			return array();
		}

		
	}

	function dbGetVSLAContributionHeaders($options)
	{
		$db = new MySQL();
		$qVsla = "SELECT tbl_vslas.*
					FROM tbl_vslas
					WHERE 1 
					";

		if($options['ceg_id'])
			$qVsla .= " AND tbl_vslas.ceg_id = '" . $options['ceg_id'] . "' ";

		$arrVsla = $db->QuerySingleRowArray($qVsla, MYSQLI_ASSOC);
	    if($db->Error())
	        die("VSLA query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		// Get contributions
	   		$qContribs = "SELECT tbl_vsla_contributions.*, 
	   						AVG(contribution_amount) AS contribution_amount, 
	   						SUM(contribution_amount) AS total_contribution
							FROM tbl_vsla_contributions
							WHERE tbl_vsla_contributions.vsla_id = '" . $arrVsla['vsla_id'] . "'
							GROUP BY tbl_vsla_contributions.contribution_date 
							ORDER BY tbl_vsla_contributions.contribution_date ASC
							";
	   		$arrContribs = $db->QueryArray($qContribs, MYSQLI_ASSOC);

	   		if($db->Error())
	   			die("Contribution query error: " . $db->Error());

	   		if($db->RowCount())
	   		{
	   			$arrVsla['contributions'] = $arrContribs;
	   		}

	   	return $arrVsla;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetGlossary($options = null)
	{
		$db = new MySQL();
		$qGlossary = "SELECT tbl_glossary.*
					FROM tbl_glossary
					WHERE 1 
					";

		if($options['keyword'])
			$qGlossary .= " AND tbl_glossary.keyword LIKE '%" . $options['keyword'] . "%' ";

		$qGlossary .= " ORDER BY tbl_glossary.keyword ASC";

		$arrGlossary = $db->QueryArray($qGlossary, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Glossary query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrGlossary;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}	

	function dbGetBudgetDetails($options)
	{
		$db = new MySQL();
		$qBudget = "SELECT tbl_budgets.*, tbl_budget_categories.category_name, 
						tbl_subcounties.subcounty_name, tbl_districts.district_name
					FROM tbl_budgets
					LEFT JOIN tbl_budget_categories ON tbl_budget_categories.category_id = tbl_budgets.category_id
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_budgets.subcounty_id
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id
					WHERE 1 
					";

		if($options['budget_id'])
			$qBudget .= " AND tbl_budgets.budget_id = '" . $options['budget_id'] . "' ";

		$arrBudget = $db->QueryArray($qBudget, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Budget query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		// Get details
	   		$qDetails = "SELECT tbl_budget_details.*
	   					  FROM tbl_budget_details
	   					  WHERE tbl_budget_details.budget_id = '" . $options['budget_id'] . "' ";
	   		$arrDetails = $db->QueryArray($qDetails, MYSQLI_ASSOC);

	   		if($db->Error())
	   			die("Budget detail error: " . $db->Error());

	   		if($db->RowCount())
	   		{
	   			$arrBudget['details'] = $arrDetails;
	   		}

	   	return $arrBudget;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetBudgets($options = null)
	{
		$db = new MySQL();
		$qBudgets = "SELECT tbl_budgets.*, tbl_budget_categories.category_name, 
						tbl_subcounties.subcounty_name
					FROM tbl_budgets
					LEFT JOIN tbl_budget_categories ON tbl_budget_categories.category_id = tbl_budgets.category_id
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_budgets.subcounty_id
					WHERE 1 
					";

		if($options['budget_id'])
			$qBudgets .= " AND tbl_budgets.budget_id = '" . $options['budget_id'] . "' ";

		$arrBudgets = $db->QueryArray($qBudgets, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Budget query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrBudgets;
	   	}
	   	else
	   	{
	   		return array();
	   	}

	}

	function dbGetBudgetCategories($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_budget_categories.*
                   FROM tbl_budget_categories
                   WHERE 1
                   ";
        if($options['category_id'])
			$qCats .= " AND tbl_budget_categories.category_id = '" . $options['category_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Budget query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
	
	function dbGetContributions($options = null)
	{
		$db = new MySQL();
		$qContribs = "SELECT tbl_contributions.*, tbl_contribution_categories.category_name, 
						tbl_contribution_sources.source_name						
					FROM tbl_contributions
					LEFT JOIN tbl_contribution_categories ON tbl_contribution_categories.category_id = tbl_contributions.category_id
					LEFT JOIN tbl_contribution_sources ON tbl_contribution_sources.source_id = tbl_contributions.source_id
					WHERE 1 
					";

		if($options['contribution_id'])
			$qContribs .= " AND tbl_contributions.contribution_id = '" . $options['contribution_id'] . "' ";

		$arrContribs = $db->QueryArray($qContribs, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Budget query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrContribs;
	   	}
	   	else
	   	{
	   		return array();
	   	}

	}

	function dbGetContributionCategories($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_contribution_categories.*
                   FROM tbl_contribution_categories
                   WHERE 1
                   ";
        if($options['category_id'])
			$qCats .= " AND tbl_contribution_categories.category_id = '" . $options['category_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Contribution query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetContributionSources($options = null)
	{
		$db = new MySQL();
		$qSources = "SELECT tbl_contribution_sources.*
                   FROM tbl_contribution_sources
                   WHERE 1
                   ";
        if($options['source_id'])
			$qSources .= " AND tbl_contribution_sources.source_id = '" . $options['source_id'] . "' ";

	    $arrSources = $db->QueryArray($qSources, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Source query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrSources;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetExpenses($options = null)
	{
		$db = new MySQL();
		$qExpenses = "SELECT tbl_expenses.*, tbl_budget_categories.category_name, 
						tbl_subcounties.subcounty_name, tbl_districts.district_name
					FROM tbl_expenses
					LEFT JOIN tbl_budget_categories ON tbl_budget_categories.category_id = tbl_expenses.category_id
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_expenses.subcounty_id
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_expenses.district_id
					WHERE 1 
					";

		if($options['expense_id'])
			$qExpenses .= " AND tbl_expenses.expense_id = '" . $options['expense_id'] . "' ";

		$arrExpenses = $db->QueryArray($qExpenses, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Expense query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrExpenses;
	   	}
	   	else
	   	{
	   		return array();
	   	}

	}

	function dbGetExpenseDetails($options)
	{
		$db = new MySQL();
		$qExpense = "SELECT tbl_expenses.*, tbl_budget_categories.category_name, 
						tbl_subcounties.subcounty_name, tbl_districts.district_name
					FROM tbl_expenses
					LEFT JOIN tbl_budget_categories ON tbl_budget_categories.category_id = tbl_expenses.category_id
					LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_expenses.subcounty_id
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_expenses.district_id
					WHERE 1 
					";

		if($options['expense_id'])
			$qExpense .= " AND tbl_expenses.expense_id = '" . $options['expense_id'] . "' ";

		$arrExpense = $db->QueryArray($qExpense, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Expense query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		// Get details
	   		$qDetails = "SELECT tbl_expense_details.*
	   					  FROM tbl_expense_details
	   					  WHERE tbl_expense_details.expense_id = '" . $options['expense_id'] . "' ";
	   		$arrDetails = $db->QueryArray($qDetails, MYSQLI_ASSOC);

	   		if($db->Error())
	   			die("Expense detail error: " . $db->Error());

	   		if($db->RowCount())
	   		{
	   			$arrExpense['details'] = $arrDetails;
	   		}

	   	return $arrExpense;
	   }
	   else
	   {
	   	return array();
	   }
	}

//-----------Added by Achilley Kiwanuka S----16-mar-2021

//-----GRaphs, Charts and Maps------
//---Beneficiary Savings Graph
function BeneficiarySavingsGraph()
	{
		$db = new MySQL();
		$sql = "SELECT substr(`contribution_date`,1,7) as month,count(`beneficiary_id`) as saving FROM `tbl_vsla_contributions` WHERE 1 group by substr(`contribution_date`,1,7) 
					";

		 $arrQuery = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Graph query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuery;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
	//---Amount of Savings
	function BeneficiaryAmountofSavingsGraph()
	{
		$db = new MySQL();
		$sql = "SELECT substr(`contribution_date`,1,7) as month,sum(`contribution_amount`) as saving FROM `tbl_vsla_contributions` WHERE 1 group by substr(`contribution_date`,1,7) 
					";

		 $arrQuery = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Graph query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuery;
	   }
	   else
	   {
	   	return array();
	   }
	}
	//----No of Loans
	
	//---Amount of Savings
	function BeneficiaryNoofLoansGraph()
	{
		$db = new MySQL();
		$sql = "SELECT substr(`date_issued`,1,7) as month,sum(`beneficiary_id`) as saving FROM `tbl_vsla_loans` WHERE 1 group by substr(`date_issued`,1,7) 
					";

		 $arrQuery = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Graph query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuery;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
	
	
	
	
	//---Amount of Loans
	function BeneficiaryAmountofLoansGraph()
	{
		$db = new MySQL();
		$sql = "SELECT substr(`date_issued`,1,7) as month,sum(`principal`) as saving FROM `tbl_vsla_loans` WHERE 1 group by substr(`date_issued`,1,7) 
					";

		 $arrQuery = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Graph query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuery;
	   }
	   else
	   {
	   	return array();
	   }
	}
	//BeneficiaryNoofLoansClearedGraph
	function BeneficiaryNoofLoansClearedGraph()
	{
		$db = new MySQL();
		$sql = "SELECT substr(`date_issued`,1,7) as month,sum(`beneficiary_id`) as saving FROM `tbl_vsla_loans` WHERE loan_status='Grace' group by substr(`date_issued`,1,7) 
					";

		 $arrQuery = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Graph query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuery;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
	//BeneficiaryValueofLoansClearedGraph
	
	function BeneficiaryValueofLoansClearedGraph()
	{
		$db = new MySQL();
		$sql = "SELECT substr(`date_issued`,1,7) as month,sum(`principal`) as saving FROM `tbl_vsla_loans` WHERE loan_status='Grace' group by substr(`date_issued`,1,7) 
					";

		 $arrQuery = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Graph query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuery;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
	//BeneficiaryNoofLoansPendingGraph
	
	function BeneficiaryNoofLoansPendingGraph()
	{
		$db = new MySQL();
		$sql = "SELECT substr(`date_issued`,1,7) as month,sum(`beneficiary_id`) as saving FROM `tbl_vsla_loans` WHERE loan_status='Pending' group by substr(`date_issued`,1,7) 
					";

		 $arrQuery = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Graph query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuery;
	   }
	   else
	   {
	   	return array();
	   }
	}
	//BeneficiaryAmountofLoansPendingGraph
	
	function BeneficiaryAmountofLoansPendingGraph()
	{
		$db = new MySQL();
		$sql = "SELECT substr(`date_issued`,1,7) as month,sum(`principal`) as saving FROM `tbl_vsla_loans` WHERE loan_status='Pending' group by substr(`date_issued`,1,7) 
					";

		 $arrQuery = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Graph query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuery;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
	//FacilitatorsTrainedGraph()
	
	function FacilitatorsTrainedGraph()
	{
		$db = new MySQL();
		$sql = "SELECT tbl_training_courses.course_name,tbl_training_courses.course_id, SUM(CASE WHEN tbl_training_facilitators.attendance = '1' THEN 1 ELSE 0 END) AS attended FROM tbl_training_facilitators LEFT JOIN tbl_training_courses ON tbl_training_courses.course_id = tbl_training_facilitators.course_id WHERE 1 group by tbl_training_courses.course_name 
					";

		 $arrQuery = $db->QueryArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Graph query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrQuery;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
//-----end of Graphs------

function getIndicatorActuals($indicator_id,$quarter){
	  $db = new MySQL();
	  switch($indicator_id){
		  case 1:
		  //#of adult learners enrolled
		  $sql="select count(beneficiary_id) as actual from tbl_beneficiaries";
		  break;
		  //2 % of enrolled adult learners completing the learning cycle
		  case 2:
		   $sql="select 0 as actual from tbl_training_facilitators where 1";
		   break;
		  //3# of Facilitators trained
		  case 3:
		   $sql="select sum(attendance) as actual from tbl_training_facilitators where 1 ";
		   break;
		   //4# of Facilitators equipped with instructional materials
		   case 4:
		   $sql="select sum(attendance) as actual from tbl_training_facilitators where quarter_id='".$quarter."' ";
		   break;
		  //5 # of Facilitators remunerated
		  case 5:
		   $sql="select sum(remuneration_id) as actual from tbl_facilitator_remuneration where quarter_id='".$quarter."' ";
		   break;
		  //6 # of materials acquired and/or developed
		case 6:
		   $sql="select 0 as actual from tbl_training_facilitators where 1";
		   break;
		 //7 Types of materials acquired and/or developed and in use
		
		   case 7:
		    $sql="select 0 as actual from tbl_training_facilitators where 1";
		   break;
		   
		   // 8 # of functional learning sites
		   case 8:
		   $sql="select sum(learning_sites) as actual from tbl_facilitator_learningsites where quarter_id='".$quarter."' ";
		   break;
		   //9, '# of learners trained in green livelihood enterprises and entrepreneurship skills')
		   
/*(10, '# of learners engaged in viable green enterprises'),
(11, '# of group enterprises invested'),
(12, '# of groups funded by amounts'),*/

//13, '# of villages mobilized and sensitized'),
case 13:
		   $sql="select sum(villages_mobilized) as actual from tbl_facilitator_villagesmobilizedsensitized where quarter_id='".$quarter."' ";
		   break;

/*(14, '# of CEGs trained in mindset change'),*/
//15, '# of SITAN sessions undertaken'),
case 15:
		   $sql="select sum(sitan_sessions) as actual from tbl_facilitator_sitansessions where quarter_id='".$quarter."' ";
		   break;
 
/*(16, '# of village lists showing village priorities'),

(17, '# of parish development plans reflecting priorities from VAPs and GAPs '),
(18, '# of projects established arising from VAPs and GAPs'),*/
//19, '# of structures established '),
case 19:
		   $sql="select sum(structures_established) as actual from tbl_facilitator_structures_established where quarter_id='".$quarter."' ";
		   break;
//20, '# of implementation structures strengthened'),
case 20:
		   $sql="select sum(structures_strengthened) as actual from tbl_facilitator_structures_strengthened where quarter_id='".$quarter."' ";
		   break;

//21, '# of national level joint review and planning meetings held '),
case 21:
		   $sql="select sum(meeting_name) as actual from tbl_meetings where meeting_type=6 and quarter_id='".$quarter."' ";
		   break;

//22, '# of district level review and planning meetings held'),
case 22:
		   $sql="select sum(meeting_name) as actual from tbl_meetings where meeting_type=6 and quarter_id='".$quarter."' ";
		   break;
//23, '# of IMTC meetings conducted'),
case 23:
		   $sql="select sum(meeting_name) as actual from tbl_meetings where meeting_type=5 and quarter_id='".$quarter."' ";
		   break;
//24, '# of coordination meetings held'),
case 24:
		   $sql="select sum(meeting_name) as actual from tbl_meetings where meeting_type=3 and quarter_id='".$quarter."' ";
		   break;
//25, '# of staff trained in the implementation of ALE at all levels'),
case 24:
		   $sql="select sum(attendance) as actual from tbl_training_facilitators where quarter_id='".$quarter."' ";
		   break;
//26, '# of Facilitators trained to conduct learning sessions '),
case 26:
		   $sql="select sum(attendance) as actual from tbl_training_facilitators where quarter_id='".$quarter."' ";
		   break;
//27, '# of trainings conducted'),
case 27:
		   $sql="select count(course_id) as actual from tbl_training_facilitators where quarter_id='".$quarter."' ";
		   break;
/*(28, '# of equipment and tools procured and availed to implementers at all levels'),
(29, '% of financial to ALE in the work plans and budgets at all level '),*/
//30, 'Functional computerized database '),
case 30:
		   $sql="select 1 as actual from tbl_training_facilitators where 1 ";
		   break;
//31, '# of VSLAs established, equipped'),
case 31:
		   $sql="select count(vsla_name) as actual from tbl_vslas where 1 ";
		   break;
//32, '% of learners regularly saving and borrowing '),
case 31:
		   $sql="select count(distinct(beneficiary_id)) as actual from tbl_vsla_contributions where 1 ";
		   break;
/*33, '% of IGAs established using VSLA savings or loans'),*/
//34, '% of Facilitators trained in VSLA management'),
case 34:
		   $sql="select count(distinct(clc_name)) as actual from tbl_clcs where 1 ";
		   break;
//35, '# of CLCs established, equipped and functional'),
case 35:
		   $sql="select count(distinct(clc_name)) as actual from tbl_clcs where 1 ";
		   break;
//36, '# of CLC Coordinators assigned and trained'),
case 34:
		   $sql="select count(distinct(coordinator_id)) as actual from tbl_clc_coordinators where 1 ";
		   break;
/*(37, '# of CMCs formed and oriented'),*/
//38, '# of programs and services offered at the CLCs'),
//39, '# of people accessing programs and services at the CLCs'),
//40, '# of partnerships established at the CLCs '),
//41, '# of community score cards sessions conducted at CLCs');*/
		   
		   
		  default:
		   $sql="select 0 as actual from tbl_training_facilitators where 1";
		  break;
		  }
	  
	  $arrActuals = $db->QuerySingleRowArray($sql, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrActuals['actual'];
	   	}
	   	else
	   	{
	   		return array();
	   	}/**/
	
	  }

function dbGetBeneficiaryCategories($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_beneficiary_categories.*
                   FROM tbl_beneficiary_categories
				   WHERE 1 
                   ";
				   
				    if($options['category_id'])
			$qCats .= " AND tbl_beneficiary_categories.category_id = '" . $options['category_id'] . "' ";
	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Beneficiary query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}

//----------dbGetCLCActvities
function dbGetCLCActvities($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_clc_services.*,tbl_clc_thematicarea.*
                   FROM tbl_clc_services left join tbl_clc_thematicarea
				    on(tbl_clc_services.thematic_area=tbl_clc_thematicarea.thematic_id)
                   WHERE 1
                   ";
        if($options['category_id'])
			$qCats .= " AND tbl_clc_services.service_id = '" . $options['service_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
	//-SELECT * FROM `tbl_activities` 
	function dbGetSetupActvities($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_activities.*
                   FROM tbl_activities
                   WHERE 1
                   ";
        if($options['activity_id'])
			$qCats .= " AND tbl_activities.activity_id = '" . $options['activity_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}
	//-----dbGetCLCEventTypes--SELECT * FROM `tbl_event_types` 
	function dbGetCLCEventTypes($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_event_types.*
                   FROM tbl_event_types
                   WHERE 1
                   ";
        if($options['type_id'])
			$qCats .= " AND tbl_event_types.type_id = '" . $options['type_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}
	//-----tbl_farm_enterprises
		function dbGetCEGFarmEnterprises($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_farm_enterprises.*
                   FROM tbl_farm_enterprises
                   WHERE 1
                   ";
        if($options['enterprise_id'])
			$qCats .= " AND tbl_farm_enterprises.enterprise_id = '" . $options['enterprise_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
	//------db get Components
	
	function dbGetComponents($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_components.*
                   FROM tbl_components
                   WHERE 1
                   ";
        if($options['component_id'])
			$qCats .= " AND tbl_components.component_id = '" . $options['component_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Component query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
	
	
	
	//-----tbl_clc_partnerships SELECT * FROM `tbl_clc_partnerships` 
	//---------manage-partnerships
	function dbGetPartnerships($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_clc_partnerships.*
                   FROM tbl_clc_partnerships
                   WHERE 1
                   ";
        if($options['partnership_id'])
			$qCats .= " AND tbl_clc_partnerships.partnership_id = '" . $options['partnership_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}
	
//SELECT * FROM `tbl_beneficiary_categories` 


function dbGetBeneficiaryCategory($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_beneficiary_categories.*
                   FROM tbl_beneficiary_categories
                   WHERE 1
                   ";
        if($options['category_id'])
			$qCats .= " AND tbl_beneficiary_categories.category_id = '" . $options['category_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}
//---SELECT * FROM `tbl_partners`

function dbGetCLCPartners($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_partners.*
                   FROM tbl_partners
                   WHERE 1
                   ";
        if($options['partner_id'])
			$qCats .= " AND tbl_partners.partner_id = '" . $options['partner_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}

//----CLC Thematic Area
function dbGetCLCThematicArea($options = null)
	{
		$db = new MySQL();
		$qCats = "SELECT tbl_clc_thematicarea.*
                   FROM tbl_clc_thematicarea
                   WHERE 1
                   ";
        if($options['thematic_id'])
			$qCats .= " AND tbl_clc_thematicarea.thematic_id = '" . $options['thematic_id'] . "' ";

	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("CLC query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}
 function filterThematicArea($options=NULL){
	 
		$db = new MySQL();
		$qCats = "SELECT tbl_clc_thematicarea.*
                   FROM tbl_clc_thematicarea
                   WHERE 1
                   ";
        $data="";
	    while($arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC)){
		$sel=$arrCats['thematic_id']==$options?"SELECTED":"";
		$data.="<option value=\"".$arrCats['thematic_id']."\" ".$sel." >".$arrCats['thematic_name']."</option>";
		
		}
	    
	   	return $data;
	  
	   }
	
	 
//-------end of Items added by AK
?>