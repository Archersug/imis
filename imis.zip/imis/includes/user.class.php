<?php
	/**
	 * 
	 */
	class User
	{
		private $username = "";
		private $password = "";
		private $email = "";
		private $phone = "";
		private $pin = "";
		private $userStatus = "";
		
		public function __construct()
		{
			# code...
		}

		public function login($email, $pword)
		{
			if($email && $pword)
			{
				$db = new MySQL(true);
				$email = MySQL::SQLValue($email);

				$qUser = "SELECT tbl_users.user_id, tbl_users.username, tbl_users.phone, tbl_users.status,
								 tbl_users.email, tbl_users.fullname, tbl_users.password,
								 tbl_users.usergroup_id, tbl_usergroups.usergroup_name
						  FROM tbl_users
						  LEFT JOIN tbl_usergroups ON tbl_usergroups.usergroup_id = tbl_users.usergroup_id
						  WHERE tbl_users.email = $email
						  AND tbl_users.password = '" .md5($pword) . "'
						  ";
				$res = $db->QuerySingleRowArray($qUser);

				if($db->Error())
					die("User query error: " . $db->Error());

				if($db->RowCount())
				{
					if($res['status'] == 'ACTIVE')
					{
						$arrAssignments = dbGetUserAssignments($res['user_id']);
						$_SESSION['USER'] = array(
												'SUCCESS' => true, 
												'USERNAME' => $res['username'],
												'FULLNAME' => $res['fullname'],
												'USERGROUPID' => $res['usergroup_id'],
												'USERGROUPNAME' => $res['usergroup_name'],
												'ICOLEW_USERID' => $res['user_id'],
												'ASSIGNMENTS' => $arrAssignments
											);

						return array('SUCCESS' => true);
					}
					else
					{
						$_SESSION['loginMessage'] = "Your account has been suspended!";
						return $arrResponse = array(
												'SUCCESS' => false, 
												'MESSAGE' => 'Your account has been suspended!'
											);
					}
					
				}
				else
				{
					$_SESSION['loginMessage'] = "Invalid email address and/or password";
					return $arrResponse = array(
												'SUCCESS' => false, 
												'MESSAGE' => 'Invalid email address and/or password'
											);
				}

			}
			else
			{	
				$_SESSION['loginMessage'] = "Please provide an email address and password";
				return $arrResponse = array('SUCCESS' => false, 'MESSAGE' => 'Please provide an email address and password' );
			}
			
		}

		public function userLogout()
		{

		}

		public function userGetPin()
		{

		}

		public function userSetPassword()
		{

		}
	}
?>