<?php
	/*******************************************************
	Include only the relevant css files in index.php
	*******************************************************/
	$arrCssFiles = [];
	switch ($displayedPage['file']) 
	{
		case 'dashboard.php':
		case 'dashboard-mne.php':
		case 'dashboard-technical.php':
			// Page Vendor
    		$arrCssFiles[] = '<link rel="stylesheet" href="'.$ROOT_FOLDER.'assets/css/dashforge.dashboard.css">';
    		
			break;

		case 'usergroups.php':
		case 'users.php':
		case 'regions.php':
		case 'subregions.php':
		case 'districts.php':
		case 'counties.php':
		case 'subcounties.php':
		case 'parishes.php':
		case 'villages.php':
		case 'components.php':
		case 'beneficiaries.php':
		case 'cegs.php':
		case 'clcs.php':
		case 'budgets.php':
		case 'expenses.php':
		case 'contributions.php':
		case 'audit-trail.php':
		case 'contribution-sources.php':
		case 'cegs-profile.php':
			$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'lib/datatables.net-dt/css/jquery.dataTables.min.css" rel="stylesheet">';
    		$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css" rel="stylesheet">';
    		$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'lib/typicons.font/typicons.css" rel="stylesheet">';
    		$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'lib/prismjs/themes/prism-vs.css" rel="stylesheet">';
    		break;

    	case 'cegs-profile.php':
    	case 'clcs-profile.php':
    	case 'beneficiaries-profile.php':
    	case 'components-view.php':
    	case 'users-profile.php':
    		$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'assets/css/dashforge.profile.css" rel="stylesheet">';
    		break;
    	case 'documents.php':
    		$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'assets/css/dashforge.filemgr.css" rel="stylesheet">';
    		break;
    	case 'inbox.php':
    		$arrCssFiles[] = '<link rel="stylesheet" href="'.$ROOT_FOLDER.'assets/css/dashforge.mail.css">';
    		$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'lib/quill/quill.core.css" rel="stylesheet">';
    		$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'lib/quill/quill.snow.css" rel="stylesheet">';
    		break;
    	case 'configure-approvals.php':
    		$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'lib/prismjs/themes/prism-vs.css" rel="stylesheet">';
    		$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'lib/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">';
    		break;
		default:
			# code...
			break;
	}

	$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'assets/css/dashforge.demo.css" rel="stylesheet">';
	$arrCssFiles[] = '<link href="'.$ROOT_FOLDER.'lib/select2/css/select2.min.css" rel="stylesheet">';

	if(!empty($arrCssFiles))
	{
		foreach ($arrCssFiles as $key => $file) 
		{
			echo $file . "\n\t";
		}
	}
?>