<?php
	if(!isset($_SESSION['USER']))
		session_start();

	//include("app-config.php");
	include("mysql.class.php");
	include("functions-standard.php");
	include("functions-custom.php");
	include("router.class.php");
	include("user.class.php");

	$arrProjectSettings = dbGetProjectSettings();
?>