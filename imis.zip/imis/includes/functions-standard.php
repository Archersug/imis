<?php
	function auditTrail($action)
	{
		$db = new MySQL(true);
		
		$today = date("Y-m-d H:i:s");
		//Receive and prepare values for mysql insertion
		$values = array();
		$values["user_id"] = MySQL::SQLValue($_SESSION['USER']['ICOLEW_USERID']);
		$values["user_name"] = MySQL::SQLValue($_SESSION['USER']['FULLNAME']);
		$values["audit_action"] = MySQL::SQLValue($action);
		$values["audit_date"]  = MySQL::SQLValue($today); 
			
		// Execute the insert for user group details
		if(!$result = $db->InsertRow("tbl_audit_trail", $values))
			die("Audit trail Error: " . $db->Error());
	}

	function getFinancialYear()
	{
		$currentYear = date("Y");
		$today = date("Y-m-d", strtotime("88 days ago"));

		if($today < $currentYear."-07-01")
			$finYear = ($currentYear - 1) . "/" . $currentYear;
		else
			$finYear = $currentYear . "/" . ($currentYear + 1);

		return $finYear;
	}

	function updateCurrentReportingQuarter($quarterId = NULL)
	{
		$db = new MySQL(true);
		$today = date("Y-m-d H:i:s");

		// Get current reporting quarter
		$qCurrentQuarter = "SELECT tbl_quarters.*
							FROM tbl_quarters
							WHERE tbl_quarters.quarter_status = 'OPEN'
							";
		$arrCurrentQuarter = $db->QuerySingleRowArray($qCurrentQuarter, MYSQLI_ASSOC);

		if($quarterId)
		{

		}
		else
		{
			if($db->RowCount()) // If there is a current reporting quarter
			{
				// Check if today is greater than current quarter's last day
				if(strtotime($today) > strtotime($arrCurrentQuarter['quarter_deactivated'] . " 23:59:59"))
				{
					// Close the old quarter
					$values = array();
					$whereArray = array();
					$values['quarter_status'] = MySQL::SQLValue('CLOSED');
					$whereArray['quarter_id'] = MySQL::SQLValue($arrCurrentQuarter['quarter_id']);
					$qUpdate = $db->BuildSQLUpdate("tbl_quarters",$values,$whereArray);
					if(!$result = $db->Query($qUpdate))
						$db->Error();

					// New quarter array
					$financialYear = getFinancialYear();
					$startingMonth = date("M", strtotime("-3 months"));
					$endingMonth = date("M", strtotime("-1 months"));
					$startingDate = date("Y-m-d", strtotime("- 3 months"));
					$endingDate = date("Y-m-d", strtotime("last day of $startingDate + 2 months"));
					$activationDate = date("Y-m-d");
					$deactivationDate = date("Y-m-d", strtotime("last day of " . date("M", strtotime("+ 2 months"))));

					$name = $startingMonth . " - " . $endingMonth . " ($financialYear)";
					$arrQuarter = array(
									'quarter_name' => $name,
									'quarter_start' => $startingDate,
									'quarter_stop' => $endingDate,
									'quarter_status' => 'OPEN',
									'quarter_activated' => $activationDate,
									'quarter_deactivated' => $deactivationDate
								);

					// Insert new quarter
					$result = dbSaveTable(
								array("table_name" => "tbl_quarters", 
										"table_data" => $arrQuarter, 
										"primary_field" => "quarter_id", 
										"primary_data" => "NULL"
									)
								);
					

					echo "Quarter successfuly set!";
				}
				else
				{
					echo "Still in quarter";
				}
			}
			else // If there isn't any
			{
				// New quarter array
				$financialYear = getFinancialYear();
				$startingMonth = date("M", strtotime("-3 months"));
				$endingMonth = date("M", strtotime("-1 months"));
				$startingDate = date("Y-m-d", strtotime("- 3 months"));
				$endingDate = date("Y-m-d", strtotime("last day of $startingDate + 2 months"));
				$activationDate = date("Y-m-d");
				$deactivationDate = date("Y-m-d", strtotime("last day of " . date("M", strtotime("+ 2 months"))));

				$name = $startingMonth . " - " . $endingMonth . " ($financialYear)";
				$arrQuarter = array(
								'quarter_name' => $name,
								'quarter_start' => $startingDate,
								'quarter_stop' => $endingDate,
								'quarter_status' => 'OPEN',
								'quarter_activated' => $activationDate,
								'quarter_deactivated' => $deactivationDate
							);

				// Insert new quarter
				$result = dbSaveTable(
							array("table_name" => "tbl_quarters", 
									"table_data" => $arrQuarter, 
									"primary_field" => "quarter_id", 
									"primary_data" => "NULL"
								)
							);
				echo "No current quarter. New one set.";
			}
		}
	}

	function getInboxMessages($options = NULL)
	{
		$db = new MySQL();
	    $qMessages = "SELECT tbl_inbox_messages.*, Senders.fullname as sender, 
	    				Receivers.fullname as receiver, tbl_usergroups.usergroup_name
	              FROM tbl_inbox_messages
	              LEFT JOIN tbl_users Senders ON Senders.user_id = tbl_inbox_messages.sender_id
	              LEFT JOIN tbl_users Receivers ON Receivers.user_id = tbl_inbox_messages.receiver_id
	              LEFT JOIN tbl_usergroups ON tbl_usergroups.usergroup_id = Senders.usergroup_id
	              WHERE 1	                   ";

	    if(isset($options['message_id']))
	    {
	    	$qMessages .= " AND tbl_inbox_messages.message_id = '" . $options['message_id'] . "'";

	    	// update message status
			$values = array();
			$whereArray = array();
			$values['read_status'] = MySQL::SQLValue('1');
			$whereArray['message_id'] = MySQL::SQLValue($options['message_id']);
			$qUpdate = $db->BuildSQLUpdate("tbl_inbox_messages",$values,$whereArray);
			if(!$result = $db->Query($qUpdate))
				$db->Error();
	    }

	    if(isset($options['receiver_id']))
	    	$qMessages .= " AND tbl_inbox_messages.receiver_id = '" . $options['receiver_id'] . "'";

	    $qMessages .= " ORDER BY tbl_inbox_messages.message_date DESC";

	    $arrMessages = $db->QueryArray($qMessages, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Message query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrMessages;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function getInboxNotifications($options)
	{
		$db = new MySQL();
	    $qNotifications = "SELECT tbl_inbox_messages.message_heading, tbl_inbox_messages.message_id,
	    				 tbl_inbox_messages.message_date, Senders.fullname as sender
	              FROM tbl_inbox_messages
	              LEFT JOIN tbl_users Senders ON Senders.user_id = tbl_inbox_messages.sender_id
	              WHERE tbl_inbox_messages.receiver_id = '" . $options['receiver_id'] . "'
	              AND tbl_inbox_messages.read_status = '0'
	              ";
	    $arrNotifications = $db->QueryArray($qNotifications, MYSQLI_ASSOC);

	    if($db->RowCount())
	    {
	    	return $arrNotifications;
	    }
	    else
	    {
	    	return array();
	    }
	}

    function base64ToImage($base64_string, $output_file) 
    {
	    $file = fopen($output_file, "wb");
	    $data = explode(',', $base64_string);
	    fwrite($file, base64_decode($data[1]));
	    fclose($file);

	    return $output_file;
	}
	
	function generateUUID()
	{
		$data = random_bytes(16);
	    assert(strlen($data) == 16);
	    $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
	    $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10
	    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
	}

	function validateDate($date, $format = 'Y-m-d')
	{
	    $d = DateTime::createFromFormat($format, $date);
	    return $d && $d->format($format) === $date;
	}

	function validateDateTime($date, $format = 'Y-m-d H:i:s')
	{
	    $d = DateTime::createFromFormat($format, $date);
	    return $d && $d->format($format) === $date;
	}
	
	function purifyNumber($number)
	{
	    if($res = preg_replace("/[^0-9]/", "", $number))
	        return $res;
	    else
	        return false;
	}
	
	function phoneToLong($enteredNumber) //256700
	{
	    if($number = purifyNumber($enteredNumber))
	    {
	        if(ctype_digit($number))
    		{
    			if(strlen($number) == 10 || strlen($number) == 12 || strlen($number) == 9)
    			{
    				if(strlen($number) == 12 && substr($number, 0, 4) == "2567")
    				{
    					return $number;
    				}
    				elseif(strlen($number) == 10 && substr($number, 0, 2) == "07")
    				{
    					return "256" . ltrim($number, "0");
    				}
    				elseif(strlen($number) == 9 && substr($number, 0, 1) == "7")
    				{
    					return "256" . ltrim($number, "0");
    				}
    				else
    				{
    					return false;
    				}
    			}
    			else
    			{
    				return false;
    			}
    		}
    		else
    		{
    			return false;
    		}
	    }
	    else
	    {
	        return false;
	    }
		
	}
	
	function MobipaySendSMS($numberList, $message)
	{
		$url = "https://www.mobipay-systems.com/sms/get/?";
		$data = array(
			'NUMBERS' => $numberList,
			'MESSAGE' => $message
		); 
		$url .=  http_build_query($data);
		$options = array(
	        CURLOPT_HEADER         => false,    // don't return headers
	        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
	        CURLOPT_ENCODING       => "",       // handle all encodings
	        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
	        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
	        CURLOPT_TIMEOUT        => 120,      // timeout on response
	        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
	        CURLOPT_SSL_VERIFYPEER => 0,     // Disabled SSL Cert checks
	        CURLOPT_SSL_VERIFYHOST => 0,
	        CURLOPT_RETURNTRANSFER => 1
    	);
		$ch = curl_init( $url );
	    curl_setopt_array( $ch, $options );
		$ch_result = curl_exec($ch);
		curl_close($ch);

		return $ch_result;
	}
	
	function paymentStatusBackground($status)
	{
		switch ($status) {
			case 'DRAFT':
				return "black";
				break;
			case 'PENDING':
				return "orange";
				break;
			case 'APPROVED':
				return "green";
				break;
			case 'PAID':
				return "blue";
				break;
			case 'DENIED':
				return "red";
				break;
			default:
				# code...
				break;
		}
	}


	function calculateAgeFromDate($birthDate)
	{
		$age = date_diff(date_create($birthDate), date_create('now'))->y;
		return $age;
	}

	function dbGetMenuSections()
	{
		$db = new MySQL();
	    $qSections = "SELECT tbl_menu_sections.*
	                   FROM tbl_menu_sections
	                   ORDER BY tbl_menu_sections.section_position ASC
	                   ";
	    $arrSections = $db->QueryArray($qSections, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Section query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrSections;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetMenuCategories()
	{
		$db = new MySQL();
	    $qCats = "SELECT tbl_menu_categories.*
	              FROM tbl_menu_categories
	              ORDER BY tbl_menu_categories.cat_position ASC
	                   ";
	    $arrCats = $db->QueryArray($qCats, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Category query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrCats;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetMenuItems()
	{
		$db = new MySQL();
	    $qItems = "SELECT tbl_menu_items.*, tbl_menu_categories.cat_name
	              FROM tbl_menu_items
	              LEFT JOIN tbl_menu_categories ON tbl_menu_categories.cat_id = tbl_menu_items.item_category
				  WHERE tbl_menu_items.display_status = '1'
	              ORDER BY tbl_menu_items.item_position ASC
	                   ";
	    $arrItems = $db->QueryArray($qItems, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Item query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrItems;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetMenuPermissions($groupId)
	{
		if($groupId)
		{
			$db = new MySQL();
		    $qPerms = "SELECT tbl_user_permissions.item_id
		              FROM tbl_user_permissions
		              WHERE tbl_user_permissions.usergroup_id = '$groupId'
		                   ";
		    $arrRes = $db->QueryArray($qPerms, MYSQLI_ASSOC);
		    if($db->Error())
		        die("Permission query error: " . $db->Error());

		   	if($db->RowCount())
		   	{
		   		foreach($arrRes as $res)
		   		{
		   			$arrPerms[] = $res['item_id'];
		   		}
		   		return $arrPerms;
		   	}
		   	else
		   	{
		   		return array();
		   	}
		}
		else
		{
			return array();
		}

	}

	function dbGetAuditTrail()
	{
		$db = new MySQL();
	    $qAudit = "SELECT tbl_audit_trail.*
	                   FROM tbl_audit_trail
	                   ORDER BY tbl_audit_trail.audit_date DESC
	                   LIMIT 1000
	                   ";
	    $arrAudit = $db->QueryArray($qAudit, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Audit query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrAudit;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetProjectSettings()
	{
		$db = new MySQL();
	    $qSettings = "SELECT tbl_project_settings.*
	                   FROM tbl_project_settings
	                   ";
	    $arrSettings = $db->QueryArray($qSettings, MYSQLI_ASSOC);
	    if($db->Error())
	        die("Settings query error: " . $db->Error());

	    foreach($arrSettings as $setting)
	    {
	    	$arr[$setting['setting_name']] = $setting['setting_value'];
	    }

	   	if($db->RowCount())
	   	{
	   		return $arr;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetDataApprovals($options = NULL)
	{
		$db = new MySQL();
	    $qApprovals = "SELECT tbl_approval_settings.*
		              FROM tbl_approval_settings
		              WHERE 1
		              ";
		if($options['usergroup_id'])
	    	$qApprovals .= " AND tbl_approval_settings.usergroup_id = '". $options['usergroup_id']."' ";
	    
	    $arrApprovals = $db->QueryArray($qApprovals, MYSQLI_ASSOC);

	    if($db->Error())
	    	die("Approval query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrApprovals;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetUsergroups($options = null)
	{
		$db = new MySQL();
	    $qGroups = "SELECT tbl_usergroups.*
		              FROM tbl_usergroups
		              WHERE 1
		              ";
		if($options['usergroup_id'])
	    	$qGroups .= " AND tbl_usergroups.usergroup_id = '". $options['usergroup_id']."' ";
	    
	    $arrGroups = $db->QueryArray($qGroups, MYSQLI_ASSOC);

	    if($db->Error())
	        die("Group query error: " . $db->Error());

	   if($db->RowCount())
	   {
	   	return $arrGroups;
	   }
	   else
	   {
	   	return array();
	   }
	}

	function dbGetUsers($options = null)
	{
		$db = new MySQL();
		$qUsers = "SELECT tbl_users.user_id, tbl_users.fullname, tbl_users.email, 
					tbl_users.phone, tbl_users.status, tbl_usergroups.usergroup_name, tbl_users.usergroup_id
				   FROM tbl_users
				   LEFT JOIN tbl_usergroups ON tbl_usergroups.usergroup_id = tbl_users.usergroup_id
				   WHERE 1
				   ";
		if(isset($options['usergroup_id']))
		{
			$qUsers .= "AND tbl_users.usergroup_id = '".$options['usergroup_id']."'";
		}

		$arrUsers = $db->QueryArray($qUsers, MYSQLI_ASSOC);
		if($db->Error())
			die("Users query error: " . $db->Error());
		if($db->RowCount())
		{
			return $arrUsers;
		}
		else
		{
			return array();
		}
	}

	function dbGetAllRegions()
	{
		$db = new MySQL();
		$qRegions = "SELECT tbl_regions.*
					 FROM tbl_regions
					 ";
		$arrRegions = $db->QueryArray($qRegions, MYSQLI_ASSOC)
			or die("Region Query Error: " . $db->Error());
		if($db->RowCount($arrRegions))
		{
			return $arrRegions;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetRegion($regionId)
	{
		$db = new MySQL();
		$qRegion = "SELECT tbl_regions.*
					 FROM tbl_regions
					 WHERE tbl_regions.region_id = '$regionId'
					 ";
		$arrRegion = $db->QuerySingleRowArray($qRegion, MYSQLI_ASSOC)
			or die("Region Query Error: " . $db->Error());
		if($db->RowCount($arrRegion))
		{
			return $arrRegion;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetAllSubRegions($regionId = NULL)
	{
		$db = new MySQL();
		$qSubRegions = "SELECT tbl_sub_regions.*, tbl_regions.region_name
					 	FROM tbl_sub_regions 
					 	LEFT JOIN tbl_regions ON tbl_regions.region_id = tbl_sub_regions.region_id ";

		if($regionId)
			$qSubRegions .= "WHERE tbl_sub_regions.region_id = '$regionId'
					 ";
		$arrSubRegions = $db->QueryArray($qSubRegions, MYSQLI_ASSOC);
		if($db->Error())
			die("Subregion Query Error: " . $db->Error());
		if($db->RowCount($arrSubRegions))
		{
			return $arrSubRegions;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetSubregion($subregionId)
	{
		$db = new MySQL();
		$qSubregion = "SELECT tbl_sub_regions.*, tbl_regions.region_name
					 FROM tbl_sub_regions
					 LEFT JOIN tbl_regions ON tbl_regions.region_id = tbl_sub_regions.region_id
					 WHERE tbl_sub_regions.subregion_id = '$subregionId'
					 ";
		$arrSubregion = $db->QuerySingleRowArray($qSubregion, MYSQLI_ASSOC)
			or die("Subregion Query Error: " . $db->Error());
		if($db->RowCount($arrSubregion))
		{
			return $arrSubregion;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetAllDistricts($subRegionId = NULL, $regionId = NULL)
	{
		$db = new MySQL();
		$qDistricts = "SELECT tbl_districts.*, tbl_regions.region_name
						FROM tbl_districts
						LEFT JOIN tbl_regions ON tbl_regions.region_id = tbl_districts.region_id
						";

		if($subRegionId)
		{
			$qDistricts .= " WHERE tbl_districts.subregion_id = '$subRegionId'";
		}
		elseif($regionId)
		{
			$qDistricts .= " WHERE tbl_districts.region_id = '$regionId'";
		}

		$qDistricts .= " ORDER BY tbl_districts.district_name ASC";

		$arrDistricts = $db->QueryArray($qDistricts, MYSQLI_ASSOC);
		if($db->Error())
			die("District Query Error: " . $db->Error());

		if($db->RowCount())
		{
			return $arrDistricts;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetDistrict($districtId)
	{
		$db = new MySQL();
		$qDistrict = "SELECT tbl_districts.*
					 FROM tbl_districts
					 WHERE tbl_districts.district_id = '$districtId'
					 ";
		$arrDistrict = $db->QuerySingleRowArray($qDistrict, MYSQLI_ASSOC)
			or die("District Query Error: " . $db->Error());
		if($db->RowCount($arrDistrict))
		{
			return $arrDistrict;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetUserDistrict($options)
	{
		$array = array_map('intval', explode(',', $options['locations']));
		$array = implode("','",$array);

		$db = new MySQL();
		$qDistrict = "SELECT tbl_districts.*
					 FROM tbl_districts
					 WHERE tbl_districts.district_id IN ('$array')
					 ";
		$arrDistrict = $db->QueryArray($qDistrict, MYSQLI_ASSOC)
			or die("District Query Error: " . $db->Error());
		if($db->RowCount($arrDistrict))
		{
			return $arrDistrict;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetUserSubcounties($options)
	{
		$array = array_map('intval', explode(',', $options['locations']));
		$array = implode("','",$array);

		$db = new MySQL();
		$qSubcounties = "SELECT tbl_subcounties.*
					 FROM tbl_subcounties
					 WHERE tbl_subcounties.subcounty_id IN ('$array')
					 ";
		$arrSubCounties = $db->QueryArray($qSubcounties, MYSQLI_ASSOC)
			or die("Subcounties Query Error: " . $db->Error());
		if($db->RowCount($arrSubCounties))
		{
			return $arrSubCounties;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetAllCounties($districtId = NULL)
	{
		$db = new MySQL();
		$qCons = "SELECT tbl_constituencies.*, tbl_districts.district_name, tbl_regions.region_name
					FROM tbl_constituencies
					LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_constituencies.district_id
					LEFT JOIN tbl_regions ON tbl_regions.region_id = tbl_districts.region_id
					";

		if($districtId)
			$qCons .= " WHERE tbl_constituencies.district_id = '$districtId'";

		$arrCons = $db->QueryArray($qCons, MYSQLI_ASSOC);
		if($db->Error())
			die("Constituency Query Error: " . $db->Error());
		if($db->RowCount($arrCons))
		{
			return $arrCons;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetCounty($countyId)
	{
		$db = new MySQL();
		$qCounty = "SELECT tbl_constituencies.*, tbl_districts.district_name
					 FROM tbl_constituencies
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_constituencies.district_id
					 WHERE tbl_constituencies.constituency_id = '$countyId'
					 ";
		$arrCounty = $db->QuerySingleRowArray($qCounty, MYSQLI_ASSOC)
			or die("County Query Error: " . $db->Error());
		if($db->RowCount($arrCounty))
		{
			return $arrCounty;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetSubcounty($subcountyId)
	{
		$db = new MySQL();
		$qCounty = "SELECT tbl_subcounties.*, tbl_districts.district_name
					 FROM tbl_subcounties
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id
					 WHERE tbl_subcounties.subcounty_id = '$subcountyId'
					 ";
		$arrCounty = $db->QuerySingleRowArray($qCounty, MYSQLI_ASSOC)
			or die("Subcounty Query Error: " . $db->Error());
		if($db->RowCount($arrCounty))
		{
			return $arrCounty;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetAllSubCounties($options = NULL)
	{
		$db = new MySQL();
		$qSubCounties = "SELECT tbl_subcounties.*, tbl_constituencies.constituency_name, 
							tbl_districts.district_name, tbl_regions.region_name
					 FROM tbl_subcounties
					 LEFT JOIN tbl_constituencies ON tbl_constituencies.constituency_id = tbl_subcounties.constituency_id
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id
					 LEFT JOIN tbl_regions ON tbl_regions.region_id = tbl_districts.region_id
					 WHERE 1
					 ";

		if(isset($options['constituency_id']))
			$qSubCounties .= " AND tbl_subcounties.constituency_id = '".$options['constituency_id']."'";

		if(isset($options['district_id']))
			$qSubCounties .= " AND tbl_subcounties.district_id = '".$options['district_id']."'";

		$qSubCounties .= " ORDER BY tbl_subcounties.subcounty_name ASC";

		$arrSubCounties = $db->QueryArray($qSubCounties, MYSQLI_ASSOC);
		if($db->Error())
			die("Sub Counties Query Error: " . $db->Error());
		if($db->RowCount($arrSubCounties))
		{
			return $arrSubCounties;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetDistrictSubCounties($districtId)
	{
		$db = new MySQL();
		$qSubCounties = "SELECT tbl_subcounties.*, tbl_constituencies.constituency_name, 
							tbl_districts.district_name, tbl_regions.region_name
					 FROM tbl_subcounties
					 LEFT JOIN tbl_constituencies ON tbl_constituencies.constituency_id = tbl_subcounties.constituency_id
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id
					 LEFT JOIN tbl_regions ON tbl_regions.region_id = tbl_districts.region_id
					 WHERE tbl_subcounties.district_id = '$districtId'
					 ORDER BY tbl_subcounties.subcounty_name ASC
					 ";

		$arrSubCounties = $db->QueryArray($qSubCounties, MYSQLI_ASSOC);
		if($db->Error())
			die("Sub Counties Query Error: " . $db->Error());
		if($db->RowCount($arrSubCounties))
		{
			return $arrSubCounties;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetAllParishes($subcountyId = NULL)
	{
		$db = new MySQL();
		$qParishes = "SELECT tbl_parishes.*, tbl_subcounties.subcounty_name, 
						tbl_constituencies.constituency_name, tbl_districts.district_name
					 FROM tbl_parishes
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
					 LEFT JOIN tbl_constituencies ON tbl_constituencies.constituency_id = tbl_subcounties.constituency_id
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_constituencies.district_id
					 ";

		if($subcountyId)
			$qParishes .= " WHERE tbl_parishes.subcounty_id = '$subcountyId'";

		$arrParishes = $db->QueryArray($qParishes, MYSQLI_ASSOC);
		if($db->Error())
			die("Parish Query Error: " . $db->Error());
		if($db->RowCount($arrParishes))
		{
			return $arrParishes;
		}
		else
		{
			return NULL;
		}

	}

	function dbGetParish($parishId)
	{
		$db = new MySQL();
		$qParishes = "SELECT tbl_parishes.*, tbl_subcounties.subcounty_name, 
						tbl_districts.district_name
					 FROM tbl_parishes
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.district_id
					 WHERE tbl_parishes.parish_id = '$parishId'
					 ";

		$arrParishes = $db->QuerySingleRowArray($qParishes, MYSQLI_ASSOC);
		if($db->Error())
			die("Parish Query Error: " . $db->Error());
		if($db->RowCount($arrParishes))
		{
			return $arrParishes;
		}
		else
		{
			return NULL;
		}

	}

	function dbGetAllVillages($parishId = NULL)
	{
		$db = new MySQL();
		$qVillages = "SELECT tbl_villages.*, tbl_parishes.parish_name, tbl_subcounties.subcounty_name
					 FROM tbl_villages
					 LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
					 ";

		if($parishId)
			$qVillages .= " WHERE tbl_villages.parish_id = '$parishId'";

		$arrVillages = $db->QueryArray($qVillages, MYSQLI_ASSOC);
		if($db->Error())
			die("Village Query Error: " . $db->Error());
		if($db->RowCount($arrVillages))
		{
			return $arrVillages;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetAllSubcountyVillages($subcountyId = NULL)
	{
		$db = new MySQL();
		$qVillages = "SELECT tbl_villages.*, tbl_parishes.parish_name, tbl_subcounties.subcounty_name
					 FROM tbl_villages
					 LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
					 ";

		if($subcountyId)
			$qVillages .= " WHERE tbl_subcounties.subcounty_id = '$subcountyId'";

		$arrVillages = $db->QueryArray($qVillages, MYSQLI_ASSOC);
		if($db->Error())
			die("Village Query Error: " . $db->Error());
		if($db->RowCount($arrVillages))
		{
			return $arrVillages;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetAllSubcountyLocations($subcountyId)
	{
		$db = new MySQL();
		$qVillages = "SELECT tbl_villages.*
					 FROM tbl_villages
					 LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
	 				WHERE tbl_subcounties.subcounty_id = '$subcountyId'";
		$arrVillages = $db->QueryArray($qVillages, MYSQLI_ASSOC);
		if($db->Error())
			die("Village Query Error: " . $db->Error());

		$qParishes = "SELECT tbl_parishes.*
					 FROM tbl_parishes
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
	 				WHERE tbl_subcounties.subcounty_id = '$subcountyId'";
		$arrParishes = $db->QueryArray($qParishes, MYSQLI_ASSOC);
		if($db->Error())
			die("Parish Query Error: " . $db->Error());

		$qClcs = "SELECT tbl_clcs.*
					 FROM tbl_clcs
					 LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_clcs.parish_id
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
	 				WHERE tbl_subcounties.subcounty_id = '$subcountyId'";
		$arrClcs = $db->QueryArray($qClcs, MYSQLI_ASSOC);
		if($db->Error())
			die("CLC Query Error: " . $db->Error());

		$qCegs = "SELECT tbl_cegs.ceg_id, tbl_cegs.ceg_name, tbl_cegs.ceg_code
					 FROM tbl_cegs
					 LEFT JOIN tbl_villages ON tbl_villages.village_id = tbl_cegs.village_id
					 LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
	 				WHERE tbl_subcounties.subcounty_id = '$subcountyId'";
		$arrCegs = $db->QueryArray($qCegs, MYSQLI_ASSOC);
		if($db->Error())
			die("CLC Query Error: " . $db->Error());


		return array(
				'parishes' => $arrParishes,
				'villages' => $arrVillages,
				'clcs' => $arrClcs,
				'cegs' => $arrCegs
			);

	}
	
	function dbGetAllVillagesSearch($term)
	{
		$db = new MySQL();
		$qVillages = "SELECT tbl_villages.*, tbl_parishes.parish_name, tbl_districts.district_name
					 FROM tbl_villages
					 LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
					 LEFT JOIN tbl_constituencies ON tbl_constituencies.constituency_id = tbl_subcounties.subcounty_id
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_constituencies.district_id
					 WHERE tbl_villages.village_name LIKE '%" . $term['term'] . "%'
					 ";

		$arrVillages = $db->QueryArray($qVillages, MYSQLI_ASSOC);
		if($db->Error())
			die("Village Query Error: " . $db->Error());
		if($db->RowCount($arrVillages))
		{
			return $arrVillages;
		}
		else
		{
			return NULL;
		}
	}

	function dbGetVillage($villageId)
	{
		$db = new MySQL();
		$qVillage = "SELECT tbl_villages.*, tbl_parishes.parish_name, tbl_subcounties.subcounty_name
					 FROM tbl_villages
					 LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_subcounties.subcounty_id
					 WHERE tbl_villages.village_id = '$villageId'
					 ";

		$arrVillage = $db->QuerySingleRowArray($qVillage, MYSQLI_ASSOC);
		if($db->Error())
			die("Village Query Error: " . $db->Error());
		if($db->RowCount($arrVillage))
		{
			return $arrVillage;
		}
		else
		{
			return NULL;
		}

	}

	function dbGetTableItem($table, $field, $id)
	{
		$db = new MySQL();
		$qItem = "SELECT *
					 FROM $table
					 WHERE $field = '$id'
					 ";

		$arrItem = $db->QuerySingleRowArray($qItem, MYSQLI_ASSOC);
		if($db->Error())
			die("Item Query Error: " . $db->Error());
		if($db->RowCount($arrItem))
		{
			return $arrItem;
		}
		else
		{
			return NULL;
		}

	}

	function dbSaveTable($options)
	{
		$db = new MySQL();
		// Verify that table options have been parsed
		if(!empty($options))
		{
			// Verify that a table name and table data have been parsed
			if($options['table_name'] && !empty($options['table_data']))
			{
				$values = array();
				foreach($options['table_data'] as $data)
				{

					//$key = array_search($data, $options['table_data']);
					$key = key($options['table_data']);
					if($key == 'password')
						$values[$key] = MySQL::SQLValue(md5($data));
					else
						$values[$key] = MySQL::SQLValue($data);

					next($options['table_data']);
				}

						
				$db->AutoInsertUpdate($options['table_name'], $values, array($options['primary_field'] => $options['primary_data']));
				if($db->Error())
				{
					//die($options['table_name'] . " query error: " . $db->Error());
					return array("success"=>0, "message"=>$db->Error());
				}
				else
				{
					
				    //$_SESSION['UserAlert']['Type']='SUCCESS';
				    $newId = $db->GetLastInsertID();
					return array("success"=>1, "last_id"=>$newId);
				    
				}
			}
		}
		else // Faile the process and return FALSE
		{
			return array("success"=>0, "last_id"=>'');
		}
	}

	function dbDeleteFromTable($options)
	{
		$db = new MySQL();
		// Verify that table options have been parsed
		if(!empty($options))
		{
			// Verify that a table name and table data have been parsed
			if($options['table_name'] && !empty($options['primary_field']) && !empty($options['primary_data']))
			{
				// Retrieve row data first
				$qData = "SELECT * 
							FROM " . $options['table_name'] . "
							WHERE " . $options['primary_field'] . " = " . $options['primary_data'];
				$arrData = $db->QuerySingleRowArray($qData, MYSQLI_ASSOC);

				// if row exists
				if($db->RowCount())
				{
					$filter[$options['primary_field']] = MySQL::SQLValue($options['primary_data']);
 						
					$result= $db->DeleteRows($options['table_name'], $filter);
					if($db->Error())
					{
						die($options['table_name'] . " query error: " . $db->Error());
					}
					else
					{
						return array("success" => 1, "data" => $arrData);
					}
				}
				// if row does not exists
				else
				{
					return array("success" => 0, "message" => "The data you are trying to delete does not exist!");
				}
			}
		}
		else // Faile the process and return FALSE
		{
			return array("success"=>0);
		}
	}

	function dbGetUserAssignments($userId)
	{
	    $db = new MySQL();
		$qAssign = "SELECT tbl_assigned_locations.*
					 FROM tbl_assigned_locations
					 WHERE tbl_assigned_locations.user_id = '$userId'
					 ";
	    $arrAssign = $db->QuerySingleRowArray($qAssign, MYSQLI_ASSOC);
	    
	    if($db->Error())
	        die("Assignment Query Error");

	    // District name
	    $qDistrictName = "SELECT tbl_districts.district_name
	    				  FROM tbl_districts
	    				  WHERE tbl_districts.district_id = '".$arrAssign['districts']."'
	    				  ";
	    $districtName = $db->QuerySingleValue($qDistrictName);

	    // subcounty names
	    $arrSubs = explode(",",$arrAssign['subcounties']);
	    if(!empty($arrSubs))
	    {
	        foreach($arrSubs as $sub)
    	    {
    	    	$qSubNames = "SELECT tbl_subcounties.subcounty_name
    	    			  FROM tbl_subcounties
    	    			  WHERE tbl_subcounties.subcounty_id = '$sub'
    	    			  ";
    	    	$arrSubNames = $db->QuerySingleRowArray($qSubNames, MYSQLI_ASSOC);
    	    	$subNames[] = $arrSubNames['subcounty_name'];
    	    }	    
    	    $subNames = implode(", ", $subNames);
	    }
	    else
	        $subNames = '';
	    

	    // parish names
	    $arrSubs = explode(",",$arrAssign['parishes']);
	    if(!empty($arrSubs))
	    {
	        foreach($arrSubs as $sub)
    	    {
    	    	$qNames = "SELECT tbl_parishes.parish_name
    	    			  FROM tbl_parishes
    	    			  WHERE tbl_parishes.parish_id = '$sub'
    	    			  ";
    	    	$arrNames = $db->QuerySingleRowArray($qNames, MYSQLI_ASSOC);
    	    	$listNames[] = $arrNames['parish_name'];
    	    }	    
    	    $listNames = implode(", ", $listNames);
	    }
	    else
	        $listNames = '';
	    

	    // village names
	    $arrSubs = explode(",",$arrAssign['villages']);
	    if(!empty($arrSubs))
	    {
	        foreach($arrSubs as $sub)
    	    {
    	    	$qNames = "SELECT tbl_villages.village_name
    	    			  FROM tbl_villages
    	    			  WHERE tbl_villages.village_id = '$sub'
    	    			  ";
    	    	$arrNames = $db->QuerySingleRowArray($qNames, MYSQLI_ASSOC);
    	    	$vNames[] = $arrNames['village_name'];
    	    }	    
    	    $vNames = implode(", ", $vNames);
	    }
	    else
	        $vNames = '';
	    

	    // clc names
	    $arrSubs = explode(",",$arrAssign['clcs']);
	    if(!empty($arrSubs))
	    {
	        foreach($arrSubs as $sub)
    	    {
    	    	$qNames = "SELECT tbl_clcs.clc_name
    	    			  FROM tbl_clcs
    	    			  WHERE tbl_clcs.clc_id = '$sub'
    	    			  ";
    	    	$arrNames = $db->QuerySingleRowArray($qNames, MYSQLI_ASSOC);
    	    	$cNames[] = $arrNames['clc_name'];
    	    }	    
    	    $cNames = implode(", ", $cNames);
	    }
	    else
	        $cNames = '';
	    

	    // ceg names
	    $arrSubs = explode(",",$arrAssign['cegs']);
	    if(!empty($arrSubs))
	    {
	        foreach($arrSubs as $sub)
    	    {
    	    	$qNames = "SELECT tbl_cegs.ceg_name
    	    			  FROM tbl_cegs
    	    			  WHERE tbl_cegs.ceg_id = '$sub'
    	    			  ";
    	    	$arrNames = $db->QuerySingleRowArray($qNames, MYSQLI_ASSOC);
    	    	$gNames[] = $arrNames['ceg_name'];
    	    }	    
    	    $gNames = implode(", ", $gNames);
	    }
	    else
	        $gNames = '';
	    


	    // Complile result
	    $arr = array(
	    		'district' => $districtName,
	    		'subcounties' => $subNames,
	    		'parishes' => $listNames,
	    		'villages' => $vNames,
	    		'clcs' => $cNames,
	    		'cegs' => $gNames,
	    		'locations' => $arrAssign
	    	);
	        
	    //if($db->RowCount())
	    //{
	        
	        return $arr;
	    //}
	    //else
	    //{
	    	//return array();
	    //}
	}

	function dbGetVillageFromId($villageId)
	{
	    $db = new MySQL();
		$qVillage = "SELECT tbl_villages.village_name, tbl_parishes.parish_name, tbl_districts.district_name
					 FROM tbl_villages
					 LEFT JOIN tbl_parishes ON tbl_parishes.parish_id = tbl_villages.parish_id
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
					 LEFT JOIN tbl_constituencies ON tbl_constituencies.constituency_id = tbl_subcounties.constituency_id
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_constituencies.district_id
					 WHERE tbl_villages.village_id = '$villageId'
					 ";
	    $village = $db->QuerySingleRowArray($qVillage, MYSQLI_ASSOC);
	    
	    if($db->Error())
	        die("Village Query Error");
	        
	    if($db->RowCount())
	    {
	        if($village['parish_name'])
	        {
	            $result = $village['village_name'] . ", " . $village['parish_name'] . " Parish";
	            if($village['district_name'])
	                $result .= ", " . $village['district_name'] . " District";
	                
	            return $result;
	        }
	        else
	            return $village['village_name'];
	    }
	        
	    else
	        return "N/A";
	}

	function dbGetParishFromId($parishId)
	{
	    $db = new MySQL();
		$qParish = "SELECT tbl_parishes.parish_name, tbl_subcounties.subcounty_name, tbl_districts.district_name
					 FROM tbl_parishes
					 LEFT JOIN tbl_subcounties ON tbl_subcounties.subcounty_id = tbl_parishes.subcounty_id
					 LEFT JOIN tbl_constituencies ON tbl_constituencies.constituency_id = tbl_subcounties.constituency_id
					 LEFT JOIN tbl_districts ON tbl_districts.district_id = tbl_constituencies.district_id
					 WHERE tbl_parishes.parish_id = '$parishId'
					 ";
	    $parish = $db->QuerySingleRowArray($qParish, MYSQLI_ASSOC);
	    
	    if($db->Error())
	        die("Village Query Error");
	        
	    if($db->RowCount())
	    {
	        if($parish['subcounty_name'])
	        {
	            $result = $parish['parish_name'] . ", " . $parish['subcounty_name'] . " Subcounty";
	            if($parish['district_name'])
	                $result .= ", " . $parish['district_name'] . " District";
	                
	            return $result;
	        }
	        else
	            return $parish['parish_name'];
	    }
	        
	    else
	        return "N/A";
	}
	
	function dbGetUserFromId($userId)
	{
	    $db = new MySQL();
		$qUser = "SELECT tbl_users.full_name
					 FROM tbl_users
					 WHERE tbl_users.user_id = '$userId'
					 ";
	    $user = $db->QuerySingleRowArray($qUser, MYSQLI_ASSOC);
	    
	    if($db->Error())
	        die("User Query Error");
	        
	    if($db->RowCount())
	    {
	            return $user['full_name'];
	    }
	        
	    else
	        return "N/A";
	}

	function dbGetUserProfile($userId)
	{
	    $db = new MySQL();
	    $qUser = "SELECT tbl_users.*, tbl_usergroups.usergroup_name
	    		  FROM tbl_users
	    		  LEFT JOIN tbl_usergroups ON tbl_usergroups.usergroup_id = tbl_users.usergroup_id
	    		  WHERE tbl_users.user_id = '$userId'
	    		  ";
	   	$arrUser = $db->QuerySingleRowArray($qUser, MYSQLI_ASSOC);

	   	if($db->Error())
	   		die("User query error: " . $db->Error());

	   	if($db->RowCount())
	   	{
	   		return $arrUser;
	   	}
	   	else
	   	{
	   		return array();
	   	}
	}

	function dbGetAllBanks()
	{
		$db = new MySQL();
		$qBanks = "SELECT tbl_banks.* 
				   FROM tbl_banks
				   ";
		$arrBanks = $db->QueryArray($qBanks, MYSQLI_ASSOC);
		if($db->Error())
			die("Bank Query Error: " . $db->Error());
		if($db->RowCount($arrBanks))
		{
			return $arrBanks;
		}
		else
		{
			return NULL;
		}
	}
?>